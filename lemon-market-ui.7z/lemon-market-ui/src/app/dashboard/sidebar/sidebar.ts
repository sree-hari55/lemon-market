import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-sidebar',
  imports: [RouterModule,CommonModule],
  templateUrl: './sidebar.html',
  styleUrl: './sidebar.css'
})
export class Sidebar {
showPayments: boolean = false;
showReports: boolean = false;

togglePayments() {
  this.showPayments = !this.showPayments;
}

toggleReports() {
  this.showReports = !this.showReports;
}

}
