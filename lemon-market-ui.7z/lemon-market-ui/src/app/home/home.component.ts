// home.component.ts - THE CORRECT FIX

import { Component, OnInit, Injector } from '@angular/core'; // 1. Import Injector
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AuthService} from '../auth/auth.service';
import { LoginRequest } from '../auth/auth.models';


interface Market {
  id: number;
  name: string;
  ownerName: string;
}

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  marketShops: Market[] = [];
  selectedMarket: string = '';
  isLoginVisible: boolean = false;
  username: string = '';
  password: string = '';
  errorMessage: string = '';

  constructor(
    private http: HttpClient,
    private injector: Injector, // 2. Inject the Injector, NOT the Router
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.fetchMarketData();
  }

  fetchMarketData(): void {
    this.http.get<Market[]>('http://localhost:9090/api/market').subscribe({
      next: (data) => {
        this.marketShops = data;
      },
      error: (error) => {
        console.error('Error fetching market data', error);
      }
    });
  }

  onMarketSelect(): void {
    this.isLoginVisible = true;
    this.errorMessage = '';
  }

  onSubmit(): void {
    if (!this.username || !this.password || !this.selectedMarket) {
      this.errorMessage = 'Please enter username, password, and select a market.';
      return;
    }

    const payload: LoginRequest = {
      userName: this.username,
      password: this.password,
      marketName: this.selectedMarket
    };

    this.authService.login(payload).subscribe({
      next: () => {
        // 3. Get the Router instance "just-in-time" when you need it
        const router = this.injector.get(Router);
        router.navigate(['/layout/farmers']);
        this.resetForm();
      },
      error: (err) => {
        console.error('Login failed', err);
        this.errorMessage = 'Invalid credentials or market. Please try again.';
      }
    }); 
  }

  resetForm(): void {
    this.username = '';
    this.password = '';
    this.selectedMarket = '';
    this.isLoginVisible = false;
    this.errorMessage = '';
  }
}