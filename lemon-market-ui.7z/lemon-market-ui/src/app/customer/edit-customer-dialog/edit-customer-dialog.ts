import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog, MatDialogModule } from '@angular/material/dialog';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { CustomerDto, CustomerService } from '../service/add-customer.service';

@Component({
  selector: 'app-edit-customer-dialog',
  standalone: true,
  imports: [CommonModule,ReactiveFormsModule, FormsModule, MatFormFieldModule, MatInputModule, MatButtonModule,MatDialogModule],
  templateUrl: './edit-customer-dialog.html',
  styleUrls: ['./edit-customer-dialog.css']
})
export class EditCustomerDialogComponent {
 form: FormGroup;

  constructor(
    public dialogRef: MatDialogRef<EditCustomerDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: CustomerDto,
    private fb: FormBuilder,
    private customerService: CustomerService
  ) {
    this.form = this.fb.group({
      firstName: [data.firstName, Validators.required],
      lastName: [data.lastName, Validators.required],
      email: [data.email, [Validators.required, Validators.email]],
      phoneNumber: [data.phoneNumber],
      address: [data.address],
      createdDate: [data.creationDate]
    });
  }

  onSave(): void {
    if (this.form.valid) {
      const updated = { ...this.data, ...this.form.value };
      this.customerService.updateCustomer(this.data.id!, updated).subscribe(() => {
        this.dialogRef.close(updated);
      });
    }
  }

  onCancel(): void {
    this.dialogRef.close();
  }
}
