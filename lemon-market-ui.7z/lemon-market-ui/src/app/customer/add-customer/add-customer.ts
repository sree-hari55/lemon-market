import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { CustomerService } from '../service/add-customer.service';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-customer-form',
  standalone: true,
  templateUrl: './add-customer.html',
  styleUrls: ['./add-customer.css'],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatSnackBarModule,
    MatCardModule
  ]
})
export class AddCustomerComponent implements OnInit {
  customerForm!: FormGroup;
  submitting = false;

  ngOnInit(): void {
    this.customerForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      phoneNumber: [
        '',
        [Validators.required, Validators.minLength(10), Validators.maxLength(15)],
      ],
      email: ['', Validators.email],
      address: [''],
      // createdBy and createdDate are backend-managed, no need on form
    });
  }

constructor(
  private fb: FormBuilder,
  private customerService: CustomerService,
  private snackBar: MatSnackBar,
  private router: Router,
  private route: ActivatedRoute
) {}

onSubmit() {
  if (this.customerForm.invalid) {
    this.customerForm.markAllAsTouched();
    return;
  }

  this.submitting = true;

  this.customerService.createCustomer(this.customerForm.value).subscribe({
    next: () => {
      this.snackBar.open('Customer created successfully!', 'Close', {
        duration: 3000,
      });
      this.submitting = false;
      this.customerForm.reset();

      // ✅ Go back to customer list
      this.router.navigate(['../'], { relativeTo: this.route });
    },
    error: () => {
      this.snackBar.open('Failed to create customer', 'Close', {
        duration: 3000,
      });
      this.submitting = false;
    }
  });
} 
get f() {
  return this.customerForm.controls;
}

onCancel(): void {
  this.router.navigate(['../'], { relativeTo: this.route });
}


}
