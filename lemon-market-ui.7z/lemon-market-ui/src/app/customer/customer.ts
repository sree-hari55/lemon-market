import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSnackBar } from '@angular/material/snack-bar';
import { FormsModule } from '@angular/forms';
import { filter } from 'rxjs/operators';
import { CustomerDto, CustomerService } from './service/add-customer.service';
import { EditCustomerDialogComponent } from './edit-customer-dialog/edit-customer-dialog';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-customers',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    MatTableModule,
    MatPaginatorModule,
    MatButtonModule,
    MatIconModule,
    FormsModule
  ],
  templateUrl: './customer.html',
  styleUrls: ['./customer.css'],
})
export class Customer {
  customers: CustomerDto[] = [];
  displayedCustomers: CustomerDto[] = [];
  pageIndex = 1;
  pageSize = 10;
  totalResult = 0;
  isCreateRoute: boolean = false;
  editedCustomer: CustomerDto | null = null;

  constructor(
    private router: Router,
    private customerService: CustomerService,
    private snackBar: MatSnackBar,
    private dialog:MatDialog
  ) {}

  ngOnInit(): void {
    this.loadCustomers();

    this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe(() => {
        this.isCreateRoute = this.router.url.endsWith('/create');

        if (!this.isCreateRoute) {
          this.loadCustomers();
        }
      });
  }

  loadCustomers(): void {
    this.customerService.getPaginatedCustomers(this.pageIndex, this.pageSize).subscribe((data) => {
        this.customers = data.results;
    this.totalResult = data.totalResult;
    this.pageIndex = data.pageIndex;
      this.updateDisplayedCustomers();
    });
  }
  onPageChange(event: PageEvent) {
  this.pageIndex = event.pageIndex + 1; // MatPaginator is 0-based
  this.pageSize = event.pageSize;
  this.loadCustomers();
}

  deleteCustomer(id: number): void {
    const confirmDelete = confirm('Are you sure you want to delete this customer?');
    if (confirmDelete) {
      this.customerService.deleteCustomer(id).subscribe({
        next: () => {
          this.customers = this.customers.filter(c => c.id !== id);
          this.updateDisplayedCustomers();
          this.snackBar.open('Customer deleted successfully.', 'Close', { duration: 3000 });
        },
        error: () => {
          this.snackBar.open('Failed to delete customer.', 'Close', { duration: 3000 });
        }
      });
    }
  }
editCustomer(customer: CustomerDto): void {
  const dialogRef = this.dialog.open(EditCustomerDialogComponent, {
    width: '400px',
    data: customer
  });

  dialogRef.afterClosed().subscribe(result => {
    if (result) {
      const index = this.customers.findIndex(c => c.id === result.id);
      if (index > -1) {
        this.customers[index] = result;
        this.updateDisplayedCustomers();
      }
    }
  });
}

  updateDisplayedCustomers(): void {
    this.displayedCustomers = this.customers.slice(0, this.pageSize);
  }
}
