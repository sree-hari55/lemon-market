import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { R } from '@angular/cdk/keycodes';

export interface CustomerDto {
  id?: number;
  firstName: string;
  lastName: string;
  phoneNumber: string;
  email?: string;
  address?: string;
  createdBy?: string;
  creationDate?: string;
}
export interface PaginatedResponse<T> {
  totalResult: number;
  pageIndex: number;
  itemsPerPage: number;
  results: T[];
}
@Injectable({
  providedIn: 'root',
})
export class CustomerService {

  private apiUrl = 'http://localhost:9090/api/customers';

  constructor(private http: HttpClient) {}

  createCustomer(customer: CustomerDto): Observable<CustomerDto> {
    return this.http.post<CustomerDto>(this.apiUrl, customer);
  }

  getCustomers(): Observable<CustomerDto[]> {
    return this.http.get<CustomerDto[]>(this.apiUrl);
  }

  getPaginatedCustomers(pageIndex: number, pageSize: number): Observable<PaginatedResponse<CustomerDto>> {
    return this.http.get<PaginatedResponse<CustomerDto>>(
      `${this.apiUrl}?pageIndex=${pageIndex}&pageSize=${pageSize}`
    );
  }

  deleteCustomer(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  getCustomerById(id: number): Observable<CustomerDto> {
    return this.http.get<CustomerDto>(`${this.apiUrl}/${id}`);
  }

  updateCustomer(id: number, customer: Partial<CustomerDto>): Observable<CustomerDto> {
    return this.http.put<CustomerDto>(`${this.apiUrl}/${id}`, customer);
  }
  searchCustomers(query: string):Observable<CustomerDto[]>{
   return this.http.get<CustomerDto[]>(`${this.apiUrl}/search?query=${query}`);
  }

}
