import { CommonModule, DatePipe } from '@angular/common';
import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { NavigationEnd, Router, RouterModule } from '@angular/router';
import { filter } from 'rxjs';
import { PurchaseDto, PurchaseService } from './service/purchase-service';
import { EditPurchase } from './edit-purchase/edit-purchase';

@Component({
  selector: 'app-purchase',
  imports: [CommonModule,
    ReactiveFormsModule,
    RouterModule,
    MatPaginatorModule,
    MatTableModule,
    MatIconModule,
    DatePipe],
  templateUrl: './purchase.html',
  styleUrl: './purchase.css'
})
export class Purchase implements OnInit, AfterViewInit {
displayedColumns: string[] = ['date', 'farmerName', 'weight', 'pricePerKg', 'vehicleNumber', 'bags', 'finalAmount', 'actions'];
  dataSource = new MatTableDataSource<PurchaseDto>();
  isCreateRoute: boolean = false;

  pageIndex = 1;
  pageSize = 10;
  totalResult = 0;

  @ViewChild(MatPaginator) paginator!: MatPaginator;

  purchaseForm!: FormGroup;
  isFormVisible = false;

  constructor(
    private router: Router,
    private fb: FormBuilder,
    private purchaseService: PurchaseService,
    private snackBar: MatSnackBar,
    private dialog:MatDialog
  ) {}

  ngOnInit(): void {
    this.loadPurchaseFromApi();
    this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe(() => {
        this.isCreateRoute = this.router.url.endsWith('/create');

        if (!this.isCreateRoute) {
          this.loadPurchaseFromApi();
        }
      });
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;  
  }

  loadPurchaseFromApi(): void {
    this.purchaseService.getPurchases(this.pageIndex, this.pageSize).subscribe({
      next: (purchase) => {
         this.dataSource.data = purchase.results;
         this.totalResult = purchase.totalResult;
         this.pageIndex = purchase.pageIndex; 
      },
      error: (err) => {
        console.error('Failed to load purchases:', err);
      }
    });
  }

  onPageChange(event: any): void {
    this.pageIndex = event.pageIndex + 1; // MatPaginator is 0-based
  this.pageSize = event.pageSize;
  this.loadPurchaseFromApi();
  }

  openPurchaseModal(): void {
    this.isFormVisible = true;
  }

  closePurchaseModal(): void {
    this.isFormVisible = false;
    this.purchaseForm.reset();
  }

   editPurchase(purchase: any): void {
     const dialogRef = this.dialog.open(EditPurchase, {
        width: '400px',
        data: purchase
      });
    
      dialogRef.afterClosed().subscribe(result => {
        if (result) {
          const index = this.dataSource.data.findIndex(s => s.id === result.id);
          if (index > -1) {
            this.dataSource.data[index] = result;
            this.updateDisplayedesPurchases();
          }
        }
      });
  }

 deletePurchase(purchase: any): void {
    if (confirm('Are you sure you want to delete this purchase?')) {
      console.log(purchase)
      this.purchaseService.deletePurchase(purchase.id).subscribe(
        (response) => {
          this.loadPurchaseFromApi(); // Reload the sales data after deletion
          this.snackBar.open('purchase deleted successfully', 'Close', {
            duration: 3000,
            panelClass: ['success-snack'],
          });
        },
        (error) => {
          console.error('Error deleting purchase', error);
          this.snackBar.open('Failed to delete purchase', 'Close', {
            duration: 3000,
            panelClass: ['error-snack'],
          });
        }
      );
    }
  }

 updateDisplayedesPurchases(): void {
    this.dataSource.data = this.dataSource.data.slice(0, this.pageSize);
  }

  toggleFilter(){}
}