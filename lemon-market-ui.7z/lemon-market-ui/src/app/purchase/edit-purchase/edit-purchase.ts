import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { PurchaseDto, PurchaseService } from '../service/purchase-service';

@Component({
  selector: 'app-edit-purchase',
  imports: [ReactiveFormsModule],
  templateUrl: './edit-purchase.html',
  styleUrl: './edit-purchase.css'
})
export class EditPurchase  implements OnInit{
purchaseForm!: FormGroup;  // Declare saleForm

  constructor(
    public dialogRef: MatDialogRef<EditPurchase>,
    @Inject(MAT_DIALOG_DATA) public data: PurchaseDto,  // Inject the sale data
    private fb: FormBuilder,
    public router: Router,
    private purchaseService: PurchaseService
  ) {}

  ngOnInit(): void {
  if (this.data) {
    this.purchaseForm = this.fb.group({
      customerName: [{ value: `${this.data.farmer.firstName} ${this.data.farmer.lastName}`, disabled: true }],
      mobileNo: [{ value: this.data.farmer.phoneNumber || '', disabled: true }],
      address: [{ value: this.data.farmer.address || '', disabled: true }],
      weight: [this.data.weight || ''],
      pricePerKg: [this.data.pricePerKg || null],
      commission: [this.data.commission || null],
      transportCharge: [this.data.transportCharge || null],
      transportDistance: [this.data.transportDistance || null],
      vehicleNumber: [this.data.vehicleNumber || ''],
     // bagCharge: [this.data. || null, Validators.required],
     // date: [this.data.date || '', Validators.required],
     // amount: [this.data.amount || null, Validators.required]
    });

    // After initializing form controls, populate them
    this.purchaseForm.patchValue(this.data);
  }
}

  onSubmit(): void {
    if (this.purchaseForm.valid) {
      const updated = { ...this.data, ...this.purchaseForm.value };
      this.purchaseService.editPurchase(this.data.id!, updated).subscribe(() => {
        this.dialogRef.close(updated);
      });
    }
  }

  onCancel(): void {
    this.dialogRef.close();
  }

}