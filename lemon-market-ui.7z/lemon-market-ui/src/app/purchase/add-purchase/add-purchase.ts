import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { debounceTime, map, Observable, of, startWith, switchMap } from 'rxjs';
import { PurchaseDto, PurchaseService } from '../service/purchase-service';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatTableModule } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';
import { MatOptionModule } from '@angular/material/core';
import { CustomerDto, CustomerService } from '../../customer/service/add-customer.service';
import { FarmerService } from '../../farmer/service/FarmerService';
import { FarmerDto } from '../../farmer/model/FarmerDto';

@Component({
  selector: 'app-add-purchase',
  imports: [CommonModule,
    ReactiveFormsModule,
    RouterModule,
    MatPaginatorModule,
    MatTableModule,
    MatIconModule,
    MatAutocompleteModule,
    MatOptionModule
  ],
  templateUrl: './add-purchase.html',
  styleUrl: './add-purchase.css'
})
export class AddPurchase {
purchaseForm!: FormGroup;
  isFormVisible = true;

  farmerCtrl = new FormControl('');
  filteredFarmers!: Observable<FarmerDto[]>;
  selectedFarmer: FarmerDto | null = null;
  lemonTypes: string[] = ['FRESH', 'SECOND_QUALITY'];

  constructor(private fb: FormBuilder, private purchaseService: PurchaseService,private router: Router, private farmerService:FarmerService) {}

  ngOnInit(): void {
     this.purchaseForm = this.fb.group({
      farmerId: [null],
      quality: [null],
      weight: [''],
      pricePerKg: [null],
      commission: [null],
      transportCharge: [null],
      transportDistance: [null],
      vehicleNumber: [''],
      bags: [null],
      date: [''],
      finalAmount: [null]
    });

    this.filteredFarmers = this.farmerCtrl.valueChanges.pipe(
      debounceTime(300),
      startWith(''),
      switchMap(value => this._filterFarmers(value ?? ''))
    );
  }
   private _filterFarmers(value: string): Observable<FarmerDto[]> {
    if (typeof value !== 'string' || value.trim().length < 2) {
      return of([]);
    }
    return this.farmerService.searchFarmers(value.trim()).pipe(
  map(farmers=>farmers) 
);

  }
   displayFarmer(farmer: FarmerDto): string {
    return farmer ? `${farmer.firstName} ${farmer.lastName}` : '';
  }
  onFarmerSelected(farmer: FarmerDto): void {
    this.selectedFarmer = farmer;
    this.purchaseForm.patchValue({ farmerId: farmer.id });
  }


  closePurchaseModal(): void {
    this.isFormVisible = false;
    this.router.navigate(['/layout/purchase']);
  }

  onSubmit(): void {
   const purchaseData: PurchaseDto = {
      ...this.purchaseForm.value, 
      farmer: {
        id: this.purchaseForm.value.farmerId,
      }
    };
    this.purchaseService.createPurchase(purchaseData).subscribe(
      (response) => {
        if (response.id != null) {
          this.printInvoice(response.id);
        } else {
          console.error('purchase ID is missing in the response');
        }
        this.closePurchaseModal(); 
         this.router.navigate(['/layout/purchase']);
      },
      (error) => {
        console.error('Error creating sale', error);
      }
    );
  }
  downloadInvoice(purchaseId: number): void {
  this.purchaseService.invoiceDownload(purchaseId).subscribe(blob => {
    const file = new Blob([blob], { type: 'application/pdf' });
    const url = window.URL.createObjectURL(file);

    const a = document.createElement('a');
    a.href = url;
    a.download = `invoice_${purchaseId}.pdf`; 
    a.click();

    window.URL.revokeObjectURL(url); 
  });
}
printInvoice(purchaseId: number): void
{
  this.purchaseService.invoiceDownload(purchaseId).subscribe(blob => {
  const file = new Blob([blob], { type: 'application/pdf' });
  const url = URL.createObjectURL(file);

  const iframe = document.createElement('iframe');
  iframe.style.display = 'none';
  iframe.src = url;

  iframe.onload = () => {
    iframe.contentWindow?.focus();
    iframe.contentWindow?.print();
  };

  document.body.appendChild(iframe);
});
}
}
