import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { PaginatedResponse } from "../../customer/service/add-customer.service";

export interface Farmer {
  id: number;
  firstName: string;
  lastName: string;
  phoneNumber: string;
  address: string;
  email: string;
}
// Sale data interface (request & response)
export interface PurchaseDto {
  id?: number,
  weight: number;
  pricePerKg: number;
  transportDistance: number;
  vehicleNumber: string;
  bags: number;
  createdBy: string;
  farmer: Farmer;
  purchaseAmount: number;
  commission: number;
  transportCharge: number;
  finalAmount: number;
  creationDate:Date;
  quality: string;
}


@Injectable({
  providedIn: 'root'
})
export class PurchaseService {
  private apiUrl = 'http://localhost:9090/api/purchase';

  constructor(private http: HttpClient) {}

  createPurchase(purchaseData: PurchaseDto): Observable<PurchaseDto> {
    return this.http.post<PurchaseDto>(this.apiUrl, purchaseData);
  }

  getPurchases(pageIndex: number, pageSize: number): Observable<PaginatedResponse<PurchaseDto>> {
    return this.http.get<PaginatedResponse<PurchaseDto>>(
      `${this.apiUrl}?pageIndex=${pageIndex}&pageSize=${pageSize}`
    );
  }
  editPurchase(purchaseId: number, saleData: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/${purchaseId}`, saleData);
  }

   deletePurchase(purchaseId: string): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${purchaseId}`);
  }

  invoiceDownload(purchaseId: number): Observable<Blob> {
    return this.http.get(`${this.apiUrl}/${purchaseId}/invoice`, {
    responseType: 'blob'
  });
}

}
