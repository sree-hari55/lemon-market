// This represents the data we SEND to the backend
export interface ShipmentRequestDto {
  weight: number;
  pricePerKg: number;
  transportDistance: number;
  vehicleNumber: string;
  // user: UserDto; // We'll add this later
}

// This represents the full Shipment object we GET BACK from the backend
export interface Shipment extends ShipmentRequestDto {
  id: number; // Assuming the backend adds an ID
  saleAmount: number;
  commission: number;
  transportCharge: number;
  finalAmount: number;
}