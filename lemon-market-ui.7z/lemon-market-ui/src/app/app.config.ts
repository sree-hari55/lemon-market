import { ApplicationConfig, provideBrowserGlobalErrorListeners, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';
import { routes } from './app.routes'; 
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { authInterceptor } from './http-client-interceptor';
import { provideNgxWebstorage } from 'ngx-webstorage';

export const appConfig: ApplicationConfig = {
  providers: [
    provideHttpClient(),
    provideBrowserGlobalErrorListeners(),  // Set up global error handling
    provideZoneChangeDetection({ eventCoalescing: true }),  // Optimize change detection
    provideRouter(routes),  // Provide router with routes
    provideNgxWebstorage(),
  ]
};
