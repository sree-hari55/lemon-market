import { Component } from '@angular/core';
import { Sale } from './models/sale.model';
import { SalesService } from './services/sales.service';
import { Router, RouterModule } from '@angular/router';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { FormsModule } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { CreateSale } from './create-sale/create-sale';

@Component({
  selector: 'app-sales',
  standalone: true,
  imports: [   CommonModule,
    RouterModule,
    MatTableModule,
    MatPaginatorModule,
    MatButtonModule,
    MatIconModule,
    FormsModule],
  templateUrl: './sales.html',
  styleUrl: './sales.css'
})
export class Sales {
 isCreateRoute: boolean = false;
displayedSales: Sale[] = [];
  displayedColumns: string[] = [
    'saleDate',
    'customer',
    'quality',
    'quantityKg',
    'unitPrice',
    'amount',
    'status',
    'actions',
  ];

  pageSize = 10;
  pageIndex = 1;
  totalResult = 0;

  constructor(private saleService: SalesService, private router: Router,private dialog: MatDialog) {}

  ngOnInit(): void {
    this.loadSales();
  }

  loadSales(): void {
    this.saleService.list(this.pageIndex - 1, this.pageSize).subscribe({
      next: (res) => {
      this.displayedSales = res.results;   // ✅ Must match the key `results` from your JSON
      this.totalResult = res.totalResult;
      },
      error: (err) => {
        console.error('Failed to load sales:', err);
      },
    });
  }

  onPageChange(event: PageEvent): void {
    this.pageSize = event.pageSize;
    this.pageIndex = event.pageIndex + 1;
    this.loadSales();
  }

  editSale(sale: Sale): void {
    this.router.navigate(['/sales/edit', sale.id]);
  }

  deleteSale(id: number): void {
    if (confirm('Are you sure you want to delete this sale?')) {
      this.saleService.delete(id).subscribe({
        next: () => this.loadSales(),
        error: (err) => console.error('Delete failed:', err),
      });
    }
  }
  openCreateSaleDialog(): void {
  const dialogRef = this.dialog.open(CreateSale, {
    width: '600px',
  maxHeight: '80vh',
  disableClose: true,
  });

  dialogRef.afterClosed().subscribe(result => {
    if (result === 'success') {
      this.loadSales(); // refresh the list
    }
  });
}
}
