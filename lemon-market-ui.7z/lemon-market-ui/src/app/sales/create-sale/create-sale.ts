import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { SalesService } from '../services/sales.service';
import { Router, RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { CommonModule } from '@angular/common';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule, MatOptionModule } from '@angular/material/core';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDialogModule } from '@angular/material/dialog';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatTableModule } from '@angular/material/table';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { debounceTime, map, Observable, of, startWith, switchMap } from 'rxjs';
import { Sale } from '../models/sale.model';
import { CustomerDto, CustomerService } from '../../customer/service/add-customer.service';

@Component({
  selector: 'app-create-sale',
  standalone: true,
  imports: [CommonModule,
    ReactiveFormsModule,
    RouterModule,
    MatPaginatorModule,
    MatTableModule,
    MatIconModule,
    MatAutocompleteModule,
    MatOptionModule],
  templateUrl: './create-sale.html',
  styleUrl: './create-sale.css'
})
export class CreateSale {
saleForm!: FormGroup;
  isFormVisible = true;

  customerCtrl = new FormControl('');
  filteredCustomer!: Observable<CustomerDto[]>;
  selectedCustomer: CustomerDto | null = null;
  lemonTypes: string[] = ['FRESH', 'SECOND_QUALITY'];

  constructor(private fb: FormBuilder, private saleService: SalesService,private router: Router, private customerService:CustomerService) {}

  ngOnInit(): void {
     this.saleForm = this.fb.group({
      customerId: [null],
      quality: [null],
      quantityKg: [null],
      unitPrice: [null],
      vehicleNumber: [''],
      location:[''],

    });
    this.filteredCustomer = this.customerCtrl.valueChanges.pipe(
      debounceTime(300),
      startWith(''),
      switchMap(value => this._filterCustomers(value ?? ''))
    );
  }
   private _filterCustomers(value: string): Observable<CustomerDto[]> {
    if (typeof value !== 'string' || value.trim().length < 2) {
      return of([]);
    }
    return this.customerService.searchCustomers(value.trim()).pipe(
  map(customers=>customers) 
);

  }
   displayCustomer(customers: CustomerDto): string {
    return customers ? `${customers.firstName} ${customers.lastName}` : '';
  }
  onCustomerSelected(customer: CustomerDto): void {
    this.selectedCustomer = customer;
    this.saleForm.patchValue({ customerId: customer.id });
  }


  closeSaleModal(): void {
    this.isFormVisible = false;
    this.router.navigate(['/layout/sale']);
  }

  onSubmit(): void {
   const saleData: Sale = {
      ...this.saleForm.value
    };
    this.saleService.create(saleData).subscribe(
      (response) => {
        alert('Sale created successfully');
        if (response.id != null) {
         // this.printInvoice(response.id);
          this.router.navigate(['/layout/sale']);
        } else {
          console.error('Sale ID is missing in the response');
        }
      
      },
      (error) => {
        console.error('Error creating sale', error);
        const backendMsg = error?.error?.message || 'Unknown error occurred';
         alert(`❗ ${backendMsg}`);
      }
    );
  }

}
