export interface Sale {
  id?: number;
  quality: string;
  creationDate: string;        // YYYY-MM-DD or ISO
  location: string;
  paymentStatus?: string;
  quantityKg: number;
  unitPrice: number;
  status?: string;
  createdBy?: string;
  bags?: number;
  vehicleNumber?: string;
  amount?: number;
  customerId?: number;  
  customerName: string;    
}

export interface SalePage<T> {
  totalResult: number;
  pageIndex: number;
  itemsPerPage: number;
  results: T[];
}
