import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { PaymentData } from '../models/report-model';

@Component({
  selector: 'app-payment-report',
  imports: [CommonModule, MatTableModule, MatCardModule],
  templateUrl: './payment-report.html',
  styleUrl: './payment-report.css'
})
export class PaymentReport {
 displayedColumns: string[] = ['date', 'partyName', 'amount', 'paymentType', 'notes'];

  dataSource: PaymentData[] = [
    {
      date: 'Sep 30',
      partyName: 'Supplier A',
      amount: '₹8,000',
      paymentType: 'Bank Transfer',
      notes: 'Advance for lemons',
    },
    {
      date: 'Oct 01',
      partyName: 'Retail Shop B',
      amount: '₹5,000',
      paymentType: 'Cash',
      notes: 'Final settlement',
    }
  ];
}