import { Component, OnInit } from '@angular/core';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { PurchaseData } from '../models/report-model';
import { ReportService } from '../service/report-service';

@Component({
  selector: 'app-purchase-report',
  standalone: true,
  imports: [CommonModule, MatTableModule, MatCardModule, MatPaginatorModule],
  templateUrl: './purchase-report.html',
  styleUrl: './purchase-report.css'
})
export class PurchaseReport implements OnInit {
  displayedColumns: string[] = ['date', 'lemonType', 'location', 'totalQty', 'avgRate', 'totalCost'];
  dataSource: PurchaseData[] = [];

  pageSize = 10;
  pageIndex = 0;
  totalRecords = 0;

  constructor(private service: ReportService) {}

  ngOnInit(): void {
    this.loadPurchaseSummary();
  }

  loadPurchaseSummary(): void {
    this.service.getPurchaseSummary(this.pageIndex, this.pageSize).subscribe({
      next: (result) => {
        this.dataSource = result.data;
        this.totalRecords = result.total;
      },
      error: (err) => {
        console.error('Failed to load purchase summary', err);
      }
    });
  }

  onPageChange(event: PageEvent): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.loadPurchaseSummary();
  }
}
