import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { ProfitData } from '../models/report-model';

@Component({
  selector: 'app-profit-report',
  imports: [CommonModule, MatTableModule, MatCardModule],
  templateUrl: './profit-report.html',
  styleUrl: './profit-report.css'
})
export class ProfitReport {
displayedColumns: string[] = ['date', 'totalPurchase', 'totalSales', 'profit', 'notes'];

  dataSource: ProfitData[] = [
    {
      date: 'Sep 30',
      totalPurchase: '₹12,000',
      totalSales: '₹15,000',
      profit: '₹3,000',
      notes: ''
    },
    {
      date: 'Oct 1',
      totalPurchase: '₹10,000',
      totalSales: '₹14,500',
      profit: '₹4,500',
      notes: ''
    }
  ];
}