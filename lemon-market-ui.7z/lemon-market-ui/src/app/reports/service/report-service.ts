import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { map, Observable } from "rxjs";
import { PaginatedResponse, PurchaseData } from "../models/report-model";

@Injectable({
  providedIn: 'root',
})
export class ReportService {
  private baseUrl = 'http://localhost:9090/api/purchase';

  constructor(private http: HttpClient) {}

  getPurchaseSummary(pageIndex: number, pageSize: number): Observable<{ data: PurchaseData[]; total: number }> {
    const params = new HttpParams()
      .set('pageIndex', pageIndex.toString())
      .set('pageSize', pageSize.toString());

    return this.http.get<PaginatedResponse<any>>(`${this.baseUrl}/purchase-summary`, { params }).pipe(
      map((response) => {
        const data: PurchaseData[] = response.results.map((item: any) => ({
          date: this.formatDate(item.date),
          lemonType: this.formatLabel(item.lemonType),
          location: this.formatLabel(item.location),
          totalQty: item.totalQuantity,
          avgRate: `₹${item.avgCost.toFixed(2)}`,
          totalCost: `₹${item.totalCost.toLocaleString('en-IN', { maximumFractionDigits: 2 })}`,
        }));
        return {
          data,
          total: response.totalResult,
        };
      })
    );
  }

  private formatDate(dateArray: number[]): string {
    const [year, month, day] = dateArray;
    const date = new Date(year, month - 1, day);
    return date.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
  }

  private formatLabel(value: string): string {
    return value.replace(/_/g, ' ').toLowerCase().replace(/\b\w/g, (char) => char.toUpperCase());
  }
}