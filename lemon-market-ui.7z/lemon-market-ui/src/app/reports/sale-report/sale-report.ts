import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { SalesData } from '../models/report-model';

@Component({
  selector: 'app-sale-report',
  imports: [CommonModule, MatTableModule, MatCardModule],
  templateUrl: './sale-report.html',
  styleUrl: './sale-report.css'
})
export class SaleReport {
 displayedColumns: string[] = ['date', 'lemonType', 'quantitySold', 'pricePerKg', 'totalAmount', 'customer'];

  dataSource: SalesData[] = [
    {
      date: 'Sep 30, 2025',
      lemonType: 'Fresh',
      quantitySold: 800,
      pricePerKg: '₹12',
      totalAmount: '₹9,600',
      customer: 'Local Market'
    },
    {
      date: 'Sep 30, 2025',
      lemonType: '2nd Quality',
      quantitySold: 400,
      pricePerKg: '₹9',
      totalAmount: '₹3,600',
      customer: 'Retail Shop'
    }
  ];
}
