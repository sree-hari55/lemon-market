export interface StockSummary {
  lemonType: string;
  location: string;
  purchased: number;
  sold: number;
  stockLeft: number;
}

export interface PaymentData {
  date: string;
  partyName: string;
  amount: string;
  paymentType: string;
  notes?: string;
}

export interface ProfitData {
  date: string;
  totalPurchase: string;
  totalSales: string;
  profit: string;
  notes?: string;
}

export interface PurchaseData {
  date: string;
  lemonType: string;
  location: string;
  totalQty: number;
  avgRate: string;
  totalCost: string;
}

export interface SalesData {
  date: string;
  lemonType: string;
  quantitySold: number;
  pricePerKg: string;
  totalAmount: string;
  customer: string;
}

export interface PaginatedResponse<T> {
  totalResult: number;
  pageIndex: number;
  itemsPerPage: number;
  results: T[];
}