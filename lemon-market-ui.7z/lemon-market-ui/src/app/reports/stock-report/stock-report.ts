import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { StockSummary } from '../models/report-model';

@Component({
  selector: 'app-stock-report',
  imports: [CommonModule, MatTableModule, MatCardModule],
  templateUrl: './stock-report.html',
  styleUrl: './stock-report.css'
})
export class StockReport {
displayedColumns: string[] = ['lemonType', 'location', 'purchased', 'sold', 'stockLeft'];

  dataSource: StockSummary[] = [
    {
      lemonType: 'Fresh',
      location: 'Warehouse',
      purchased: 5000,
      sold: 3200,
      stockLeft: 5000 - 3200,
    },
    {
      lemonType: '2nd Quality',
      location: 'Shop',
      purchased: 3000,
      sold: 2800,
      stockLeft: 3000 - 2800,
    }
  ];
}