import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';import { CommonModule } from '@angular/common';
import { MatSnackBar } from '@angular/material/snack-bar';
import { debounceTime, map, Observable, of, startWith, switchMap } from 'rxjs';
import { MatInputModule } from '@angular/material/input';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { FarmerDto } from '../../farmer/model/FarmerDto';
import { FarmerService } from '../../farmer/service/FarmerService';
import { FarmerPaymentService } from '../service/farmer-payment.service';
import { FarmerAdvancePayDto } from '../model/farmer-payment';

@Component({
  selector: 'app-add-advance-payment',
  imports: [ReactiveFormsModule,CommonModule,MatInputModule,MatAutocompleteModule],
  standalone: true,
  templateUrl: './add-advance-payment.html',
  styleUrl: './add-advance-payment.css'
})
export class AddAdvancePayment {
paymentTypes: string[] = ['Cash', 'Credit Card', 'Online', 'Bank Transfer']; 
  selectedPaymentType: string = '';
    farmers: FarmerDto[] = [];
    farmerCtrl = new FormControl('');
  filteredFarmers!: Observable<FarmerDto[]>;
  selectedFarmer: FarmerDto | null = null;
      isFormVisible = true;  
      advancePaymentForm!: FormGroup;
      
    constructor(private farmerService:FarmerService,private fb: FormBuilder,private snackBar: MatSnackBar,
      private router: Router,private paymentService:FarmerPaymentService){}

    ngOnInit(): void {
       this.advancePaymentForm = this.fb.group({
        paymentType: [''],
         farmerId: [''],
         amount: [''], 
      });
     this.filteredFarmers = this.farmerCtrl.valueChanges.pipe(
      debounceTime(300),
      startWith(''),
      switchMap(value => this._filterFarmers(value ?? ''))
    );
    }
    private _filterFarmers(value: string): Observable<FarmerDto[]> {
    if (typeof value !== 'string' || value.trim().length < 2) {
      // Don't search for less than 2 chars
      return of([]);
    }
    return this.farmerService.searchFarmers(value.trim()).pipe(
  map(farmers => farmers)  // or simply remove map entirely if it's already CustomerDto[]
);

  }
   displayFarmer(farmer: FarmerDto): string {
    return farmer ? `${farmer.firstName} ${farmer.lastName}` : '';
  }
  onFarmerSelected(farmer: FarmerDto): void {
    this.selectedFarmer = farmer;
    this.advancePaymentForm.patchValue({ farmerId: farmer.id });
  }

  onSubmit(){
    const farmerAdvancePayDto: FarmerAdvancePayDto = {
          ...this.advancePaymentForm.value, 
          farmer: {
            id: this.advancePaymentForm.value.farmerId,
          }
        };
        console.log(farmerAdvancePayDto);
        this.paymentService.createAdvancePayment(farmerAdvancePayDto).subscribe(
          (response) => {
            this.paymentService.triggerRefresh();
            this.closeSaleModal(); 
             this.router.navigate(['/layout/farmer/payments']);
          },
          (error) => {
            console.error('Error creating sale', error);
          }
        );
  }
  showPaymentModal = false;
closeModal() : void{
    this.isFormVisible = false;
    this.router.navigate(['/layout/farmer/payments']);
  }

  onFarmerChange(event: any): void {
   const selectedFarmerId = Number(event.target.value);
   this.selectedFarmer = this.farmers.find(farmer => farmer.id === selectedFarmerId)|| null;
  }
    closeSaleModal(): void {
    this.isFormVisible = false;
    this.router.navigate(['/layout/sale']);
  }
  

}
