import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddAdvancePayment } from './add-advance-payment';

describe('AddAdvancePayment', () => {
  let component: AddAdvancePayment;
  let fixture: ComponentFixture<AddAdvancePayment>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddAdvancePayment]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddAdvancePayment);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
