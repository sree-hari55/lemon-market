import { Component, ViewChild } from '@angular/core';
import { MatPaginator, MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Router, RouterModule } from '@angular/router';
import { FarmerPaymentService } from './service/farmer-payment.service';
import { MatDialog } from '@angular/material/dialog';
import { PaymentHistory } from '../customer-payment/payment-history/payment-history';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { FormsModule } from '@angular/forms';
import { FarmerFinalPaymentDto, PaymentSummary } from './model/farmer-payment';

@Component({
  selector: 'app-farmer-payments',
  standalone: true,
  imports: [CommonModule,
    MatTableModule,
    MatButtonModule,
    MatCardModule,
    MatIconModule,
    MatInputModule,
    FormsModule,
    RouterModule,
    MatPaginatorModule,
    MatMenuModule],
  templateUrl: './farmer-payments.html',
  styleUrl: './farmer-payments.css'
})
export class FarmerPayments {
displayedColumns: string[] = ['date','name', 'advancedPayment', 'paidPayment', 'pendingPayment','totalPayment'];
  dataSource = new MatTableDataSource<FarmerFinalPaymentDto>();
  totalRevenue = 0;
  pendingPayments = 0;
  totalFarmers = 0;
  totalAdvancePayments =0;
  paidPayment =0;
  searchQuery = '';
  pageIndex = 1;
  pageSize = 10;
  totalResult = 0;
  rupeeSymbol = '\u20B9';


  @ViewChild(MatPaginator) paginator!: MatPaginator;

  constructor(private router:Router,private farmerPaymentService: FarmerPaymentService,private dialog: MatDialog) {}
  ngAfterViewInit(): void {
  this.dataSource.paginator = this.paginator;
}
  ngOnInit(): void {
    this.loadPayments();
    this.loadPaymentSummary();
    this.farmerPaymentService.refreshNeeded.subscribe(() => {
      this.loadPayments();
      this.loadPaymentSummary();
    });
  }
  loadPayments() {
    this.farmerPaymentService.getFinalPayments(this.pageIndex,this.pageSize).subscribe({
      next: (data) => {
        this.dataSource.data = data.results;
        this.totalResult = data.totalResult;
        this.pageIndex = data.pageIndex;
      },
      error: (err) => {
        console.error('Failed to load customer data', err);
      },
    });
  }
  onPageChange(event: PageEvent) {
  this.pageIndex = event.pageIndex + 1; 
  this.pageSize = event.pageSize;
  this.loadPayments();
}
  loadPaymentSummary() {
    this.farmerPaymentService.getPaymentSummary().subscribe({
      next: (data: PaymentSummary) => {
        console.log(data);
        this.totalRevenue = data.totalPayments;
        this.pendingPayments = data.pendingAmount;
        this.totalFarmers = data.totalFarmers;
        this.paidPayment = data.paidPayment;
        this.totalAdvancePayments = data.totalAdvancePayments;
      },
      error: (err) => {
        console.error('Failed to load customer data', err);
      }
    });
  }

  applyFilter(): void {
    this.dataSource.filter = this.searchQuery.trim().toLowerCase();
  }

viewHistory(customer: any, type: 'advance' | 'paid'): void {
  const customerId = customer.customer.id;

  if (!customerId) {
    console.error('Invalid customer object or missing ID');
    return;
  }

  const historyObservable =
    type === 'advance'
      ? this.farmerPaymentService.getCustomerAdvancePayhistroy(customerId)
      : this.farmerPaymentService.getCustomerPayhistroy(customerId);

  historyObservable.subscribe({
    next: (history) => {
      this.dialog.open(PaymentHistory, {
        width: '800px',
        data: {
          customer,
          type,
          history
        }
      });
    },
    error: (err) => {
      console.error(`Error fetching ${type} payment history:`, err);
      // optionally show an error message on UI
    }
  });
}

}
