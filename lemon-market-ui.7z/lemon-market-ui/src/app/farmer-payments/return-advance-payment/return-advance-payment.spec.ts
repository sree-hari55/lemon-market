import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReturnAdvancePayment } from './return-advance-payment';

describe('ReturnAdvancePayment', () => {
  let component: ReturnAdvancePayment;
  let fixture: ComponentFixture<ReturnAdvancePayment>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ReturnAdvancePayment]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ReturnAdvancePayment);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
