import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { CustomerDto, CustomerService } from '../../customer/service/add-customer.service';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { debounceTime, map, Observable, of, startWith, switchMap } from 'rxjs';
import { MatInputModule } from '@angular/material/input';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { FarmerDto } from '../../farmer/model/FarmerDto';
import { FarmerService } from '../../farmer/service/FarmerService';
import { FarmerPaymentService } from '../service/farmer-payment.service';
import { ReturnAdvancePayDto } from '../model/farmer-payment';

@Component({
  selector: 'app-return-advance-payment',
  imports: [ReactiveFormsModule,CommonModule,MatInputModule,MatAutocompleteModule],
  standalone: true,
  templateUrl: './return-advance-payment.html',
  styleUrl: './return-advance-payment.css'
})
export class ReturnAdvancePayment {
paymentTypes: string[] = ['Cash', 'Credit Card', 'Online', 'Bank Transfer']; 
  selectedPaymentType: string = '';
    farmers: FarmerDto[] = [];
   farmerCtrl = new FormControl('');
  filteredFarmers!: Observable<FarmerDto[]>;
  selectedFarmer: FarmerDto | null = null;
      isFormVisible = true;  
      advanceReturnPaymentForm!: FormGroup;
      
    constructor(private farmerService:FarmerService,private fb: FormBuilder,private router: Router,private paymentService:FarmerPaymentService,private snackBar: MatSnackBar){}

    ngOnInit(): void {
       this.advanceReturnPaymentForm = this.fb.group({
        paymentType: [''],
         farmerId: [''],
         amount: [''], 
      });
      this.filteredFarmers = this.farmerCtrl.valueChanges.pipe(
      debounceTime(300),
      startWith(''),
      switchMap(value => this._filterFarmers(value ?? ''))
    );
    }
    private _filterFarmers(value: string): Observable<CustomerDto[]> {
    if (typeof value !== 'string' || value.trim().length < 2) {
      // Don't search for less than 2 chars
      return of([]);
    }
    return this.farmerService.searchFarmers(value.trim()).pipe(
  map(farmers => farmers)  // or simply remove map entirely if it's already CustomerDto[]
);

  }
   displayFarmer(farmer: FarmerDto): string {
    return farmer ? `${farmer.firstName} ${farmer.lastName}` : '';
  }
  onFarmerSelected(farmer: FarmerDto): void {
    this.selectedFarmer = farmer;
    this.advanceReturnPaymentForm.patchValue({ farmerId: farmer.id });
  }

  onSubmit(){
    const advanceReturnPayDto: ReturnAdvancePayDto = {
          ...this.advanceReturnPaymentForm.value, 
          farmer: {
            id: this.advanceReturnPaymentForm.value.farmerId,
          }
        };
        this.paymentService.createReturnAdvancePayment(advanceReturnPayDto).subscribe(
          (response) => {
            this.closeSaleModal(); 
             this.paymentService.triggerRefresh();
             this.router.navigate(['/layout/farmer/payments']);
          },
          (error) => {
           const errorMessage =
        error?.error?.message || 'Something went wrong. Please try again.';
      this.snackBar.open(errorMessage, 'Close', {
        duration: 5000,
        verticalPosition: 'top',
        panelClass: ['snackbar-error'], 
      });
          }
        );
  }
  showPaymentModal = false;
closeModal() : void{
    this.isFormVisible = false;
    this.router.navigate(['/layout/farmer/payments']);
  }

  onFarmerChange(event: any): void {
   const selectedFarmerId = Number(event.target.value);
   this.selectedFarmer = this.farmers.find(farmer => farmer.id === selectedFarmerId)|| null;
  }
    closeSaleModal(): void {
    this.isFormVisible = false;
    this.router.navigate(['/layout/sale']);
  }
  

}
