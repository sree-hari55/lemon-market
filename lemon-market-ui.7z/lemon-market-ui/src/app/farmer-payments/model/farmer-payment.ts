import { FarmerDto } from "../../farmer/model/FarmerDto";

export interface FarmerFinalPaymentDto {
  id: number;
  advancePayment: number;
  paidPayment: number;
  totalPayment: number;
  pendingPayment: number;
  createdDate: Date;
  modifiedDate:Date;
  farmerDto: FarmerDto;
}
export interface FarmerPaymentDto{
  id: number;
  paymentType: number;
  amount: number;
  createdDate: Date;
  modifiedDate:Date;
  farmer:FarmerDto
} 

export interface FarmerAdvancePayDto{
  id: number;
  paymentType: number;
  amount: number;
  createdDate: Date;
  modifiedDate:Date;
  farmer:FarmerDto
} 

export interface ReturnAdvancePayDto{
  id: number;
  paymentType: number;
  amount: number;
  createdDate: Date;
  modifiedDate:Date;
  farmer:FarmerDto
}
export interface PaymentSummary{
  totalFarmers: number;
  paidPayment: number;
  totalPayments: number;
  pendingAmount: number;
  totalAdvancePayments: number;
}

export interface FarmerResponsePaymentDto{
id: number;
paymentType: string;
narration: string;
withdrawalAmount:number;
depositAmount: number;
closingBalance:number;
createdDate: Date;
modifiedDate:Date;
 farmer:FarmerDto
}

export interface FarmerPaymentFilterDto {
  farmerID?: number;
  farmerFirstName?: string;
  farmerLastName?: string;
  paymentType?: string;
  fromDate?: string; // use ISO string for date/time
  toDate?: string;
}