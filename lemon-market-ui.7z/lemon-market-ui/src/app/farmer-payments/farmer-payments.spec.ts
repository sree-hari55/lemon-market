import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FarmerPayments } from './farmer-payments';

describe('FarmerPayments', () => {
  let component: FarmerPayments;
  let fixture: ComponentFixture<FarmerPayments>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FarmerPayments]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FarmerPayments);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
