import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { Observable, Subject, tap } from 'rxjs';
import { PaginatedResponse } from '../../farmer/model/FarmerDto';
import { CustomerPayDto } from '../../customer-payment/customer-payment.service';
import { FarmerAdvancePayDto, FarmerFinalPaymentDto, FarmerPaymentDto, FarmerPaymentFilterDto, FarmerResponsePaymentDto, PaymentSummary, ReturnAdvancePayDto } from '../model/farmer-payment';


@Injectable({
  providedIn: 'root',
})
export class FarmerPaymentService {
  private apiUrl = 'http://localhost:9090/api/farmer/final-payments';
  private addPaymentUrl ='http://localhost:9090/api/farmer-payment';
  private addAdvancePaymentUrl ='http://localhost:9090/api/farmer/advance-payments';
  private returnAdvancePaymentUrl ='http://localhost:9090/api/farmer/advance-payments/return';
  private paymentHistroyUrl ='http://localhost:9090/api/customer-pay/customers';
  private paymentSummaryUrl ='http://localhost:9090/api/farmer/final-payments/summary';
  private filterNormalPaymentsUrl ='http://localhost:9090/api/farmer-payment/filter';
  private filterAdvancePaymentsUrl ='http://localhost:9090/api/farmer/advance-payments/filter';
  private downloadPaymentReportUrl ='http://localhost:9090/api/farmer-payment/download';
  private downloadAdvancePaymentReportUrl ='http://localhost:9090/api/farmer/advance-payments/download';
  private _refreshNeeded = new Subject<void>();
refreshNeeded = this._refreshNeeded.asObservable();

triggerRefresh() {
  this._refreshNeeded.next();
}


  constructor(private http: HttpClient) {}

  getFinalPayments(pageIndex: number, pageSize: number): Observable<PaginatedResponse<FarmerFinalPaymentDto>> {
    return this.http.get<PaginatedResponse<FarmerFinalPaymentDto>>(
      `${this.apiUrl}?pageIndex=${pageIndex}&pageSize=${pageSize}`
    );
  }
  createPayment(dto: FarmerPaymentDto): Observable<FarmerPaymentDto> {
    return this.http.post<FarmerPaymentDto>(this.addPaymentUrl, dto);
  }

  createAdvancePayment(dto: FarmerAdvancePayDto): Observable<FarmerAdvancePayDto> {
    return this.http.post<FarmerAdvancePayDto>(this.addAdvancePaymentUrl, dto);
  }

   createReturnAdvancePayment(dto: ReturnAdvancePayDto): Observable<ReturnAdvancePayDto> {
    return this.http.post<ReturnAdvancePayDto>(this.returnAdvancePaymentUrl, dto);
  }

  getCustomerPayhistroy(customerId:number): Observable<CustomerPayDto[]>{
    const url = `${this.paymentHistroyUrl}/${customerId}`;
    return this.http.get<CustomerPayDto[]>(url);
  }
  getCustomerAdvancePayhistroy(customerId:number): Observable<CustomerPayDto[]>{
    const url = `${this.addAdvancePaymentUrl}/${customerId}`;
    return this.http.get<CustomerPayDto[]>(url);
  }

  getPaymentSummary(): Observable<PaymentSummary> {
    return this.http.get<PaymentSummary>(this.paymentSummaryUrl);
  }

filterNormalCustomerPayments(filterDto: FarmerPaymentFilterDto, pageIndex: number = 0, pageSize: number = 10): Observable<PaginatedResponse<FarmerResponsePaymentDto>> {
    const params = new HttpParams()
      .set('pageIndex', pageIndex.toString())
      .set('pageSize', pageSize.toString());

    return this.http.post<PaginatedResponse<FarmerResponsePaymentDto>>(this.filterNormalPaymentsUrl, filterDto, { params });
  }

  filterAdvanceCustomerPayments(filterDto: FarmerPaymentFilterDto, pageIndex: number = 0, pageSize: number = 10): Observable<PaginatedResponse<FarmerResponsePaymentDto>> {
    const params = new HttpParams()
      .set('pageIndex', pageIndex.toString())
      .set('pageSize', pageSize.toString());

    return this.http.post<PaginatedResponse<FarmerResponsePaymentDto>>(this.filterAdvancePaymentsUrl, filterDto, { params });
  }
downloadCustomerPaymentReportFile(filterDto: FarmerPaymentFilterDto, fileType: string): Observable<HttpResponse<Blob>> {
  return this.http.post(`${this.downloadPaymentReportUrl}?fileType=${fileType}`, filterDto, {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
    responseType: 'blob',
    observe: 'response'
  });
}


downloadAdvanceCustomerPaymentReportFile(filterDto: FarmerPaymentFilterDto, fileType: string): Observable<HttpResponse<Blob>> {
  return this.http.post(`${this.downloadAdvancePaymentReportUrl}?fileType=${fileType}`, filterDto, {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
    responseType: 'blob',
    observe: 'response'
  });
}


}
