import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentHistroy } from './payment-histroy';

describe('PaymentHistroy', () => {
  let component: PaymentHistroy;
  let fixture: ComponentFixture<PaymentHistroy>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PaymentHistroy]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PaymentHistroy);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
