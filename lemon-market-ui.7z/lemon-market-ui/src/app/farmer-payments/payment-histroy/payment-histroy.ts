import { Component, ViewChild } from '@angular/core';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FarmerDto, PaginatedResponse } from '../../farmer/model/FarmerDto';
import { debounceTime, map, Observable, of, startWith, switchMap } from 'rxjs';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { FarmerService } from '../../farmer/service/FarmerService';
import { FarmerPaymentService } from '../service/farmer-payment.service';
import { HttpResponse } from '@angular/common/http';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { FarmerResponsePaymentDto } from '../model/farmer-payment';

@Component({
  selector: 'app-payment-histroy',
  standalone: true,
  imports:  [MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatButtonModule,
    MatCardModule,
    MatIconModule,
    MatTableModule,
    FormsModule,
    CommonModule,
    ReactiveFormsModule,
    MatAutocompleteModule,
    MatPaginatorModule],
  templateUrl: './payment-histroy.html',
  styleUrl: './payment-histroy.css'
})
export class PaymentHistroy {
  farmerCtrl = new FormControl('');
  fromDate: Date | null = null;
  toDate: Date | null = null;
  paymentType = '';
  farmers: FarmerDto[] = [];
  filteredFarmers!: Observable<FarmerDto[]>;
  selectedFarmer: FarmerDto | null = null;
  selectedSearch='';
  fromDateCtrl = new FormControl('');
  toDateCtrl = new FormControl('');
  typeCtrl = new FormControl('');
  pageIndex = 1;
  pageSize = 10;
  totalResults = 0;


displayedColumns: string[] = ['createdDate', 'paymentType', 'depositAmount', 'withdrawalAmount', 'closingBalance'];
  dataSource = new MatTableDataSource<FarmerResponsePaymentDto>([]);

@ViewChild(MatPaginator) paginator!: MatPaginator;

//dataSource = new MatTableDataSource<any>([]); 

  constructor(private farmerService:FarmerService, private farmerPaymentService: FarmerPaymentService){}

  ngOnInit(): void {
    this.filteredFarmers = this.farmerCtrl.valueChanges.pipe(
      debounceTime(300),
      startWith(''),
      switchMap(value => this._filterFarmers(value ?? ''))
    );
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }
   private _filterFarmers(value: string): Observable<FarmerDto[]> {
      if (typeof value !== 'string' || value.trim().length < 2) {
           return of([]);
      }
      return this.farmerService.searchFarmers(value.trim()).pipe(
       map(farmers => farmers) 
     );   
   }

  displayFarmer(farmer: FarmerDto): string {
    return farmer ? `${farmer.firstName} ${farmer.lastName}` : '';
  }

  onFarmerSelected(farmer: FarmerDto): void {
    this.selectedFarmer = farmer;
  }

  clearFilters() {
    this.farmerCtrl.reset();
    this.fromDateCtrl.reset();
    this.toDateCtrl.reset();
    this.typeCtrl.reset();
  }
  onPageChange(event: PageEvent) {
  this.pageIndex = event.pageIndex + 1; 
  this.pageSize = event.pageSize;
}

  applyFilter() {
 const filters: any = {};
  const farmer = this.farmerCtrl.value;
  const fromDate = this.fromDateCtrl.value;
  const toDate = this.toDateCtrl.value;
  const type = this.typeCtrl.value;

  if (!farmer || typeof farmer !== 'object') {
    console.warn('[PaymentHistory] Invalid farmer selection');
    return;
  }
  const dto = farmer as FarmerDto;
    filters.farmerID = dto.id;
    filters.farmerFirstName = dto.firstName;
    filters.farmerLastName = dto.lastName;
   if (fromDate) filters.fromDate = new Date(fromDate).toISOString();
  if (toDate) filters.toDate = new Date(toDate).toISOString();
  if (type) filters.paymentType = type;

   const serviceCall = this.getPaymentServiceMethod(type);
   if (!serviceCall) {
    console.warn(`[PaymentHistory] Unsupported payment type: ${type}`);
    return;
  }
  serviceCall(filters, this.pageIndex, this.pageSize).subscribe({
    next: (response: PaginatedResponse<FarmerResponsePaymentDto>) => {
      this.dataSource.data = response.results; 
      this.paginator.length = response.totalResult;
    },
    error: (err) => {
      console.error('[PaymentHistory] Failed to fetch filtered payments:', err);
    }
  });
  }
  private getPaymentServiceMethod(type: string | null): ((f: any, p: number, s: number) => Observable<PaginatedResponse<FarmerResponsePaymentDto>>) | null {
  switch (type) {
    case 'Normal':
      return this.farmerPaymentService.filterNormalCustomerPayments.bind(this.farmerPaymentService);
    case 'Advance':
      return this.farmerPaymentService.filterAdvanceCustomerPayments.bind(this.farmerPaymentService);
    default:
      return null;
  }
}
  
  downloadCSV() {
    console.log('Download CSV');
  }

downloadPDF(): void {
  const filters: any = {};
  const farmer = this.farmerCtrl.value;
  const fromDate = this.fromDateCtrl.value;
  const toDate = this.toDateCtrl.value;
  const type = this.typeCtrl.value;

  if (!farmer || typeof farmer !== 'object') {
    console.warn('[PaymentHistory] Invalid farmer selection');
    return;
  }

  const dto = farmer as FarmerDto;
  filters.farmerID = dto.id;
  filters.farmerFirstName = dto.firstName;
  filters.farmerLastName = dto.lastName;
  if (fromDate) filters.fromDate = new Date(fromDate).toISOString();
  if (toDate) filters.toDate = new Date(toDate).toISOString();
  if (type) filters.paymentType = type;

  // 👇 Update the observable type to HttpResponse<Blob>
  let request$: Observable<HttpResponse<Blob>>;
  if (type === 'Normal') {
    request$ = this.farmerPaymentService.downloadCustomerPaymentReportFile(filters, 'PDF');
  } else if (type === 'Advance') {
    request$ = this.farmerPaymentService.downloadAdvanceCustomerPaymentReportFile(filters, 'PDF');
  } else {
    console.warn('Invalid payment type');
    return;
  }

  request$.subscribe({
    next: (response: HttpResponse<Blob>) => {
      const blob = response.body!;
      const contentType = blob.type;

      if (contentType !== 'application/pdf') {
        console.error('Downloaded blob is not a PDF');
        blob.text().then(text => console.log('Response content:', text));
        return;
      }

      const contentDisposition = response.headers.get('Content-Disposition');
      let filename = `Customer-Payment-Report-${type}-${new Date().toISOString().split('T')[0]}.pdf`;

      if (contentDisposition) {
        const matches = /filename="?([^"]+)"?/.exec(contentDisposition);
        if (matches?.[1]) {
          filename = matches[1];
        }
      }

      const fileURL = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = fileURL;
      a.download = filename;

      document.body.appendChild(a);
      setTimeout(() => {
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(fileURL);
      }, 100);
    },
    error: (err) => {
      console.error('PDF download failed:', err);
    }
  });
}

  

}

