import { Component, OnInit } from '@angular/core';
import { FarmerDto } from '../../farmer/model/FarmerDto';
import { FormBuilder, FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { debounceTime, map, Observable, of, startWith, switchMap } from 'rxjs';
import { FarmerService } from '../../farmer/service/FarmerService';
import { Router, RouterModule } from '@angular/router';
import { FarmerPaymentService } from '../service/farmer-payment.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CommonModule } from '@angular/common';
import { MatInputModule } from '@angular/material/input';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { CustomerPayDto } from '../../customer-payment/customer-payment.service';
import { FarmerPaymentDto } from '../model/farmer-payment';

@Component({
  selector: 'app-add-farmer-payments',
  standalone: true,
  imports: [RouterModule,ReactiveFormsModule,CommonModule,MatInputModule,MatAutocompleteModule],
  templateUrl: './add-farmer-payments.html',
  styleUrl: './add-farmer-payments.css'
})
export class AddFarmerPayments implements OnInit{

  paymentTypes: string[] = ['Cash', 'Credit Card', 'Online', 'Bank Transfer']; 
  selectedPaymentType: string = '';
  farmers: FarmerDto[] = [];
  farmerCtrl = new FormControl('');
  filteredFarmers!: Observable<FarmerDto[]>;
  selectedFarmer: FarmerDto | null = null;
  isFormVisible = true;  
  paymentForm!: FormGroup;
      
  constructor(private farmerService:FarmerService,private fb: FormBuilder,private router: Router,private paymentService:FarmerPaymentService,private snackBar: MatSnackBar){}

  ngOnInit(): void {
    this.paymentForm = this.fb.group({
      paymentType: [''],
      farmerId: [''],
      amount: [''], 
    });
   this.filteredFarmers = this.farmerCtrl.valueChanges.pipe(
         debounceTime(300),
         startWith(''),
         switchMap(value => this._filterFarmers(value ?? ''))
       );
    }
   private _filterFarmers(value: string): Observable<FarmerDto[]> {
       if (typeof value !== 'string' || value.trim().length < 2) {
         // Don't search for less than 2 chars
         return of([]);
       }
       return this.farmerService.searchFarmers(value.trim()).pipe(
     map(farmer => farmer)  
   );
   
     }
      displayFarmer(farmer: FarmerDto): string {
       return farmer ? `${farmer.firstName} ${farmer.lastName}` : '';
     }
     onFarmerSelected(farmer: FarmerDto): void {
       this.selectedFarmer = farmer;
       this.paymentForm.patchValue({ farmerId: farmer.id });
     }
  onSubmit(){
    const farmerPayDto: FarmerPaymentDto = {
          ...this.paymentForm.value, // Spread sale form data
          farmer: {
            id: this.paymentForm.value.farmerId,
          }
        };
        this.paymentService.createPayment(farmerPayDto).subscribe(
          (response) => {
            this.closeSaleModal(); 
            this.paymentService.triggerRefresh();
             this.router.navigate(['/layout/farmer/payments']);
          },
          (error) => {
          const errorMessage = error?.error?.message || 'Something went wrong. Please try again.';
          this.snackBar.open(errorMessage, 'Close', {
          duration: 5000,
          verticalPosition: 'top',
          panelClass: ['snackbar-error'], 
        });
      });
  }
  

closeModal() : void{
    this.isFormVisible = false;
    this.router.navigate(['/layout/farmer/payments']);
  }

  onFarmersChange(event: any): void {
   const selectedFarmerId = Number(event.target.value);
   this.selectedFarmer = this.farmers.find(farmer => farmer.id === selectedFarmerId)|| null;
  }
    closeSaleModal(): void {
    this.isFormVisible = false;
    this.router.navigate(['/layout/farmer/payments']);
  }
  

}
