import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddFarmerPayments } from './add-farmer-payments';

describe('AddFarmerPayments', () => {
  let component: AddFarmerPayments;
  let fixture: ComponentFixture<AddFarmerPayments>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddFarmerPayments]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddFarmerPayments);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
