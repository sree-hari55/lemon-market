import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FormBuilderlistcomponent } from './form-builderlistcomponent';

describe('FormBuilderlistcomponent', () => {
  let component: FormBuilderlistcomponent;
  let fixture: ComponentFixture<FormBuilderlistcomponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FormBuilderlistcomponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FormBuilderlistcomponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
