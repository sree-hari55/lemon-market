import { Component, OnInit } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormBuilderService } from '../service/form-builder-service';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-form-builderlistcomponent',
  standalone: true,
  imports: [CommonModule,RouterModule,MatIconModule],
  templateUrl: './form-builderlistcomponent.html',
  styleUrl: './form-builderlistcomponent.css'
})
export class FormBuilderlistcomponent implements OnInit {

  forms: any[] = [];
  loading = false;

  constructor(
    private formBuilderService: FormBuilderService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadForms();
  }

  loadForms(): void {
    this.loading = true;
    this.formBuilderService.getAllForms().subscribe({
      next: (res) => {
        console.log(res)
        this.forms = res;
        this.loading = false;
      },
      error: (err) => {
        console.error('❌ Failed to load forms', err);
        this.loading = false;
      }
    });
  }

  editForm(id: number): void {
  this.router.navigate([`/form-builder/${id}`]);
  }

  deleteForm(id: number): void {
    if (confirm('Are you sure you want to delete this form?')) {
      this.formBuilderService.deleteForm(id).subscribe({
        next: () => {
          alert('✅ Form deleted successfully!');
          this.loadForms();
        },
        error: (err) => {
          console.error('❌ Failed to delete form', err);
        }
      });
    }
  }

  createForm(): void {
    this.router.navigate(['/form-builder']);
  }
previewForm(form: any): void {
  const popup = window.open('', '_blank', 'width=900,height=600');

  if (!popup) return;

  popup.document.write(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>Preview - ${form.title || 'Form'}</title>
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/formiojs/dist/formio.full.min.css">
    </head>
    <body style="padding: 20px;">
    <!--  <h2 style="text-align: center;">${form.title || 'Untitled Form'}</h2> -->
      <div id="formio"></div>
      <script src="https://cdn.jsdelivr.net/npm/formiojs/dist/formio.full.min.js"></script>
      <script>
        const schema = ${JSON.stringify(form.schemaJson)};
        Formio.createForm(document.getElementById('formio'), schema);
      </script>
    </body>
    </html>
  `);
  popup.document.close();
}

 downloadFormAsPdf(form: any): void {
  const iframe = document.createElement('iframe');
  iframe.style.position = 'fixed';
  iframe.style.width = '0';
  iframe.style.height = '0';
  iframe.style.border = 'none';
  iframe.style.visibility = 'hidden';
  document.body.appendChild(iframe);

  const doc = iframe.contentWindow?.document;
  if (!doc) return;

  const title = form.name || 'Untitled Form';

  const titleComponent = {
    type: 'htmlelement',
    key: 'formTitle',
    tag: 'h2',
    content: `<div style="text-align:center;">${title}</div>`,
    input: false,
    tableView: false
  };

  const schema = { ...form.schemaJson };

  // Insert title if not already present
  const hasTitle = schema.components?.some((c: any) => c.key === 'formTitle');
  if (!hasTitle && schema.components) {
    schema.components.unshift(titleComponent);
  }

  const html = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>${title}</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/formiojs/dist/formio.full.min.css">
  <style>
    body { padding: 20px; font-family: Arial, sans-serif; }
    h2 { text-align: center; margin-bottom: 20px; }
  </style>
</head>
<body>
  <div id="formio"></div>
  <script src="https://cdn.jsdelivr.net/npm/formiojs/dist/formio.full.min.js"></script>
  <script>
    const schema = ${JSON.stringify(schema, null, 2)};
    Formio.createForm(document.getElementById('formio'), schema)
      .then(() => {
        setTimeout(() => {
          window.focus();
          window.print();
        }, 500);
      });
  </script>
</body>
</html>
`;

  doc.open();
  doc.write(html);
  doc.close();

  iframe.onload = () => {
    if (iframe.contentWindow) {
      iframe.contentWindow.onafterprint = () => {
        document.body.removeChild(iframe);
      };
    }
  };
}

}