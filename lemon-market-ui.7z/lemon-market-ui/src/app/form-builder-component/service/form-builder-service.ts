import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FormBuilderService {
  private baseUrl = 'http://localhost:8080/api/v1/forms'; 

  constructor(private http: HttpClient) {}

  // Forms
  getAllForms(): Observable<any> {
    return this.http.get(this.baseUrl);
  }

  getForm(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/${id}`);
  }

  createForm(data: any): Observable<any> {
    return this.http.post(this.baseUrl, data);
  }

  updateForm(id: number, data: any): Observable<any> {
    return this.http.put(`${this.baseUrl}/${id}`, data);
  }

  deleteForm(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`);
  }

  // Submissions
  getFormSubmissions(formId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/${formId}/submissions`);
  }

  submitForm(formId: number, data: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/${formId}/submissions`, data);
  }
}
