import { Component, ElementRef, AfterViewInit, OnDestroy, ViewChild } from '@angular/core';
import { Formio } from 'formiojs';
import { FormBuilder } from 'formiojs';
import { CommonModule } from '@angular/common';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { FormBuilderService } from './service/form-builder-service';

@Component({
  selector: 'app-form-builder-component',
  standalone: true,
  imports: [
    CommonModule,
    MatToolbarModule,
    MatButtonModule,
    MatIconModule,
    MatProgressSpinnerModule
  ],
  templateUrl: './form-builder-component.html',
  styleUrls: ['./form-builder-component.css']
})
export class FormBuilderComponent implements AfterViewInit, OnDestroy {
  @ViewChild('builder', { static: true }) builderEl!: ElementRef;
  @ViewChild('preview', { static: true }) previewEl!: ElementRef;

  builderInstance: any;
  formSchema: any = { components: [] };
  previewVisible = false;
  formTitle: string = '';
  constructor(private formService: FormBuilderService) {}

  // Builder configuration
  builderConfig = {
    basic: { title: 'Basic Components', weight: 0, components: { text: true, number: true, textarea: true } },
    advanced: { title: 'Advanced Components', weight: 10, components: { checkbox: true, radio: true, select: true } },
    data: { title: 'Data Components', weight: 20, components: {} },
    layout: { title: 'Layout Components', weight: 30, components: {} },
    customBasic: { title: 'Custom', weight: 40, components: {} }
  };

ngAfterViewInit() {
  this.builderInstance = new FormBuilder(
    this.builderEl.nativeElement,
    {}, // Empty schema initially
    { builder: this.builderConfig }
  );

  // Wait until the actual form instance is ready
  this.builderInstance.ready.then(() => {
    this.builderInstance.instance.ready.then(() => {
      // Now the instance is ready and editable
      this.formSchema = this.builderInstance.instance.schema;

      // Update on every change
      this.builderInstance.instance.on('change', () => {
        this.formSchema = this.builderInstance.instance.schema;
        console.log('📦 Form updated:', this.formSchema);
      });
    });
  });
}



  togglePreview() {
    this.previewVisible = !this.previewVisible;
    if (this.previewVisible) this.renderPreview();
  }

  renderPreview() {
    if (!this.formSchema || !this.previewEl?.nativeElement) return;

    // Clear previous preview
    this.previewEl.nativeElement.innerHTML = '';

    Formio.createForm(this.previewEl.nativeElement, this.formSchema)
      .then((formInstance: any) => {
        formInstance.on('submit', (submission: any) => {
          console.log('Preview submitted:', submission);
        });
      })
      .catch(err => console.error('Error rendering preview:', err));
  }
saveForm() {
  if (!this.formSchema || !this.formSchema.components || this.formSchema.components.length === 0) {
    alert('⚠️ No form components to save! Drag and drop something first.');
    return;
  }

  // Ask for title if not set
  const title = prompt('Enter a title for the form:', this.formTitle || 'Untitled Form');
  if (!title) {
    alert('⚠️ Title is required to save the form.');
    return;
  }
  this.formTitle = title;

  // Add a centered HTML heading to the schema (if not already present)
  const titleComponent = {
    type: 'htmlelement',
    key: 'formTitle',
    tag: 'h2',
    content: `<div style="text-align:center;">${title}</div>`,
    input: false,
    tableView: false
  };

  const existingTitle = this.formSchema.components.find((c: any) => c.key === 'formTitle');
  if (existingTitle) {
    existingTitle.content = titleComponent.content;
  } else {
    this.formSchema.components.unshift(titleComponent);
  }

  const payload = {
    name: title,
    schemaJson: this.formSchema
  };

  this.formService.createForm(payload).subscribe({
    next: (response) => {
      console.log('✅ Form saved on backend:', response);
      alert('Form saved to backend!');
    },
    error: (err) => {
      console.error('❌ Failed to save form:', err);
      alert('Error saving form. Check console.');
    }
  });
}




publishForm(){

}
  downloadHTML() {
  if (!this.formSchema || !this.formSchema.components || this.formSchema.components.length === 0) {
    alert('⚠️ No form to print!');
    return;
  }

  // Prompt for title
  const title = prompt('Enter a title for the form:', this.formTitle || 'Untitled Form');
  if (!title) {
    alert('⚠️ Title is required for print.');
    return;
  }
  this.formTitle = title;

  // Inject or update title as HTML element
  const titleComponent = {
    type: 'htmlelement',
    key: 'formTitle',
    tag: 'h2',
    content: `<div style="text-align:center;">${title}</div>`,
    input: false,
    tableView: false
  };

  const existingTitle = this.formSchema.components.find((c: any) => c.key === 'formTitle');
  if (existingTitle) {
    existingTitle.content = titleComponent.content;
  } else {
    this.formSchema.components.unshift(titleComponent);
  }

  // Create hidden iframe for print
  const iframe = document.createElement('iframe');
  iframe.style.position = 'fixed';
  iframe.style.width = '0';
  iframe.style.height = '0';
  iframe.style.border = 'none';
  iframe.style.visibility = 'hidden';
  document.body.appendChild(iframe);

  const doc = iframe.contentWindow?.document;
  if (!doc) return;

  const html = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>${title}</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/formiojs/dist/formio.full.min.css">
  <style>
    body { padding: 20px; font-family: Arial, sans-serif; }
    h2 { text-align: center; margin-bottom: 20px; }
  </style>
</head>
<body>
  <div id="formio"></div>
  <script src="https://cdn.jsdelivr.net/npm/formiojs/dist/formio.full.min.js"></script>
  <script>
    const schema = ${JSON.stringify(this.formSchema, null, 2)};
    Formio.createForm(document.getElementById('formio'), schema)
      .then(() => {
        setTimeout(() => {
          window.focus();
          window.print();
        }, 500);
      });
  </script>
</body>
</html>
`;

  doc.open();
  doc.write(html);
  doc.close();

  iframe.onload = () => {
    if (iframe.contentWindow) {
      iframe.contentWindow.onafterprint = () => {
        document.body.removeChild(iframe);
      };
    }
  };
}
clearForm() {
  const confirmClear = confirm('⚠️ Are you sure you want to clear the form? This will remove all components.');
  if (!confirmClear) return;

  this.formSchema = { components: [] }; // Reset schema

  // Rebuild the form builder with empty schema
  if (this.builderInstance) {
    this.builderInstance.instance.destroy(true); // Clean up old instance
    this.builderInstance = null;
  }

  this.builderInstance = new FormBuilder(
    this.builderEl.nativeElement,
    {}, // fresh schema
    { builder: this.builderConfig }
  );

  this.builderInstance.ready.then(() => {
    this.builderInstance.instance.ready.then(() => {
      this.builderInstance.instance.on('change', () => {
        this.formSchema = this.builderInstance.instance.schema;
      });
    });
  });
}



  ngOnDestroy() {
    if (this.builderInstance && this.builderInstance.instance) {
      this.builderInstance.instance.destroy(true);
      this.builderInstance = null;
    }
  }
}
