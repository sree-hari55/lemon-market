import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { LocalStorageService } from 'ngx-webstorage';
import { LoginRequest, LoginResponse } from './auth.models';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private loginUrl = 'http://localhost:9090/api/admin/login';

  constructor(
    private http: HttpClient,
    private localStorage: LocalStorageService
  ) {}

  login(payload: LoginRequest): Observable<boolean> {
    return this.http.post<LoginResponse>(this.loginUrl, payload).pipe(
      map(response => {
        this.localStorage.store('authenticationToken', response.token);
        this.localStorage.store('username', response.userName);
        this.localStorage.store('img-url', response.imageUrl); 
        return true;
      })
    );
  }

  logout(): void {
    this.localStorage.clear('authenticationToken');
    this.localStorage.clear('username');
    this.localStorage.clear('img-url'); 
  }

  isAuthenticated(): boolean {
    return this.localStorage.retrieve('username') !== null;
  }

  getUsername(): string | null {
    return this.localStorage.retrieve('username');
  }

  getProfileImageUrl(): string | null {
    return this.localStorage.retrieve('img-url');
  }
}
