export interface LoginRequest {
  userName: string;
  password: string;
  marketName: string;
}

export interface LoginResponse {
  token: string;
  userName: string;
  imageUrl: string;
}
