import { Route } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { provideNgxWebstorage } from 'ngx-webstorage';
import { Customer } from './customer/customer';
import { Layout } from './dashboard/layout/layout';
import { AddCustomerComponent } from './customer/add-customer/add-customer';
import { CustomerPayment } from './customer-payment/customer-payment';
import { AddCustomerPayment } from './customer-payment/add-customer-payment/add-customer-payment';
import { Purchase } from './purchase/purchase';
import { AddPurchase } from './purchase/add-purchase/add-purchase';
import { InventoryDashboard } from './inventory/inventory-dashboard/inventory-dashboard';
import { Farmer } from './farmer/farmer';
import { AddFarmer } from './farmer/add-farmer/add-farmer';
import { Sales } from './sales/sales';
import { CreateSale } from './sales/create-sale/create-sale';
import { FarmerPayments } from './farmer-payments/farmer-payments';
import { AddFarmerPayments } from './farmer-payments/add-farmer-payments/add-farmer-payments';
import { AddAdvancePayment } from './farmer-payments/add-advance-payment/add-advance-payment';
import { ReturnAdvancePayment } from './farmer-payments/return-advance-payment/return-advance-payment';
import { PaymentHistroy } from './farmer-payments/payment-histroy/payment-histroy';
import { FormBuilderComponent } from './form-builder-component/form-builder-component';
import { FormBuilderlistcomponent } from './form-builder-component/form-builderlistcomponent/form-builderlistcomponent';
import { DestinationList } from './routes/destinations/destination-list/destination-list';
import { DestinationForm } from './routes/destinations/destination-form/destination-form';
import { RouteList } from './routes/route/route-list/route-list';
import { RouteForm } from './routes/route/route-form/route-form';
import { AcademicList } from './academic-year/academic-list/academic-list';
import { ShiftAcademic } from './academic-year/shift-academic/shift-academic';
import { AcademicYearForm } from './academic-year/academic-year-form/academic-year-form';
import { PurchaseReport } from './reports/purchase-report/purchase-report';
import { SaleReport } from './reports/sale-report/sale-report';
import { ProfitReport } from './reports/profit-report/profit-report';
import { StockReport } from './reports/stock-report/stock-report';
import { PaymentReport } from './reports/payment-report/payment-report';
import { StudentAdmissionFormComponent } from './student-desk/student-admission/student-admission';
import { StudentRegistration } from './student-desk/student-registration/student-registration';

export const routes: Route[] = [
  {path: '', component: HomeComponent, providers: [provideNgxWebstorage()]},
  {path: 'form-list', component: FormBuilderlistcomponent },

  {path: 'destination-list', component: DestinationList},
  {path: 'destination-form', component: DestinationForm },
  {path: 'route-list', component: RouteList},
  {path: 'route-form', component: RouteForm },
  {path: 'academic-list', component: AcademicList},
  { path: 'academic/create', component: AcademicYearForm },
  { path: 'academic/edit/:id', component: AcademicYearForm },
  {path: 'shit-academic-form', component: ShiftAcademic },
  {path:'student-admission', component:StudentAdmissionFormComponent},
    {path:'student-registration', component:StudentRegistration},


  {path: 'form-builder', component: FormBuilderComponent},
   { path: 'form-builder/:id', component: FormBuilderComponent },
   {
    path: 'layout',
    component: Layout,
    children: [
      {
        path: 'customers',
        component: Customer,
        children: [
          {
            path: 'create',
            component: AddCustomerComponent
          }
        ]
      },
      {path: 'farmers', component: Farmer,children: [{ path: 'create', component: AddFarmer}]},
      {path: 'add-farmer', component:AddFarmer},
      {path: 'add-customer', component: AddCustomerComponent},
      {path: 'purchase', component: Purchase },
      {path: 'add-purchase', component: AddPurchase},
      {path: 'inventory', component: InventoryDashboard},
      {path:'create-sale', component:CreateSale},
      {path: 'sale', component: Sales,children: [
          {
            path: 'create',
            component: CreateSale
          }
        ]},
      {path: 'customer/payments', component: CustomerPayment,
        children: [
          {path: 'add-payment', component: AddCustomerPayment},
        //  {path: 'add-advance-payment', component: AddAdvancePayment},
        //  {path: 'return-advance-payment', component: ReturnAdvancePayment}
        ]
      },
        {
          path: 'farmer/payments',
          component: FarmerPayments,
          children: [
            {path: 'add-payment', component: AddFarmerPayments },
            {path: 'add-advance-payment', component: AddAdvancePayment},
            {path: 'return-advance-payment', component: ReturnAdvancePayment},
          ]
        },
        {
          path: 'create',
          component: AddFarmer
        },
      {path: 'payment-history', component: PaymentHistroy},
      {path:'reports/purchase', component: PurchaseReport},
      {path:'reports/sale', component: SaleReport},
      {path:'reports/profit', component: ProfitReport},
      {path:'reports/stock', component: StockReport},
      {path:'reports/payment', component: PaymentReport},
      
    ]
  },
  {path: 'create-customer', component: AddCustomerComponent},
  {path: 'login', component: HomeComponent}
  
];
