import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http'; 
import { ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';  // Standalone component

@NgModule({
  imports: [
    BrowserModule,
    HttpClientModule,
    ReactiveFormsModule,
  ],
  providers: [
  ],
  declarations: [], // No need to declare standalone components here
  bootstrap: [AppComponent],  // Directly bootstrap the AppComponent
})
export class AppModule {}
