import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';
import { StudentService } from '../service/student-service';
import { StudentRegistrationRequest, StudentResponse } from '../models/student-models';

@Component({
  selector: 'app-student-registration',
  standalone: true,
  imports: [
    CommonModule,
ReactiveFormsModule,
MatInputModule,
MatSelectModule,
MatDatepickerModule,
MatNativeDateModule,
MatCheckboxModule,
MatButtonModule,
MatCardModule,
MatToolbarModule,
MatSnackBarModule,
MatIconModule,
MatDividerModule
  ],
  templateUrl: './student-registration.html',
  styleUrl: './student-registration.css'
})
export class StudentRegistration implements OnInit {
  registrationForm!: FormGroup;
  branches = [
    { value: 'main', viewValue: 'Main Campus - City Center' },
    { value: 'north', viewValue: 'North Branch - Uptown' },
    { value: 'south', viewValue: 'South Branch - Downtown' },
    { value: 'east', viewValue: 'East Branch - Riverside' }
  ];


  genders = [
    { value: 'male', viewValue: 'Male' },
    { value: 'female', viewValue: 'Female' },
    { value: 'other', viewValue: 'Other' }
  ];


  bloodGroups = ['A+','A-','B+','B-','AB+','AB-','O+','O-'];
  categories = [
    { value: 'general', viewValue: 'General' },
    { value: 'obc', viewValue: 'OBC' },
    { value: 'sc', viewValue: 'SC' },
    { value: 'st', viewValue: 'ST' },
    { value: 'ews', viewValue: 'EWS' }
  ];


  classes = [
  'Nursery','LKG','UKG','Class 1','Class 2','Class 3','Class 4','Class 5','Class 6','Class 7','Class 8','Class 9','Class 10','Class 11','Class 12'
  ];
  constructor(private fb: FormBuilder, private snack: MatSnackBar,private studentService:StudentService) { }

  ngOnInit(): void {
    this.registrationForm = this.fb.group({
    // Branch Selection
    branch: ['', Validators.required],


    // Personal Information
    surName: ['', Validators.required],
    name: ['', Validators.required],
    dob: [null, Validators.required],
    gender: ['', Validators.required],
    nationality: [{value: 'Indian', disabled: true}],
    religion: [''],
    bloodGroup: [''],
    category: [''],


    // Academic Information
    admissionSoughtForClass: ['', Validators.required],
    previousSchoolInstitution: [''],
    lastClassAttended: [''],
    percentageGradeInLastClass: [''],


    // Contact Information
    residentialAddress: ['', Validators.required],
    city: ['', Validators.required],
    state: ['', Validators.required],
    pinCode: ['', Validators.required],
    phoneNumber: ['', [Validators.required, Validators.pattern('^[0-9]{6,15}$')]],
    emailAddress: ['', Validators.email],


    // Parent/Guardian Information - Father's
    fathersName: ['', Validators.required],
    fathersOccupation: [''],
    fathersPhoneNumber: ['', [Validators.required, Validators.pattern('^[0-9]{6,15}$')]],
    fathersEmailAddress: ['', Validators.email],


    // Guardian Information
    guardiansName: [''],
    guardiansRelationship: [''],
    guardiansPhoneNumber: [''],
    guardiansEmailAddress: ['', Validators.email],


    // Additional / Declarations
    declarationAccepted: [false, Validators.requiredTrue],
    agreementAccepted: [false, Validators.requiredTrue]
    });
  }


  onSubmit(): void {
    if (this.registrationForm.invalid) {
    this.registrationForm.markAllAsTouched();
    this.snack.open('Please complete all required fields.', 'OK', { duration: 3000 });
    return;
    }
   const rawValue = this.registrationForm.getRawValue();


    const payload: StudentRegistrationRequest = {
      ...rawValue,
      dob: rawValue.dob ? new Date(rawValue.dob).toISOString().slice(0, 10) : null,  // Format date to yyyy-MM-dd
    };

    console.log(payload);
    this.studentService.registerStudent(payload).subscribe({
      next: (response: StudentResponse) => {
        this.snack.open(
          `✅ Registration Successful! Student UID: ${response.studentUid}`,
          'Close',
          { duration: 5000 }
        );

        this.registrationForm.reset({ nationality: 'Indian' });
        window.scrollTo({ top: 0, behavior: 'smooth' });
      },
      error: (err) => {
        console.error('Registration failed:', err);
        this.snack.open(
          '❌ Registration failed. Please try again later.',
          'Close',
          { duration: 5000 }
        );
      }
    });
  }
}