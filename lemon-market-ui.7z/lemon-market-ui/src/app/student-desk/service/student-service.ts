import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { StudentRegistrationRequest, StudentResponse } from '../models/student-models';

@Injectable({ providedIn: 'root' })
export class StudentService {
  private baseUrl = `http://localhost:8080/api/registrations`;

  constructor(private http: HttpClient) {}

  registerStudent(req: StudentRegistrationRequest): Observable<StudentResponse> {
    return this.http.post<StudentResponse>(this.baseUrl, req);
  }

  getStudent(id: number): Observable<StudentResponse> {
    return this.http.get<StudentResponse>(`${this.baseUrl}/${id}`);
  }

  listStudents(page: number = 0, size: number = 10): Observable<any> {
    return this.http.get(`${this.baseUrl}?page=${page}&size=${size}`);
  }

  searchStudents(params: any): Observable<any> {
    return this.http.get(`${this.baseUrl}/search`, { params });
  }

  updateStudent(id: number, req: StudentRegistrationRequest): Observable<StudentResponse> {
    return this.http.put<StudentResponse>(`${this.baseUrl}/${id}`, req);
  }

  deleteStudent(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }
}
