import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

export interface FileMetadata {
  fileId: number;
  fileName: string;
  fileType: string;
  uploadedAt: string;
}

@Injectable({
  providedIn: 'root'
})
export class StudentFileService {
  private readonly baseUrl = 'http://localhost:8080/api/students/file';

  constructor(private http: HttpClient) {}

  /**
   * Upload a single file
   * @param file File to upload
   */
  uploadFile(file: File): Observable<any> {
    const formData = new FormData();
    formData.append('file', file);

    return this.http.post(`${this.baseUrl}/upload`, formData);
  }

  /**
   * Download file by ID
   * @param fileId File ID to download
   */
  downloadFile(fileId: number): Observable<Blob> {
    return this.http.get(`${this.baseUrl}/${fileId}`, {
      responseType: 'blob'
    });
  }

  /**
   * List all files for a student
   * @param studentId ID of the student
   */
  listFiles(studentId: number): Observable<FileMetadata[]> {
    const params = new HttpParams().set('studentId', studentId.toString());
    return this.http.get<FileMetadata[]>(this.baseUrl, { params });
  }
}
