import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

export interface AdmissionRequest {
  admissionNo?: string;
  applicationFormNo?: string;
  classOffice?: string;
  admissionDateOffice?: string;

  studentName: string;
  classApplyingFor: string;
  studentAadhaar: string;
  dob: string;
  dobWords: string;
  nationality?: string;
  religion?: string;
  caste: string;
  category?: string;
  childId?: string;
  penNumber?: string;
  apaarId?: string;
  identificationMarks?: string;

  fatherName: string;
  fatherAadhaar: string;
  motherName: string;
  motherAadhaar: string;
  fatherOccupation?: string;
  motherOccupation?: string;
  guardianName?: string;
  guardianRelation?: string;

  mobile: string;
  alternateMobile?: string;
  email?: string;
  address: string;

  previousSchool?: string;
  previousClass?: string;
  academicYear: string;
  admissionDate?: string;
  medium?: string;
  transport?: string;

  place: string;
  signatureDate: string;
  parentSignature: string;

  // File IDs (received from file upload API)
  tcFileId?: number;
  dobFileId?: number;
  aadharFileId?: number;
  photoFileId?: number;
}

@Injectable({
  providedIn: 'root'
})
export class AdmissionService {
  private readonly baseUrl = 'http://localhost:8080/api/admissions';

  constructor(private http: HttpClient) {}

  /**
   * Submit a new admission request
   */
  createAdmission(admission: AdmissionRequest): Observable<any> {
    return this.http.post(this.baseUrl, admission);
  }

  /**
   * Fetch admission details by ID
   */
  getAdmissionById(admissionId: number): Observable<AdmissionRequest> {
    return this.http.get<AdmissionRequest>(`${this.baseUrl}/${admissionId}`);
  }

  /**
   * Fetch list of all admissions (optional)
   */
  getAllAdmissions(): Observable<AdmissionRequest[]> {
    return this.http.get<AdmissionRequest[]>(this.baseUrl);
  }

  /**
   * Delete an admission record (optional)
   */
  deleteAdmission(admissionId: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${admissionId}`);
  }

  /**
   * Update an existing admission (optional)
   */
  updateAdmission(admissionId: number, updatedAdmission: AdmissionRequest): Observable<any> {
    return this.http.put(`${this.baseUrl}/${admissionId}`, updatedAdmission);
  }
}
