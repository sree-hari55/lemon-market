import { Component, OnInit, ViewChild, ElementRef, ViewChildren, QueryList } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { DateAdapter, MAT_DATE_FORMATS, MatNativeDateModule, MatOptionModule, NativeDateAdapter } from '@angular/material/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { CommonModule } from '@angular/common';
import { MatRadioModule} from '@angular/material/radio';
import { MatIconModule } from '@angular/material/icon';
import { StudentFileService } from '../service/student-file-upload';
import { AdmissionRequest, AdmissionService } from '../service/student-admission.service';
export const MY_DATE_FORMATS = {
  parse: {
    dateInput: 'YYYY-MM-DD',
  },
  display: {
    dateInput: 'YYYY-MM-DD',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};
@Component({
  selector: 'app-admission-form',
  standalone: true,
  imports:[
    CommonModule,
    ReactiveFormsModule,
    MatInputModule,
    MatSelectModule,
    MatCheckboxModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatButtonModule,
    MatCardModule,
    MatFormFieldModule,
    MatOptionModule,
    MatRadioModule,
    MatIconModule
  ],
  templateUrl: './student-admission.html',
   providers: [
    { provide: MAT_DATE_FORMATS, useValue: MY_DATE_FORMATS },
    { provide: DateAdapter, useClass: NativeDateAdapter },
  ],
  styleUrls: ['./student-admission.css'],
})
export class StudentAdmissionFormComponent implements OnInit {
  acceptedFormats = '.pdf,.jpg,.jpeg,.png';

  documentList = [
    { label: '1) T.C. (Transfer Certificate)', control: 'TC', uploadControl: 'tcFileId',fileName: ''  },
    { label: '2) DOB (Date of Birth Certificate)', control: 'DOB', uploadControl: 'dobFileId' ,fileName: '' },
    { label: '3) Aadhar Card', control: 'Aadhar', uploadControl: 'aadharFileId',fileName: ''  },
  ];

  docRefs: { [key: string]: HTMLInputElement } = {};

  admissionForm!: FormGroup;
  photoName: string | null = null;
  classes = ['Pre-KG', 'LKG', 'UKG', '1st', '2nd', '3rd', '4th', '5th', '6th', '7th', '8th', '9th', '10th'];
  categoryOptions: string[] = ['General', 'OBC', 'SC', 'ST', 'BC','Other'];
  @ViewChild('photoInput') photoInput!: ElementRef<HTMLInputElement>;

  constructor(private fb: FormBuilder,private studentFileService:StudentFileService, private admissionService:AdmissionService) {}
   selectedFileNames: { [key: string]: string } = {};
  ngOnInit(): void {
    this.admissionForm = this.fb.group({
      // Office Use Only
      admissionNo: [''],
      admissionDateOffice: [''],
      classOffice: [''],
      applicationFormNo: [''],

      // Student Information
      studentName: ['', Validators.required],
      classApplying: ['', Validators.required],
      studentAadhar: ['', [Validators.required, Validators.pattern(/^\d{12}$/)]],
      dob: ['', Validators.required],
      dobWords: ['', Validators.required],
      birthPlace: [''],
     // gender: ['', Validators.required],
      nationality: [''],
      religion: [''],
      casteSubCaste: ['', Validators.required],
      category: ['', Validators.required],
      childId: [''],
      penNumber: [''],
      apaarId: [''],
      identificationMarks: [''],

      // Parent / Guardian Information
       fatherName: ['', Validators.required],
       fatherAadhar: ['', [Validators.required, Validators.pattern(/^\d{12}$/)]],
       motherName: ['', Validators.required],
       motherAadhar: ['', [Validators.required, Validators.pattern(/^\d{12}$/)]],
       fatherOccupation: [''],
       motherOccupation: [''],
       guardianName: [''],
       guardianRelation: [''],

      // Contact Details
      mobileNumber: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
      alternateMobile: [''],  
      emailId: [''],          
      address: ['', Validators.required],
      //<!-- Additional Information --> & Academic Information
      previousSchool: [''],
      previousClass: [''],
      academicYear: ['', Validators.required], 
      admissionDate: [''],
      medium: ['English'],  
      transport: ['No'], 

      // Documents Submitted (checkboxes)
      TC: [false],
      DOB: [false],
      Aadhar: [false],
      photoFileId: [null],
      tcFileId: [null],
      dobFileId: [null],
      aadharFileId: [null],

      // Declaration
      place: ['', Validators.required],
      signatureDate: ['', Validators.required],
      parentSignature: ['', Validators.required],
    });
  }

onFileSelected(event: Event, controlName: string) {
  const input = event.target as HTMLInputElement;
  if (!input.files || input.files.length === 0) return;

  const file = input.files[0];

  this.studentFileService.uploadFile(file).subscribe({
    next: (res) => {
      const fileIdControlName = controlName.charAt(0).toLowerCase() + controlName.slice(1) + 'FileId';

      const fileControl = this.admissionForm.get(fileIdControlName);
      if (fileControl) {
        fileControl.setValue(res.fileId);
        this.selectedFileNames[controlName] = file.name;
        console.log(`${fileIdControlName} set to ${res.fileId}`);
      } else {
        console.warn(`⚠️ Form control '${fileIdControlName}' not found`);
      }
    },
    error: () => {
      alert('Failed to upload ' + controlName + ' document.');
    }
  });
}



onPhotoSelected(event: Event): void {
  const input = event.target as HTMLInputElement;
  if (input.files?.length) {
    const file = input.files[0];
    this.photoName = file.name;

    this.studentFileService.uploadFile(file).subscribe({
      next: (res) => {
        this.admissionForm.get('photoFileId')?.setValue(res.fileId);
        console.log('Photo uploaded with ID:', res.fileId);
      },
      error: () => {
        alert('Photo upload failed.');
        this.photoName = null;
      }
    });
  }
}


  onSubmit(): void {
    if (this.admissionForm.invalid) {
      this.admissionForm.markAllAsTouched();

      const firstInvalidControl = document.querySelector('.is-invalid .mat-input-element');
      if (firstInvalidControl instanceof HTMLElement) {
        firstInvalidControl.scrollIntoView({ behavior: 'smooth', block: 'center' });
        firstInvalidControl.focus();
      }

      alert('❌ Please fix the highlighted errors before submitting.');
      return;
    }

    // ✅ Prepare the payload from the form
    const formData = this.admissionForm.value;

    const admissionPayload: AdmissionRequest = {
      admissionNo: formData.admissionNo,
      admissionDateOffice: formData.admissionDateOffice,
      classOffice: formData.classOffice,
      applicationFormNo: formData.applicationFormNo,

      studentName: formData.studentName,
      classApplyingFor: formData.classApplying,
      studentAadhaar: formData.studentAadhar,
      dob: formData.dob,
      dobWords: formData.dobWords,
      nationality: formData.nationality,
      religion: formData.religion,
      caste: formData.casteSubCaste,
      category: formData.category,
      childId: formData.childId,
      penNumber: formData.penNumber,
      apaarId: formData.apaarId,
      identificationMarks: formData.identificationMarks,

      fatherName: formData.fatherName,
      fatherAadhaar: formData.fatherAadhar,
      motherName: formData.motherName,
      motherAadhaar: formData.motherAadhar,
      fatherOccupation: formData.fatherOccupation,
      motherOccupation: formData.motherOccupation,
      guardianName: formData.guardianName,
      guardianRelation: formData.guardianRelation,

      mobile: formData.mobileNumber,
      alternateMobile: formData.alternateMobile,
      email: formData.emailId,
      address: formData.address,

      previousSchool: formData.previousSchool,
      previousClass: formData.previousClass,
      academicYear: formData.academicYear,
      admissionDate: formData.admissionDate,
      medium: formData.medium,
      transport: formData.transport,

      place: formData.place,
      signatureDate: formData.signatureDate,
      parentSignature: formData.parentSignature,

      // File IDs
      tcFileId: formData.tcFileId,
      dobFileId: formData.dobFileId,
      aadharFileId: formData.aadharFileId,
      photoFileId: formData.photoFileId
    };
    console.log(admissionPayload);
    // ✅ Call API to create admission
    this.admissionService.createAdmission(admissionPayload).subscribe({
      next: (res) => {
        alert('✅ Admission submitted successfully!');
        this.admissionForm.reset();
        this.photoName = null;
      },
      error: (err) => {
        console.error('Submission failed:', err);
        alert('❌ Failed to submit admission. Please try again.');
      }
    });
  }

  onPrint(): void {
    window.print();
  }
isInvalid(controlName: string): boolean {
  const control = this.admissionForm.get(controlName);
  return !!(control && control.invalid && control.touched);
}
onCheckboxChange(checked: boolean, controlName: string) {
  if (!checked) {
    // Clear uploaded file if checkbox unchecked manually
    this.admissionForm.get(this.getUploadControlName(controlName))?.setValue(null);
  }
}

// Helper to map checkbox control to upload control
getUploadControlName(checkboxControl: string): string {
  switch (checkboxControl) {
    case 'TC': return 'tcUpload';
    case 'DOB': return 'dobUpload';
    case 'Aadhar': return 'aadharUpload';
    default: return '';
  }
}

}
