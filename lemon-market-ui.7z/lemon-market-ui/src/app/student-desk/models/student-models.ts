export interface StudentRegistrationRequest {
  surName: string;
  name?: string;
  dob: string; // ISO format: yyyy-MM-dd
  gender?: string;
  nationality?: string;
  category?: string;
  bloodGroup?: string;
  classApplied: string;
  previousSchool?: string;
  lastClassAttended?: string;
  lastClassPercent?: number;
  residentialAddress?: string;
  city?: string;
  state?: string;
  pinCode?: string;
  phoneNumber: string;
  email?: string;
  fatherName?: string;
  fatherPhone?: string;
  guardianName?: string;
  guardianEmail?: string;
  declarationAccepted: boolean;
  agreementAccepted: boolean;
}

export interface StudentResponse {
  id: number;
  studentUid: string;
  firstName: string;
  lastName: string;
  createdAt: string; // ISO 8601 format
}
