import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { FarmerDto, PaginatedResponse } from "../model/FarmerDto";
import { Observable } from "rxjs";

@Injectable({
  providedIn: 'root',
})
export class FarmerService {

  private apiUrl = 'http://localhost:9090/api/farmer';

  constructor(private http: HttpClient) {}

  createFarmer(customer: FarmerDto): Observable<FarmerDto> {
    return this.http.post<FarmerDto>(this.apiUrl, customer);
  }

  getFarmers(): Observable<FarmerDto[]> {
    return this.http.get<FarmerDto[]>(this.apiUrl);
  }

  getPaginatedFarmers(pageIndex: number, pageSize: number): Observable<PaginatedResponse<FarmerDto>> {
    return this.http.get<PaginatedResponse<FarmerDto>>(
      `${this.apiUrl}?pageIndex=${pageIndex}&pageSize=${pageSize}`
    );
  }

  deleteFarmer(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  getFarmerById(id: number): Observable<FarmerDto> {
    return this.http.get<FarmerDto>(`${this.apiUrl}/${id}`);
  }

  updateFarmer(id: number, customer: Partial<FarmerDto>): Observable<FarmerDto> {
    return this.http.put<FarmerDto>(`${this.apiUrl}/${id}`, customer);
  }
  searchFarmers(query: string):Observable<FarmerDto[]>{
   return this.http.get<FarmerDto[]>(`${this.apiUrl}/search?query=${query}`);
  }

  filterFarmers(filter: any, pageIndex: number, pageSize: number) {
  const params = {
    pageIndex,
    pageSize
  };
  return this.http.post<any>(`${this.apiUrl}/filter`, filter, { params });
}

}
