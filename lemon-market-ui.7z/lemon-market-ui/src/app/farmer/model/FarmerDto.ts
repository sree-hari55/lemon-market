export interface FarmerDto {
  id?: number;
  firstName: string;
  lastName: string;
  phoneNumber: string;
  email?: string;
  address?: string;
  createdBy?: string;
  creationDate?: string;
}
export interface PaginatedResponse<T> {
  totalResult: number;
  pageIndex: number;
  itemsPerPage: number;
  results: T[];
}