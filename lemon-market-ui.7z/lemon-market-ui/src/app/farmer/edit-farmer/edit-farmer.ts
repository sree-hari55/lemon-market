import { CommonModule } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { FarmerDto } from '../model/FarmerDto';
import { FarmerService } from '../service/FarmerService';

@Component({
  selector: 'app-edit-farmer',
  standalone: true,
    imports: [CommonModule,ReactiveFormsModule, FormsModule, MatFormFieldModule, MatInputModule, MatButtonModule,MatDialogModule],
  templateUrl: './edit-farmer.html',
  styleUrl: './edit-farmer.css'
})
export class EditFarmer {
 form: FormGroup;

  constructor(
    public dialogRef: MatDialogRef<EditFarmer>,
    @Inject(MAT_DIALOG_DATA) public data: FarmerDto,
    private fb: FormBuilder,
    private farmerService: FarmerService
  ) {
    this.form = this.fb.group({
      firstName: [data.firstName, Validators.required],
      lastName: [data.lastName, Validators.required],
      email: [data.email, [Validators.required, Validators.email]],
      phoneNumber: [data.phoneNumber],
      address: [data.address],
      createdDate: [data.creationDate]
    });
  }

  onSave(): void {
    if (this.form.valid) {
      const updated = { ...this.data, ...this.form.value };
      this.farmerService.updateFarmer(this.data.id!, updated).subscribe(() => {
        this.dialogRef.close(updated);
      });
    }
  }

  onCancel(): void {
    this.dialogRef.close();
  }

}
