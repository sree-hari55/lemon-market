import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { FarmerService } from '../service/FarmerService';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-add-farmer',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatSnackBarModule,
    MatCardModule
  ],
  templateUrl: './add-farmer.html',
  styleUrl: './add-farmer.css'
})
export class AddFarmer {
  farmerForm!: FormGroup;
  submitting = false;

  ngOnInit(): void {
    this.farmerForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      phoneNumber: [
        '',
        [Validators.required, Validators.minLength(10), Validators.maxLength(15)],
      ],
      email: ['', Validators.email],
      address: [''],
      // createdBy and createdDate are backend-managed, no need on form
    });
  }

constructor(
  private fb: FormBuilder,
  private farmerService: FarmerService,
  private snackBar: MatSnackBar,
  private router: Router,
  private route: ActivatedRoute
) {}

onSubmit() {
  if (this.farmerForm.invalid) {
    this.farmerForm.markAllAsTouched();
    return;
  }

  this.submitting = true;

  this.farmerService.createFarmer(this.farmerForm.value).subscribe({
    next: () => {
      this.snackBar.open('Customer created successfully!', 'Close', {
        duration: 3000,
      });
      this.submitting = false;
      this.farmerForm.reset();

      // ✅ Go back to customer list
      this.router.navigate(['../'], { relativeTo: this.route });
    },
    error: () => {
      this.snackBar.open('Failed to create customer', 'Close', {
        duration: 3000,
      });
      this.submitting = false;
    }
  });
} 
get f() {
  return this.farmerForm.controls;
}

onCancel(): void {
  this.router.navigate(['../'], { relativeTo: this.route });
}
}
