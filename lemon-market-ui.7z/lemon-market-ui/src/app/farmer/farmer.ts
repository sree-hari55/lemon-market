import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatTableModule } from '@angular/material/table';
import { NavigationEnd, Router, RouterModule } from '@angular/router';
import { CustomerDto, CustomerService } from '../customer/service/add-customer.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { filter as rxjsFilter, debounceTime, Subject } from 'rxjs';
import { EditCustomerDialogComponent } from '../customer/edit-customer-dialog/edit-customer-dialog';
import { FarmerDto } from './model/FarmerDto';
import { FarmerService } from './service/FarmerService';
import { EditFarmer } from './edit-farmer/edit-farmer';
import { MatFormFieldModule } from '@angular/material/form-field';
import { HttpParams } from '@angular/common/http';
import { MatInputModule } from '@angular/material/input';

@Component({
  selector: 'app-farmer',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    MatInputModule,
    MatTableModule,
    MatPaginatorModule,
    MatButtonModule,
    MatIconModule,
    FormsModule,
    MatFormFieldModule,
  ],
  templateUrl: './farmer.html',
  styleUrl: './farmer.css'
})
export class Farmer {
  farmers: FarmerDto[] = [];
  displayedFarmers: FarmerDto[] = [];
  pageIndex = 1;
  pageSize = 10;
  totalResult = 0;
  isCreateRoute: boolean = false;
  editedFarmer: FarmerDto | null = null;
  showFilter = false;

  // Filter fields
  filter = {
    firstName: '',
    lastName: '',
    phoneNumber: '',
    email: ''
  };

  private filterChanged = new Subject<void>();
  private isFilterActive = false;

  constructor(
    private router: Router,
    private farmerService: FarmerService,
    private snackBar: MatSnackBar,
    private dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.loadFarmers();

    this.router.events
      .pipe(rxjsFilter(event => event instanceof NavigationEnd))
      .subscribe(() => {
        this.isCreateRoute = this.router.url.endsWith('/create');
        if (!this.isCreateRoute) {
          this.loadFarmers();
        }
      });

    // Debounced filter
    this.filterChanged.pipe(debounceTime(400)).subscribe(() => {
      this.pageIndex = 1;
      this.isFilterActive = this.hasFilter();
      this.loadFarmers();
    });
  }

  toggleFilter(): void {
    this.showFilter = !this.showFilter;
  }

  onFilterChange(): void {
    this.filterChanged.next();
  }

  hasFilter(): boolean {
    return Object.values(this.filter).some(value => value && value.trim() !== '');
  }

  loadFarmers(): void {
    if (this.isFilterActive) {
      // Filter API call
      this.farmerService.filterFarmers(this.filter, this.pageIndex, this.pageSize)
        .subscribe(data => {
          this.farmers = data.results;
          this.totalResult = data.totalResult;
          this.pageIndex = data.pageIndex;
          this.updateDisplayedFarmers();
        });
    } else {
      // Default non-filtered API call
      this.farmerService.getPaginatedFarmers(this.pageIndex, this.pageSize)
        .subscribe(data => {
          this.farmers = data.results;
          this.totalResult = data.totalResult;
          this.pageIndex = data.pageIndex;
          this.updateDisplayedFarmers();
        });
    }
  }

  onPageChange(event: PageEvent): void {
    this.pageIndex = event.pageIndex + 1;
    this.pageSize = event.pageSize;
    this.loadFarmers();
  }

  deleteFarmer(id: number): void {
    const confirmDelete = confirm('Are you sure you want to delete this Farmer?');
    if (confirmDelete) {
      this.farmerService.deleteFarmer(id).subscribe({
        next: () => {
          this.farmers = this.farmers.filter(c => c.id !== id);
          this.updateDisplayedFarmers();
          this.snackBar.open('Farmer deleted successfully.', 'Close', { duration: 3000 });
        },
        error: () => {
          this.snackBar.open('Failed to delete Farmer.', 'Close', { duration: 3000 });
        }
      });
    }
  }

  editFarmer(farmer: FarmerDto): void {
    const dialogRef = this.dialog.open(EditFarmer, {
      width: '400px',
      data: farmer
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        const index = this.farmers.findIndex(c => c.id === result.id);
        if (index > -1) {
          this.farmers[index] = result;
          this.updateDisplayedFarmers();
        }
      }
    });
  }

  updateDisplayedFarmers(): void {
    this.displayedFarmers = this.farmers.slice(0, this.pageSize);
  }

   clearFilters(): void {
    this.filter = {
      firstName: '',
      lastName: '',
      email: '',
      phoneNumber: ''
    };
    this.loadFarmers();
  }
}
