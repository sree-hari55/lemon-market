import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AuthService } from '../auth/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent implements OnInit {
  profileImageUrl: string | null = null;
  showLogout: boolean = false;

  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit() {
    this.profileImageUrl = this.authService.getProfileImageUrl() || null;
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  toggleLogout() {
    this.showLogout = !this.showLogout;
  }

  get isAuthenticated(): boolean {
    return this.authService.isAuthenticated();
  }

  get loggedInUser(): string | null {
    return this.authService.getUsername();
  }
}
