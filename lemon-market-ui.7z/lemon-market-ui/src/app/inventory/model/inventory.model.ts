export interface InventoryItem {
  id: number;
  quality: string;
  participantName: string;
  stockInKg: number;
  stockOutKg: number;
  availableStockKg: number;
  pricePerKg:number;
  status: string;
  lastUpdated: string;
  expiryDate: string;
  location:string;
  transactionType: String;
  notes: string;
}

export interface LemonStock {
  freshKg: number;
  freshTons: number;
  secondQualityKg: number;
  secondQualityTons: number;
}

export interface InventorySummary {
  availableLemonStock: LemonStock;
  soldLemonStock: LemonStock;
}
