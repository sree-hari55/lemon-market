import { CommonModule } from '@angular/common';
import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { InventoryItem, InventorySummary } from '../model/inventory.model';
import { InventoryService } from '../services/inventory.service';
import { StockTransactionForm } from '../stock-transaction-form/stock-transaction-form';
import { MatCardModule } from '@angular/material/card';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';

@Component({
  selector: 'app-inventory-dashboard',
  imports: [CommonModule,
    MatTableModule,
    MatDialogModule,
    MatButtonModule,
    MatCardModule,
    MatPaginatorModule
  ],
  templateUrl: './inventory-dashboard.html',
  styleUrl: './inventory-dashboard.css'
})
export class InventoryDashboard implements AfterViewInit {
displayedColumns: string[] = [
  'date',
  'transactionType',
  'quality',
  'stockInKg',
  'stockOutKg',
  'unitPrice',
  'location',
  'participantName',
  'status'
];
inventorySummary!: InventorySummary;
@ViewChild(MatPaginator) paginator!: MatPaginator;
  inventory: InventoryItem[] = [];
  constructor(
    private inventoryService: InventoryService,
    private dialog: MatDialog
  ) {}
dataSource = new MatTableDataSource<InventoryItem>([]);

  ngOnInit() {
    this.loadInventory();
  }
   ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }

  loadInventory() {
    this.inventoryService.getInventoryList().subscribe(data => {
      this.dataSource.data = data;
    });
  this.loadInventorySummary();  
  }

  loadInventorySummary(){
    this.inventoryService.getInventorySummary().subscribe(data => {
      this.inventorySummary = data;
    });
  }


  openStockDialog(type: 'purchase' | 'sale' | 'adjustment') {
    const dialogRef = this.dialog.open(StockTransactionForm, {
      width: '400px',
      data: { type }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) this.loadInventory();
    });
  }
  getDisplayValue(value: number | null | undefined): string {
  return value && value !== 0 ? value.toString() : '-';
}

}
