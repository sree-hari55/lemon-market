import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StockTransactionForm } from './stock-transaction-form';

describe('StockTransactionForm', () => {
  let component: StockTransactionForm;
  let fixture: ComponentFixture<StockTransactionForm>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [StockTransactionForm]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StockTransactionForm);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
