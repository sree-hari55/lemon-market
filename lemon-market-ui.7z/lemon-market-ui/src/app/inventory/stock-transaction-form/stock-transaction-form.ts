import { CommonModule } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { InventoryService } from '../services/inventory.service';

@Component({
  selector: 'app-stock-transaction-form',
  imports: [CommonModule,
    ReactiveFormsModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule,
    MatDialogModule],
  templateUrl: './stock-transaction-form.html',
  styleUrl: './stock-transaction-form.css'
})
export class StockTransactionForm {
 form: FormGroup;
  transactionType: string;

  constructor(
    private fb: FormBuilder,
    private inventoryService: InventoryService,
    private dialogRef: MatDialogRef<StockTransactionForm>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.transactionType = data.type;
    this.form = this.fb.group({
      productId: ['', Validators.required],
      quantity: ['', Validators.required],
      warehouse: ['', Validators.required]
    });
  }

  submit() {
    if (this.form.valid) {
      this.inventoryService.submitTransaction(this.form.value, this.transactionType)
        .subscribe(() => this.dialogRef.close(true));
    }
  }
}
