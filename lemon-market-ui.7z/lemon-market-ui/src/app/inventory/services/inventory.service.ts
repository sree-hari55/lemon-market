import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { InventoryItem, InventorySummary } from '../model/inventory.model';

@Injectable({
  providedIn: 'root'
})
export class InventoryService {
  private baseUrl = 'http://localhost:9090/api/v1/inventory';

  constructor(private http: HttpClient) {}

  getInventoryList(): Observable<InventoryItem[]> {
    return this.http.get<InventoryItem[]>(`${this.baseUrl}`);
  }

  submitTransaction(data: any, type: string): Observable<any> {
    return this.http.post(`${this.baseUrl}/transactions/${type}`, data);
  }
  getInventorySummary(): Observable<InventorySummary> {
    const url = `${this.baseUrl}/summary`;
    return this.http.get<InventorySummary>(url);
  }
}
