export interface AcademicYear {
  id: number;
  code: string;
  fromDate: string; 
  endDate: string;
  active: boolean;
  createdAt?: string;
  updatedAt?: string;
}


export interface PageOfResponse<T> {
  totalResult: number;
  pageIndex: number;
  itemsPerPage: number;
  results: T[];
}

export interface ShiftAcademicYearRequest {
  fromYear: string;  
  toYear: string;    
  transitionCode: string;  
}
export interface AcademicYearRequestDTO {
  code: string;
  fromDate: string;  
  endDate: string;   
  active: boolean;
}
