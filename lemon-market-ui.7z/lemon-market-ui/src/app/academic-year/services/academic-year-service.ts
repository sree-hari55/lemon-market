import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AcademicYear, PageOfResponse, ShiftAcademicYearRequest } from '../models/academic-year';

@Injectable({
  providedIn: 'root'
})
export class AcademicYearService {
  private baseUrl = 'http://localhost:8080/api/v1/academic-years';

  constructor(private http: HttpClient) {}

  getAll(pageIndex = 0, pageSize = 20): Observable<PageOfResponse<AcademicYear>> {
    const params = new HttpParams()
      .set('pageIndex', pageIndex.toString())
      .set('pageSize', pageSize.toString());
    return this.http.get<PageOfResponse<AcademicYear>>(this.baseUrl, { params });
  }

  getById(id: number): Observable<AcademicYear> {
    return this.http.get<AcademicYear>(`${this.baseUrl}/${id}`);
  }

  getByCode(code: string): Observable<AcademicYear> {
    return this.http.get<AcademicYear>(`${this.baseUrl}/by-code/${code}`);
  }

  create(request: Partial<AcademicYear>): Observable<AcademicYear> {
    return this.http.post<AcademicYear>(this.baseUrl, request);
  }

  update(id: number, request: Partial<AcademicYear>): Observable<AcademicYear> {
    return this.http.put<AcademicYear>(`${this.baseUrl}/${id}`, request);
  }

  activate(id: number): Observable<AcademicYear> {
    return this.http.post<AcademicYear>(`${this.baseUrl}/${id}/activate`, {});
  }

  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }

  shiftAcademicYear(request: ShiftAcademicYearRequest): Observable<void> {
    return this.http.post<void>(`${this.baseUrl}/shift`, request);
  }
}
