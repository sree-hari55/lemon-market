import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder} from '@angular/forms';
import { AcademicYear } from '../models/academic-year';
import { AcademicYearService } from '../services/academic-year-service';
import { CommonModule, DatePipe } from '@angular/common';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatChipsModule } from '@angular/material/chips';
import { MatCardModule } from '@angular/material/card';
import { ReactiveFormsModule } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ShiftAcademic } from '../shift-academic/shift-academic';
import { AcademicYearForm } from '../academic-year-form/academic-year-form';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';

@Component({
  selector: 'app-academic-list',
  standalone: true,
  imports: [
    CommonModule,
    DatePipe,
    ReactiveFormsModule,
    MatPaginatorModule,
    MatTableModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatChipsModule,
    MatCardModule,
  ],
  templateUrl: './academic-list.html',
  styleUrls: ['./academic-list.css'],
})
export class AcademicList implements OnInit, AfterViewInit {

  displayedColumns = ['createdDate', 'code', 'fromDate', 'endDate', 'isActive', 'actions'];

  dataSource = new MatTableDataSource<AcademicYear>([]);
  currentPage = 1;
  totalPages = 1;
  pageSize = 10;

  @ViewChild(MatPaginator) paginator!: MatPaginator;

  constructor(
    private academicYearService: AcademicYearService,
    private dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.loadAcademicYears(this.currentPage);
  }

  ngAfterViewInit(): void {
    this.dataSource.paginator = this.paginator;
  }

  loadAcademicYears(page: number): void {
    this.academicYearService.getAll(page - 1, this.pageSize).subscribe(pageData => {
      this.dataSource.data = pageData.results;
      this.currentPage = pageData.pageIndex + 1;
      this.totalPages = Math.ceil(pageData.totalResult / this.pageSize);
    });
  }

  goToPage(page: number): void {
    if (page < 1 || page > this.totalPages) return;
    this.loadAcademicYears(page);
  }

  editYear(year: AcademicYear): void {
    this.editAcademicForm(year);
  }

  editAcademicForm(year: AcademicYear | null = null): void {
    const dialogRef = this.dialog.open(AcademicYearForm, {
      width: '450px',
      data: year,
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.loadAcademicYears(this.currentPage);
      }
    });
  }

  activateYear(year: AcademicYear): void {
    if (year.active) {
      return;
    }
    this.academicYearService.activate(year.id).subscribe({
      next: () => this.loadAcademicYears(this.currentPage),
      error: err => {
        console.error('Activate failed', err);
        alert('Failed to activate the academic year.');
      }
    });
  }

  deleteYear(year: AcademicYear): void {
    if (!confirm(`Are you sure you want to delete academic year ${year.code}?`)) {
      return;
    }
    this.academicYearService.delete(year.id).subscribe({
      next: () => this.loadAcademicYears(this.currentPage),
      error: err => {
        console.error('Delete failed', err);
        alert('Failed to delete the academic year.');
      }
    });
  }

  shiftAcademicYear(): void {
    const dialogRef = this.dialog.open(ShiftAcademic, {
      width: '400px',
      data: null
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.loadAcademicYears(this.currentPage);
      }
    });
  }

  openAcademicForm(): void {
    const dialogRef = this.dialog.open(AcademicYearForm, {
      width: '450px',
      data: null,
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.loadAcademicYears(this.currentPage);
      }
    });
  }
}
