import { Component, inject, OnInit } from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { AcademicYear, ShiftAcademicYearRequest } from '../models/academic-year';
import { AcademicYearService } from '../services/academic-year-service';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-shift-academic',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    MatCardModule,
    MatButtonModule
  ],
  templateUrl: './shift-academic.html',
  styleUrls: ['./shift-academic.css']
})
export class ShiftAcademic implements OnInit {

  academicYears: AcademicYear[] = [];
  form: FormGroup;
  isLoading = false;
  successMessage = '';
  errorMessage = '';
  private dialogRef = inject(MatDialogRef<ShiftAcademic>);

  constructor(private academicYearService: AcademicYearService, private fb: FormBuilder) {
    this.form = this.fb.group({
      from: ['', Validators.required],
      to: ['', Validators.required],
      code: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.loadAcademicYears();
  }

  loadAcademicYears(): void {
    this.academicYearService.getAll(0, 100).subscribe({
      next: (response) => {
        this.academicYears = response.results;
      },
      error: () => {
        this.errorMessage = 'Failed to load academic years.';
      }
    });
  }

  onSubmit(): void {
    this.isLoading = true;
    this.successMessage = '';
    this.errorMessage = '';

    const formValues = this.form.value;

    const requestPayload: ShiftAcademicYearRequest = {
      fromYear: formValues.from,
      toYear: formValues.to,
      transitionCode: formValues.code,
    };

    this.academicYearService.shiftAcademicYear(requestPayload).subscribe({
      next: () => {
        this.successMessage = 'Academic year shifted successfully!';
        this.form.reset();
      },
      error: (err) => {
        console.error('Error:', err);
        this.errorMessage = 'Failed to shift academic year.';
      },
      complete: () => {
        this.isLoading = false;
      }
    });
    this.dialogRef.close(false);
  }

  onCancel(): void {
    this.dialogRef.close(false);
  }
}
