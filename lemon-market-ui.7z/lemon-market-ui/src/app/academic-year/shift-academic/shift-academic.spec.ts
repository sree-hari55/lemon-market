import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShiftAcademic } from './shift-academic';

describe('ShiftAcademic', () => {
  let component: ShiftAcademic;
  let fixture: ComponentFixture<ShiftAcademic>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ShiftAcademic]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShiftAcademic);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
