import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AcademicYearService } from '../services/academic-year-service';
import { AcademicYear, AcademicYearRequestDTO } from '../models/academic-year';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatInputModule } from '@angular/material/input';
import { DateAdapter, MAT_DATE_FORMATS, MatNativeDateModule, NativeDateAdapter } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';

export const MY_DATE_FORMATS = {
  parse: {
    dateInput: 'YYYY-MM-DD',
  },
  display: {
    dateInput: 'YYYY-MM-DD',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: 'app-academic-year-form',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatSlideToggleModule,
    MatInputModule,
    MatNativeDateModule,
    MatDatepickerModule
  ],
  providers: [
    { provide: MAT_DATE_FORMATS, useValue: MY_DATE_FORMATS },
    { provide: DateAdapter, useClass: NativeDateAdapter },
  ],
  templateUrl: './academic-year-form.html',
  styleUrls: ['./academic-year-form.css'],
})
export class AcademicYearForm implements OnInit {
  form: FormGroup;
  editMode = false;

  constructor(
    private fb: FormBuilder,
    private service: AcademicYearService,
    public dialogRef: MatDialogRef<AcademicYearForm>,
    @Inject(MAT_DIALOG_DATA) public data: AcademicYear | null
  ) {
    this.form = this.fb.group({
      code: ['', Validators.required],
      startDate: ['', Validators.required],
      endDate: ['', Validators.required],
      isActive: [false]
    });
  }

  ngOnInit() {
    if (this.data) {
      this.editMode = true;
      this.form.patchValue({
        code: this.data.code,
        startDate: new Date(this.data.fromDate),
        endDate: new Date(this.data.endDate),
        isActive: this.data.active ?? this.data.active ?? false
      });
    }
  }

  onSubmit() {
    if (this.form.invalid) return;

    const formValues = this.form.value;

    const requestPayload: AcademicYearRequestDTO = {
      code: formValues.code,
      fromDate: this.convertToInstant(formValues.startDate),
      endDate: this.convertToInstant(formValues.endDate),
      active: formValues.isActive,
    };

    if (this.editMode && this.data?.id) {
      this.service.update(this.data.id, requestPayload).subscribe(
        (response) => {
          console.log('Update successful:', response);
          this.dialogRef.close(true);
        },
        (error) => {
          console.error('Update error:', error);
          alert('There was an error while updating the academic year. Please try again.');
        }
      );
    } else {
      this.service.create(requestPayload).subscribe(
        (response) => {
          console.log('Create successful:', response);
          this.dialogRef.close(true);
        },
        (error) => {
          console.error('Create error:', error);
          alert('There was an error while saving the academic year. Please try again.');
        }
      );
    }
  }

  private convertToInstant(date: Date): string {
    return date.toISOString();
  }

  onCancel(): void {
    this.dialogRef.close(false);
  }
}
