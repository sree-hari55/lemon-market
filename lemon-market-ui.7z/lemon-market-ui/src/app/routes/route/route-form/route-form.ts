import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { CommonModule } from '@angular/common';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { RouteService } from '../route.service';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { DestinationResponseDTO } from '../../destinations/destination.model';
import { DestinationService } from '../../destinations/destination-service';
import { RouteRequest, RouteResponse } from '../route';

@Component({
  selector: 'app-route-form',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatSnackBarModule
  ],
  templateUrl: './route-form.html',
  styleUrl: './route-form.css'
})
export class RouteForm {
form: FormGroup;
  destinations: DestinationResponseDTO[] = [];
  isLoading = false;

  constructor(
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<RouteForm>,
    @Inject(MAT_DIALOG_DATA) public data: RouteResponse | null,
    private routeService: RouteService,
    private destinationService: DestinationService,
    private snackBar: MatSnackBar
  ) {
    this.form = this.fb.group({
      routeCode: [data?.routeCode ?? '', Validators.required],
      name: [data?.name ?? '', Validators.required],
      originCode: [data?.originCode ?? '', Validators.required],
      destinationCode: [data?.destinationCode ?? '', Validators.required],
      servicePrice: [data?.servicePrice ?? '', [Validators.required, Validators.min(0)]],
    });

    this.loadDestinations();
  }

  loadDestinations(): void {
    const pageIndex = 0;
const pageSize = 20;
    this.destinationService.getAll(pageIndex,pageSize).subscribe({
      next: (res) => {
        this.destinations = res.results;
      },
      error: () => {
        this.snackBar.open('Failed to load destinations', 'Close', { duration: 3000 });
      }
    });
  }

  onSubmit(): void {
    if (this.form.invalid) return;

    const routePayload: RouteRequest = this.form.value;
    this.isLoading = true;

    const request$ = this.data?.id
      ? this.routeService.update(this.data.id, routePayload)
      : this.routeService.create(routePayload);

    request$.subscribe({
      next: () => {
        this.snackBar.open('Route saved successfully!', 'Close', { duration: 3000 });
        this.dialogRef.close(true);
      },
      error: () => {
        this.snackBar.open('Error saving route. Try again.', 'Close', { duration: 3000 });
        this.isLoading = false;
      }
    });
  }

  onCancel(): void {
    this.dialogRef.close();
  }
}