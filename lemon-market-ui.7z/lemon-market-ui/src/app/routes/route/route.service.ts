import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { PageOfResponseDTO, RouteRequest, RouteResponse } from './route';


@Injectable({
  providedIn: 'root'
})
export class RouteService {
private http = inject(HttpClient);
  private baseUrl = 'http://localhost:8080/api/v1/routes';

  list(pageIndex: number = 0, pageSize: number = 20): Observable<PageOfResponseDTO<RouteResponse>> {
    let params = new HttpParams()
      .set('pageIndex', pageIndex.toString())
      .set('pageSize', pageSize.toString());

    return this.http.get<PageOfResponseDTO<RouteResponse>>(this.baseUrl, { params });
  }

  getById(id: number): Observable<RouteResponse> {
    return this.http.get<RouteResponse>(`${this.baseUrl}/${id}`);
  }

  getByCode(code: string): Observable<RouteResponse> {
    return this.http.get<RouteResponse>(`${this.baseUrl}/by-code/${code}`);
  }

  create(route: RouteRequest): Observable<RouteResponse> {
    return this.http.post<RouteResponse>(this.baseUrl, route);
  }

  update(id: number, route: RouteRequest): Observable<RouteResponse> {
    return this.http.put<RouteResponse>(`${this.baseUrl}/${id}`, route);
  }

  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }  
}
