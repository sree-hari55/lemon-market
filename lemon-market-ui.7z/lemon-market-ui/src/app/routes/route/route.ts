export interface PageOfResponseDTO<T> {
  totalResult: number;
  pageIndex: number;
  itemsPerPage: number;
  results: T[];
}

export interface RouteRequest {
  routeCode: string;
  name: string;
  originCode: string;
  destinationCode: string;
  servicePrice: number;  // use number instead of BigDecimal
}

export interface RouteResponse {
  id: number;
  routeCode: string;
  name: string;
  originCode: string;
  originName: string;
  destinationCode: string;
  destinationName: string;
  servicePrice: number;
  createdAt: string;  // ISO date string
  updatedAt: string;  // ISO date string
}

