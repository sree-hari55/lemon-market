import { Component, inject, OnInit } from '@angular/core';
import { RouteService } from '../route.service';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { RouteResponse } from '../route';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { RouteForm } from '../route-form/route-form';

@Component({
  selector: 'app-route-list',
  imports: [
     CommonModule,
    MatTableModule,
    MatPaginatorModule,
    MatButtonModule,
    MatIconModule,
  ],
  templateUrl: './route-list.html',
  styleUrl: './route-list.css'
})
export class RouteList implements OnInit {
  private routeService = inject(RouteService);
  private dialog = inject(MatDialog);
  private snackBar = inject(MatSnackBar);

  routes: RouteResponse[] = [];
  totalResults = 0;
  pageIndex = 0;
  pageSize = 10;
  displayedColumns = ['routeCode', 'name', 'originName', 'destinationName', 'servicePrice', 'actions'];

  ngOnInit() {
    this.loadRoutes();
  }

  loadRoutes() {
    this.routeService.list(this.pageIndex, this.pageSize).subscribe({
      next: (data) => {
        this.routes = data.results;
        this.totalResults = data.totalResult;
      },
      error: () => {
        this.snackBar.open('Failed to load routes', 'Close', { duration: 3000 });
      },
    });
  }

  onPageChange(event: PageEvent) {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.loadRoutes();
  }

  addRoute() {
    const dialogRef = this.dialog.open(RouteForm, {
      width: '400px',
      data: null,
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.loadRoutes();
      }
    });
  }

  editRoute(route: RouteResponse) {
    const dialogRef = this.dialog.open(RouteForm, {
      width: '400px',
      data: route,
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.loadRoutes();
      }
    });
  }

  deleteRoute(route: RouteResponse) {
    if (confirm(`Delete route "${route.name}"?`)) {
      this.routeService.delete(route.id).subscribe({
        next: () => {
          this.snackBar.open('Route deleted', 'Close', { duration: 2000 });
          this.loadRoutes();
        },
        error: () => {
          this.snackBar.open('Failed to delete route', 'Close', { duration: 3000 });
        },
      });
    }
  }
}