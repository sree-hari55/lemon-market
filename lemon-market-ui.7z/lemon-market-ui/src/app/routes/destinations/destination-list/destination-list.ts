import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { DestinationResponseDTO } from '../destination.model';
import { DestinationService } from '../destination-service';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { DestinationForm } from '../destination-form/destination-form';

@Component({
  selector: 'app-destination-list',
   imports: [CommonModule, MatTableModule, MatButtonModule, MatIconModule, MatDialogModule, MatSnackBarModule,MatPaginatorModule],
  templateUrl: './destination-list.html',
  styleUrl: './destination-list.css'
})
export class DestinationList {
private service = inject(DestinationService);
  private dialog = inject(MatDialog);
  private snackBar = inject(MatSnackBar);

  destinations: DestinationResponseDTO[] = [];
  displayedColumns: string[] = ['code', 'name', 'location', 'active', 'actions'];

  // Pagination variables
  totalResults = 0;
  pageSize = 10;
  currentPage = 0;

  constructor() {
    this.loadDestinations();
  }

  loadDestinations(page: number = this.currentPage, size: number = this.pageSize): void {
    this.service.getAll(page, size).subscribe((response) => {
      this.destinations = response.results;
      this.totalResults = response.totalResult;
      this.pageSize = response.itemsPerPage;
      this.currentPage = response.pageIndex - 1; // backend returns 1-based pageIndex
    });
  }

  onPageChange(event: PageEvent): void {
    this.pageSize = event.pageSize;
    this.currentPage = event.pageIndex;
    this.loadDestinations(this.currentPage, this.pageSize);
  }

  openForm(destination?: DestinationResponseDTO): void {
    const dialogRef = this.dialog.open(DestinationForm, {
      width: '400px',
      data: destination || null,
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.loadDestinations();
      }
    });
  }

  delete(id: number): void {
    if (confirm('Are you sure you want to delete this destination?')) {
      this.service.delete(id).subscribe(() => {
        this.snackBar.open('Deleted successfully', 'Close', { duration: 3000 });
        this.loadDestinations();
      });
    }
  }
}