import { Component, Inject, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DestinationService } from '../destination-service';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { DestinationRequestDTO, DestinationResponseDTO } from '../destination.model';

@Component({
  selector: 'app-destination-form',
  imports: [CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSlideToggleModule,
    MatDialogModule,
    MatButtonModule,
    MatSnackBarModule,],
  templateUrl: './destination-form.html',
  styleUrl: './destination-form.css'
})
export class DestinationForm {
private fb = inject(FormBuilder);
  private service = inject(DestinationService);
  private dialogRef = inject(MatDialogRef<DestinationForm>);
  private snackBar = inject(MatSnackBar);

  form: FormGroup;

  // Edit mode or create mode
  isEditMode = false;

  constructor(@Inject(MAT_DIALOG_DATA) public data: DestinationResponseDTO | null) {
    this.form = this.fb.group({
      code: ['', Validators.required],
      name: ['', Validators.required],
      location: ['', Validators.required],
      active: [true],
    });

    if (data) {
      this.isEditMode = true;
      this.form.patchValue({
        code: data.code,
        name: data.name,
        location: data.location,
        active: data.active,
      });
      // Optionally disable code editing in edit mode:
      this.form.get('code')?.disable();
    }
  }

  onSubmit(): void {
    if (this.form.invalid) return;

    // Get form value, including disabled controls like code if disabled
    const formValue: DestinationRequestDTO = {
      ...this.form.getRawValue(),
    };

    if (this.isEditMode && this.data?.id) {
      this.service.update(this.data.id, formValue).subscribe({
        next: (res) => {
          this.snackBar.open('Destination updated', 'Close', { duration: 3000 });
          this.dialogRef.close(true);
        },
        error: () => {
          this.snackBar.open('Error updating destination', 'Close', { duration: 3000 });
        },
      });
    } else {
      this.service.create(formValue).subscribe({
        next: (res) => {
          this.snackBar.open('Destination created', 'Close', { duration: 3000 });
          this.dialogRef.close(true);
        },
        error: () => {
          this.snackBar.open('Error creating destination', 'Close', { duration: 3000 });
        },
      });
    }
  }

  onCancel(): void {
    this.dialogRef.close(false);
  }
}

