import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { DestinationRequestDTO, DestinationResponseDTO, PageOfResponseDTO } from './destination.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DestinationService {
  private baseUrl = 'http://localhost:8080/api/v1/destinations';

  constructor(private http: HttpClient) {}

  getAll(page: number = 0, size: number = 20): Observable<PageOfResponseDTO<DestinationResponseDTO>> {
    return this.http.get<PageOfResponseDTO<DestinationResponseDTO>>(`${this.baseUrl}?page=${page}&size=${size}`);
  }

  create(destination: DestinationRequestDTO): Observable<DestinationResponseDTO> {
    return this.http.post<DestinationResponseDTO>(this.baseUrl, destination);
  }

  update(id: number, destination: DestinationRequestDTO): Observable<DestinationResponseDTO> {
    return this.http.put<DestinationResponseDTO>(`${this.baseUrl}/${id}`, destination);
  }

  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }

  getById(id: number): Observable<DestinationResponseDTO> {
    return this.http.get<DestinationResponseDTO>(`${this.baseUrl}/${id}`);
  }
}
