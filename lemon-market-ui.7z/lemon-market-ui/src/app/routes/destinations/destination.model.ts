export interface DestinationRequestDTO {
  code: string;
  name: string;
  location: string;
  active: boolean;
}

export interface DestinationResponseDTO {
  id: number;
  code: string;
  name: string;
  location: string;
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface PageOfResponseDTO<T> {
  totalResult: number;
  pageIndex: number;
  itemsPerPage: number;
  results: T[];
}
