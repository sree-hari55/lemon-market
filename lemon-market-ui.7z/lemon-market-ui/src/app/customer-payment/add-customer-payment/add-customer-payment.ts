import { Component, OnInit } from '@angular/core';
import { CustomerDto, CustomerService } from '../../customer/service/add-customer.service';
import { Router, RouterModule } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import {CustomerPayDto, CustomerPaymentService } from '../customer-payment.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { debounceTime, map, Observable, of, startWith, switchMap } from 'rxjs';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatInputModule } from '@angular/material/input';

@Component({
  selector: 'app-add-customer-payment',
  standalone:true,
  imports: [RouterModule,ReactiveFormsModule,CommonModule,MatInputModule,MatAutocompleteModule],
  templateUrl: './add-customer-payment.html',
  styleUrl: './add-customer-payment.css'
})
export class AddCustomerPayment implements OnInit{

  paymentTypes: string[] = ['Cash', 'Credit Card', 'Online', 'Bank Transfer']; 
  selectedPaymentType: string = '';
  customers: CustomerDto[] = [];
  customerCtrl = new FormControl('');
  filteredCustomers!: Observable<CustomerDto[]>;
  selectedCustomer: CustomerDto | null = null;
  isFormVisible = true;  
  paymentForm!: FormGroup;
      
  constructor(private customerService:CustomerService,private fb: FormBuilder,private router: Router,private paymentService:CustomerPaymentService,private snackBar: MatSnackBar){}

  ngOnInit(): void {
    this.paymentForm = this.fb.group({
      paymentType: [''],
      customerId: [''],
      amount: [''], 
    });
   this.filteredCustomers = this.customerCtrl.valueChanges.pipe(
         debounceTime(300),
         startWith(''),
         switchMap(value => this._filterCustomers(value ?? ''))
       );
    }
   private _filterCustomers(value: string): Observable<CustomerDto[]> {
       if (typeof value !== 'string' || value.trim().length < 2) {
         // Don't search for less than 2 chars
         return of([]);
       }
       return this.customerService.searchCustomers(value.trim()).pipe(
     map(customers => customers)  // or simply remove map entirely if it's already CustomerDto[]
   );
   
     }
      displayCustomer(customer: CustomerDto): string {
       return customer ? `${customer.firstName} ${customer.lastName}` : '';
     }
     onCustomerSelected(customer: CustomerDto): void {
       this.selectedCustomer = customer;
       this.paymentForm.patchValue({ customerId: customer.id });
     }
  onSubmit(){
    const customerPayDto: CustomerPayDto = {
          ...this.paymentForm.value, // Spread sale form data
          customer: {
            id: this.paymentForm.value.customerId,
          }
        };
        console.log(customerPayDto)
        this.paymentService.createPayment(customerPayDto).subscribe(
          (response) => {
            this.closeSaleModal(); 
            this.paymentService.triggerRefresh();
           //  this.router.navigate(['/layout/customer/payments']);
          },
          (error) => {
          const errorMessage = error?.error?.message || 'Something went wrong. Please try again.';
          this.snackBar.open(errorMessage, 'Close', {
          duration: 5000,
          verticalPosition: 'top',
          panelClass: ['snackbar-error'], 
        });
      });
  }
  

closeModal() : void{
    this.isFormVisible = false;
    this.router.navigate(['/layout/customer/payments']);
  }

  onCustomerChange(event: any): void {
   const selectedCustomerId = Number(event.target.value);
   this.selectedCustomer = this.customers.find(customer => customer.id === selectedCustomerId)|| null;
  }
    closeSaleModal(): void {
    this.isFormVisible = false;
    this.router.navigate(['/layout/customer/payments']);
  }
  

}
