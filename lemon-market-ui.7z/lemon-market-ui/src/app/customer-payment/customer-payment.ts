import { CommonModule } from '@angular/common';
import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { CustomerFinalPaymentDto, CustomerPaymentService, PaymentSummary } from './customer-payment.service';
import { MatPaginator, MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { Router, RouterModule } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { PaymentHistory } from './payment-history/payment-history';
import { MatMenuModule } from '@angular/material/menu';

@Component({
  selector: 'app-customer-payment',
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatButtonModule,
    MatCardModule,
    MatIconModule,
    MatInputModule,
    FormsModule,
    RouterModule,
    MatPaginatorModule,
    MatMenuModule
  ],
  templateUrl: './customer-payment.html',
  styleUrl: './customer-payment.css'
})
export class CustomerPayment implements OnInit,AfterViewInit {
  displayedColumns: string[] = ['date','name', 'paidPayment', 'pendingPayment','totalPayment'];
  dataSource = new MatTableDataSource<CustomerFinalPaymentDto>();
  totalRevenue = 0;
  pendingPayments = 0;
  totalCustomers = 0;
  totalAdvancePayments =0;
  paidPayment =0;
  searchQuery = '';
  pageIndex = 1;
  pageSize = 10;
  totalResult = 0;
  rupeeSymbol = '\u20B9';


  @ViewChild(MatPaginator) paginator!: MatPaginator;

  constructor(private router:Router,private customerPaymentService: CustomerPaymentService,private dialog: MatDialog) {}
  ngAfterViewInit(): void {
  this.dataSource.paginator = this.paginator;
}
  ngOnInit(): void {
    this.loadPayments();
    this.loadPaymentSummary();
    this.customerPaymentService.refreshNeeded.subscribe(() => {
      this.loadPayments();
      this.loadPaymentSummary();
    });
  }
  loadPayments() {
    this.customerPaymentService.getFinalPayments(this.pageIndex,this.pageSize).subscribe({
      next: (data) => {
        
         this.dataSource.data = data.results;
        this.totalResult = data.totalResult;
        this.pageIndex = data.pageIndex;
      },
      error: (err) => {
        console.error('Failed to load customer data', err);
      },
    });
  }
  onPageChange(event: PageEvent) {
  this.pageIndex = event.pageIndex + 1; 
  this.pageSize = event.pageSize;
  this.loadPayments();
}
  loadPaymentSummary() {
    this.customerPaymentService.getPaymentSummary().subscribe({
      next: (data: PaymentSummary) => {
        this.totalRevenue = data.totalPayments;
        this.pendingPayments = data.pendingAmount;
        this.totalCustomers = data.totalCustomers;
        this.paidPayment = data.paidPayment;
        this.totalAdvancePayments = data.totalAdvancePayments;
      },
      error: (err) => {
        console.error('Failed to load customer data', err);
      }
    });
  }

  applyFilter(): void {
    this.dataSource.filter = this.searchQuery.trim().toLowerCase();
  }
/*
viewHistory(customer: any, type: 'advance' | 'paid'): void {
  const customerId = customer.customer.id;

  if (!customerId) {
    console.error('Invalid customer object or missing ID');
    return;
  }

  const historyObservable =
    type === 'advance'
      ? this.customerPaymentService.getCustomerAdvancePayhistroy(customerId)
      : this.customerPaymentService.getCustomerPayhistroy(customerId);

  historyObservable.subscribe({
    next: (history) => {
      this.dialog.open(PaymentHistory, {
        width: '800px',
        data: {
          customer,
          type,
          history
        }
      });
    },
    error: (err) => {
      console.error(`Error fetching ${type} payment history:`, err);
      // optionally show an error message on UI
    }
  });
}
*/
}
