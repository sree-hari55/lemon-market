import {  Component, ViewChild } from '@angular/core';
import { MatPaginator, MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { CommonModule } from '@angular/common';
import {HttpResponse } from '@angular/common/http';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { debounceTime, map, Observable, of, startWith, switchMap } from 'rxjs';
import { CustomerDto, CustomerService, PaginatedResponse } from '../../customer/service/add-customer.service';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { CustomerPaymentService, CustomerResponsePaymentDto } from '../customer-payment.service';
@Component({
  selector: 'app-payment-history',
  imports: [MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatButtonModule,
    MatCardModule,
    MatIconModule,
    MatTableModule,
    FormsModule,CommonModule,ReactiveFormsModule,MatAutocompleteModule,MatPaginatorModule],
  standalone:true,
  templateUrl: './payment-history.html',
  styleUrl: './payment-history.css'
})
export class PaymentHistory {
  customerCtrl = new FormControl('');
  fromDate: Date | null = null;
  toDate: Date | null = null;
  paymentType = '';
  customers: CustomerDto[] = [];
  filteredCustomers!: Observable<CustomerDto[]>;
  selectedCustomer: CustomerDto | null = null;
  selectedSearch='';
  fromDateCtrl = new FormControl('');
  toDateCtrl = new FormControl('');
  typeCtrl = new FormControl('');
  pageIndex = 1;
  pageSize = 10;
  totalResults = 0;


displayedColumns: string[] = ['createdDate', 'paymentType', 'depositAmount', 'withdrawalAmount', 'closingBalance'];
  dataSource = new MatTableDataSource<CustomerResponsePaymentDto>([]);

@ViewChild(MatPaginator) paginator!: MatPaginator;

//dataSource = new MatTableDataSource<any>([]); 

  constructor(private customerService:CustomerService, private customerPaymentService: CustomerPaymentService){}

  ngOnInit(): void {
    this.filteredCustomers = this.customerCtrl.valueChanges.pipe(
      debounceTime(300),
      startWith(''),
      switchMap(value => this._filterCustomers(value ?? ''))
    );
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }
   private _filterCustomers(value: string): Observable<CustomerDto[]> {
      if (typeof value !== 'string' || value.trim().length < 2) {
           return of([]);
      }
      return this.customerService.searchCustomers(value.trim()).pipe(
       map(customers => customers) 
     );   
   }

  displayCustomer(customer: CustomerDto): string {
    return customer ? `${customer.firstName} ${customer.lastName}` : '';
  }

  onCustomerSelected(customer: CustomerDto): void {
    this.selectedCustomer = customer;
  }

  clearFilters() {
    this.customerCtrl.reset();
    this.fromDateCtrl.reset();
    this.toDateCtrl.reset();
    this.typeCtrl.reset();
  }
  onPageChange(event: PageEvent) {
  this.pageIndex = event.pageIndex + 1; 
  this.pageSize = event.pageSize;
}

  applyFilter() {
 const filters: any = {};
  const customer = this.customerCtrl.value;
  const fromDate = this.fromDateCtrl.value;
  const toDate = this.toDateCtrl.value;
  const type = this.typeCtrl.value;

  if (!customer || typeof customer !== 'object') {
    console.warn('[PaymentHistory] Invalid customer selection');
    return;
  }
  const dto = customer as CustomerDto;
    filters.customerID = dto.id;
    filters.customerFirstName = dto.firstName;
    filters.customerLastName = dto.lastName;
   if (fromDate) filters.fromDate = new Date(fromDate).toISOString();
  if (toDate) filters.toDate = new Date(toDate).toISOString();
  if (type) filters.paymentType = type;

   const serviceCall = this.getPaymentServiceMethod(type);
   if (!serviceCall) {
    console.warn(`[PaymentHistory] Unsupported payment type: ${type}`);
    return;
  }
  serviceCall(filters, this.pageIndex, this.pageSize).subscribe({
    next: (response: PaginatedResponse<CustomerResponsePaymentDto>) => {
      this.dataSource.data = response.results; 
      this.paginator.length = response.totalResult;
    },
    error: (err) => {
      console.error('[PaymentHistory] Failed to fetch filtered payments:', err);
    }
  });
  }
  private getPaymentServiceMethod(type: string | null): ((f: any, p: number, s: number) => Observable<PaginatedResponse<CustomerResponsePaymentDto>>) | null {
  switch (type) {
    case 'Normal':
      return this.customerPaymentService.filterNormalCustomerPayments.bind(this.customerPaymentService);
    case 'Advance':
      return this.customerPaymentService.filterAdvanceCustomerPayments.bind(this.customerPaymentService);
    default:
      return null;
  }
}
  
  downloadCSV() {
    console.log('Download CSV');
  }

downloadPDF(): void {
  const filters: any = {};
  const customer = this.customerCtrl.value;
  const fromDate = this.fromDateCtrl.value;
  const toDate = this.toDateCtrl.value;
  const type = this.typeCtrl.value;

  if (!customer || typeof customer !== 'object') {
    console.warn('[PaymentHistory] Invalid customer selection');
    return;
  }

  const dto = customer as CustomerDto;
  filters.customerID = dto.id;
  filters.customerFirstName = dto.firstName;
  filters.customerLastName = dto.lastName;
  if (fromDate) filters.fromDate = new Date(fromDate).toISOString();
  if (toDate) filters.toDate = new Date(toDate).toISOString();
  if (type) filters.paymentType = type;

  // 👇 Update the observable type to HttpResponse<Blob>
  let request$: Observable<HttpResponse<Blob>>;
  if (type === 'Normal') {
    request$ = this.customerPaymentService.downloadCustomerPaymentReportFile(filters, 'PDF');
  } else if (type === 'Advance') {
    request$ = this.customerPaymentService.downloadAdvanceCustomerPaymentReportFile(filters, 'PDF');
  } else {
    console.warn('Invalid payment type');
    return;
  }

  request$.subscribe({
    next: (response: HttpResponse<Blob>) => {
      const blob = response.body!;
      const contentType = blob.type;

      if (contentType !== 'application/pdf') {
        console.error('Downloaded blob is not a PDF');
        blob.text().then(text => console.log('Response content:', text));
        return;
      }

      const contentDisposition = response.headers.get('Content-Disposition');
      let filename = `Customer-Payment-Report-${type}-${new Date().toISOString().split('T')[0]}.pdf`;

      if (contentDisposition) {
        const matches = /filename="?([^"]+)"?/.exec(contentDisposition);
        if (matches?.[1]) {
          filename = matches[1];
        }
      }

      const fileURL = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = fileURL;
      a.download = filename;

      document.body.appendChild(a);
      setTimeout(() => {
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(fileURL);
      }, 100);
    },
    error: (err) => {
      console.error('PDF download failed:', err);
    }
  });
}

  

}

