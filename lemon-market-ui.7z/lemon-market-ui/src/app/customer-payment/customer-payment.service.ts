import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { CustomerDto, PaginatedResponse } from '../customer/service/add-customer.service';
import { Observable, Subject, tap } from 'rxjs';

export interface CustomerFinalPaymentDto {
  id: number;
  advancePayment: number;
  paidPayment: number;
  totalPayment: number;
  pendingPayment: number;
  createdDate: Date;
  modifiedDate:Date;
  customer:CustomerDto
}
export interface CustomerPayDto{
  id: number;
  paymentType: number;
  amount: number;
  createdDate: Date;
  modifiedDate:Date;
  customer:CustomerDto
} 

export interface CustomerAdvancePayDto{
  id: number;
  paymentType: number;
  amount: number;
  createdDate: Date;
  modifiedDate:Date;
  customer:CustomerDto
} 

export interface ReturnAdvancePayDto{
  id: number;
  paymentType: number;
  amount: number;
  createdDate: Date;
  modifiedDate:Date;
  customer:CustomerDto
}
export interface PaymentSummary{
    totalCustomers: number;
  paidPayment: number;
  totalPayments: number;
  pendingAmount: number;
  totalAdvancePayments: number;
}

export interface CustomerResponsePaymentDto{
id: number;
paymentType: string;
narration: string;
withdrawalAmount:number;
depositAmount: number;
closingBalance:number;
createdDate: Date;
modifiedDate:Date;
customer:CustomerDto;
}

export interface CustomerPaymentFilterDto {
  customerID?: number;
  customerFirstName?: string;
  customerLastName?: string;
  paymentType?: string;
  fromDate?: string; // use ISO string for date/time
  toDate?: string;
}

@Injectable({
  providedIn: 'root',
})
export class CustomerPaymentService {
  private apiUrl = 'http://localhost:9090/api/customer/final-payments';
  private addPaymentUrl ='http://localhost:9090/api/customer-payment';
  private paymentHistroyUrl ='http://localhost:9090/api/customer-pay/customers';
  private paymentSummaryUrl ='http://localhost:9090/api/customer/final-payments/summary';
  private filterNormalPaymentsUrl ='http://localhost:9090/api/customer-payment/filter';
  private filterAdvancePaymentsUrl ='http://localhost:9090/api/customer/advance-payments/filter';
  private downloadPaymentReportUrl ='http://localhost:9090/api/customer-payment/download';
  private downloadAdvancePaymentReportUrl ='http://localhost:9090/api/customer/advance-payments/download';
  private _refreshNeeded = new Subject<void>();
refreshNeeded = this._refreshNeeded.asObservable();

triggerRefresh() {
  this._refreshNeeded.next();
}


  constructor(private http: HttpClient) {}

  getFinalPayments(pageIndex: number, pageSize: number): Observable<PaginatedResponse<CustomerFinalPaymentDto>> {
    return this.http.get<PaginatedResponse<CustomerFinalPaymentDto>>(
      `${this.apiUrl}?pageIndex=${pageIndex}&pageSize=${pageSize}`
    );
  }
  createPayment(dto: CustomerPayDto): Observable<CustomerPayDto> {
    return this.http.post<CustomerPayDto>(this.addPaymentUrl, dto);
  }

  getCustomerPayhistroy(customerId:number): Observable<CustomerPayDto[]>{
    const url = `${this.paymentHistroyUrl}/${customerId}`;
    return this.http.get<CustomerPayDto[]>(url);
  }

  getPaymentSummary(): Observable<PaymentSummary> {
    return this.http.get<PaymentSummary>(this.paymentSummaryUrl);
  }

filterNormalCustomerPayments(filterDto: CustomerPaymentFilterDto, pageIndex: number = 0, pageSize: number = 10): Observable<PaginatedResponse<CustomerResponsePaymentDto>> {
    const params = new HttpParams()
      .set('pageIndex', pageIndex.toString())
      .set('pageSize', pageSize.toString());

    return this.http.post<PaginatedResponse<CustomerResponsePaymentDto>>(this.filterNormalPaymentsUrl, filterDto, { params });
  }

  filterAdvanceCustomerPayments(filterDto: CustomerPaymentFilterDto, pageIndex: number = 0, pageSize: number = 10): Observable<PaginatedResponse<CustomerResponsePaymentDto>> {
    const params = new HttpParams()
      .set('pageIndex', pageIndex.toString())
      .set('pageSize', pageSize.toString());

    return this.http.post<PaginatedResponse<CustomerResponsePaymentDto>>(this.filterAdvancePaymentsUrl, filterDto, { params });
  }
downloadCustomerPaymentReportFile(filterDto: CustomerPaymentFilterDto, fileType: string): Observable<HttpResponse<Blob>> {
  return this.http.post(`${this.downloadPaymentReportUrl}?fileType=${fileType}`, filterDto, {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
    responseType: 'blob',
    observe: 'response'
  });
}


downloadAdvanceCustomerPaymentReportFile(filterDto: CustomerPaymentFilterDto, fileType: string): Observable<HttpResponse<Blob>> {
  return this.http.post(`${this.downloadAdvancePaymentReportUrl}?fileType=${fileType}`, filterDto, {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
    responseType: 'blob',
    observe: 'response'
  });
}


}
