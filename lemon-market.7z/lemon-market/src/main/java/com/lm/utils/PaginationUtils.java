package com.lm.utils;

import com.lm.dto.PageOfResp;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

public class PaginationUtils {

    public static Pageable initPageable(int pageIndex, int pageSize) {
        if (pageIndex < 1) {
            pageIndex = 1;
        }
        if (pageSize < 1) {
            pageSize = 10;
        }
        return PageRequest.of(pageIndex - 1, pageSize);
    }

    public static <T> PageOfResp<T> convertToPageResponse(Page<T> page) {
        PageOfResp<T> pageOfResp = new PageOfResp<>();
        pageOfResp.setPageIndex(page.getNumber() + 1);
        pageOfResp.setItemsPerPage(page.getSize());
        pageOfResp.setTotalResult(page.getTotalElements());
        pageOfResp.setResults(page.getContent());
        return pageOfResp;
    }

}
