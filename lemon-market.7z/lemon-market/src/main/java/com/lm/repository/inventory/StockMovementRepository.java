package com.lm.repository.inventory;

import com.lm.entity.inventory.StockMovement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface StockMovementRepository extends JpaRepository<StockMovement, Long> {
    @Modifying
    @Transactional
    @Query("DELETE FROM StockMovement i WHERE i.inventory.id = :inventoryId")
    void deleteByInventoryId(@Param("inventoryId") Long inventoryId);
}

