package com.lm.repository.inventory;

import com.lm.entity.inventory.InventoryItem;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface InventoryItemRepository extends JpaRepository<InventoryItem, Long>, JpaSpecificationExecutor<InventoryItem> {
    Optional<InventoryItem> findByPurchaseIdAndExpiryDate(Long purchaseId, LocalDateTime expiryDate);
    List<InventoryItem> findByAvailableStockKgLessThan(BigDecimal threshold);
    List<InventoryItem> findByQualityAndLocation(String lemonType, String location);

    @Query(value = """
    SELECT * FROM inventory_items 
    ORDER BY COALESCE(modified_date, creation_date) DESC
    """,
            countQuery = "SELECT COUNT(*) FROM inventory_items",
            nativeQuery = true)
    Page<InventoryItem> findAllOrderByLatestDateDesc(Pageable pageable);


    Optional<InventoryItem> findFirstByQualityOrderByCreationDateDesc(String quality);

    @Modifying
    @Transactional
    @Query("DELETE FROM InventoryItem i WHERE i.purchase.id = :purchaseId")
    void deleteByPurchaseId(@Param("purchaseId") Long purchaseId);


    Optional<InventoryItem> findByPurchaseId(Long purchaseId);
    @Modifying
    @Transactional
    @Query("DELETE FROM InventoryItem i WHERE i.sale.id = :saleId")
    void deleteBySaleId(@Param("saleId")Long saleId);

    Optional<InventoryItem> findBySaleId(Long saleId);
}
