package com.lm.repository;


import com.lm.dto.PurchaseSummaryDto;
import com.lm.entity.Purchase;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PurchaseRepository extends JpaRepository<Purchase, Long> , JpaSpecificationExecutor<Purchase> {
    @Query(
            value = "SELECT new com.lm.dto.PurchaseSummaryDto( " +
                    "p.creationDate, " +
                    "p.lemonType, " +
                    "p.location, " +
                    "SUM(p.weight), " +
                    "SUM(p.finalAmount), " +
                    "CAST(AVG(p.pricePerKg) AS BigDecimal) ) " +
                    "FROM Purchase p " +
                    "GROUP BY p.creationDate, p.lemonType, p.location " +
                    "ORDER BY p.creationDate",
            countQuery = "SELECT COUNT(DISTINCT p.creationDate || p.lemonType || p.location) " +
                    "FROM Purchase p"
    )
    Page<PurchaseSummaryDto> getPurchaseSummary(Pageable pageable);

}

