package com.lm.repository.sales;

import com.lm.dto.sales.SaleSummaryDto;
import com.lm.entity.sales.Sale;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface SaleRepository  extends JpaRepository<Sale, Long>, JpaSpecificationExecutor<Sale> {

   /* @Query("""
    SELECT new com.lm.dto.sales.SaleSummaryDto(
        FUNCTION('DATE', s.creationDate),
        s.quality,
        SUM(s.quantityKg),
        AVG(s.unitPrice),
        SUM(s.amount),
        s.location
    )
    FROM Sale s
    GROUP BY FUNCTION('DATE', s.creationDate), s.quality, s.location
    ORDER BY FUNCTION('DATE', s.creationDate) DESC
""")
    Page<SaleSummaryDto> findSaleSummary(Pageable pageable);*/



}