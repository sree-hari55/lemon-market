package com.lm.repository.customer;

import com.lm.entity.customer.CustomerFinalPayment;
import com.lm.entity.farmer.FarmerFinalPayment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CustomerFinalPaymentRepository extends JpaRepository<CustomerFinalPayment,Long> {
    Optional<CustomerFinalPayment> findByCustomerId(Long id);
}
