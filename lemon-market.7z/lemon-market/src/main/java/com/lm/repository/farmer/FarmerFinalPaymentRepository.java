package com.lm.repository.farmer;

import com.lm.entity.farmer.FarmerFinalPayment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface FarmerFinalPaymentRepository extends JpaRepository<FarmerFinalPayment, Long> {
    Optional<FarmerFinalPayment> findByFarmerId(Long id);
}
