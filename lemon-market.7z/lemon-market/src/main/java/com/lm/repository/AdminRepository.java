package com.lm.repository;

import com.lm.entity.Admins;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface AdminRepository extends JpaRepository<Admins,Long> {
    Optional<Admins> findByUserNameAndPasswordAndMarketName(String userName, String password, String marketName);
}
