package com.lm.entity.sales;

public enum PaymentStatus {
    PAID,
    PENDING
}

