package com.lm.entity.inventory;


import com.lm.entity.Purchase;
import com.lm.entity.sales.Sale;
import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "inventory_items")
@Getter
@Setter
@ToString(exclude = {"purchase", "sale"})
public class InventoryItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "purchase_id")
    private Purchase purchase;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sale_id")
    private Sale sale;
    private BigDecimal stockInKg;
    private BigDecimal stockOutKg;
    private BigDecimal availableStockKg;
    private BigDecimal pricePerKg;
    private LocalDateTime expiryDate;
    private BigDecimal reorderLevel;
    private String status;
    private String location;
    private String quality;
    private String transactionType;
    private String participantName;
    private String notes;
    private LocalDateTime creationDate;
    private LocalDateTime modifiedDate;

    @PrePersist
    protected void onCreate() {
        creationDate = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        modifiedDate = LocalDateTime.now();
    }
}

