package com.lm.entity.inventory;

public enum TransactionType {
    PURCHASE,
    SALE,
    ADJUSTMENT
}
