package com.lm.entity.accounting;


import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

@Entity
@Table(name = "payment")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Payment {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "invoice_id")
    private Invoice invoice;

    private BigDecimal amount;
    private OffsetDateTime paymentDate;
    private String mode; // CASH, BANK_TRANSFER, CARD, ONLINE, CHEQUE
    private String reference; // tx id or cheque number
    private String receivedBy; // username
}

