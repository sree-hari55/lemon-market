package com.lm.entity.customer;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.lm.entity.farmer.Farmer;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
@Entity
@Table(name = "customer_Final_payments")
@Getter
@Setter
public class CustomerFinalPayment implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "advance_payment")
    private BigDecimal advancePayment;
    @Column(name = "paid_payment")
    private BigDecimal paidPayment;
    @Column(name = "total_payment")
    private BigDecimal totalPayment;
    @Column(name = "pending_payment")
    private BigDecimal pendingPayment;

    @Column(name ="created_date")
    private LocalDateTime createdDate;
    @Column(name ="modified_date")
    private LocalDateTime modifiedDate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "farmer_id")
    @JsonIgnore
    private Customer customer;
    @PrePersist
    protected void onCreate() {
        createdDate = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        modifiedDate = LocalDateTime.now();
    }

}
