package com.lm.entity.farmer;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.lm.entity.farmer.Farmer;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
@Entity
@Table(name = "farmer_payments")
@Getter
@Setter
public class FarmerPayment implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "payment_type")
    private String paymentType;

    private String narration;

    @Column(name = "withdrawal_amount")
    private BigDecimal withdrawalAmount;

    @Column(name = "deposit_amount")
    private BigDecimal depositAmount;

    @Column(name = "closing_balance")
    private BigDecimal closingBalance;

    @Column(name ="created_date")
    private LocalDateTime createdDate;
    @Column(name ="modified_date")
    private LocalDateTime modifiedDate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "farmer_id")
    @JsonIgnore
    private Farmer farmer;
    @PrePersist
    protected void onCreate() {
        createdDate = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        modifiedDate = LocalDateTime.now();
    }
}
