package com.lm.entity.sales;

import com.lm.entity.inventory.InventoryItem;
import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;

@Entity
@Table(name = "sales_order_item")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class SalesOrderItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private InventoryItem inventoryItem; // reference to inventory item
    private String itemName;
    private Integer quantity;
    private BigDecimal unitPrice;
    private BigDecimal lineTotal;

    /*@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sales_order_id")
   // private SalesOrder salesOrder;*/
}
