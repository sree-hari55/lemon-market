package com.lm.entity.sales;


import jakarta.persistence.*;
import lombok.*;
import java.time.OffsetDateTime;

@Entity
@Table(name = "audit_log")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class AuditLog {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String moduleName;
    private String action; // CREATE, UPDATE, DELETE, CONFIRM
    private Long entityId;
    private String username;
    private String details;
    private OffsetDateTime timestamp;
}

