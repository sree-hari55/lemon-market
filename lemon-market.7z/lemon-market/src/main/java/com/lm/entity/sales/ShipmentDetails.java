package com.lm.entity.sales;

import jakarta.persistence.Embeddable;
import lombok.*;

@Embeddable
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ShipmentDetails {
    private String carrier;
    private String trackingNumber;
    private String originCountry;
    private String destinationCountry;
    private String portOfLoading;
    private String portOfDischarge;
}

