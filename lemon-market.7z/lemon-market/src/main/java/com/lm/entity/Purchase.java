package com.lm.entity;


import com.lm.entity.farmer.Farmer;
import jakarta.persistence.*;
import lombok.*;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;


@Entity
@Table(name = "purchase")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Purchase implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private BigDecimal weight;
    private BigDecimal pricePerKg;
    private int transportDistanceKm;
    private BigDecimal transportCharge;
    private BigDecimal commission;
    private String vehicleNumber;
    private BigDecimal finalAmount;
    private int bags;
    private String lemonType;
    private String location;

    private LocalDateTime creationDate;
    private LocalDateTime modifiedDate;
    private String createdBy;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "farmer_id")
    private Farmer farmer;
    @PrePersist
    protected void onCreate() {
        creationDate = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        modifiedDate = LocalDateTime.now();
    }

}

