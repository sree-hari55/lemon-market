package com.lm.entity.inventory;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "stock_movements")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class StockMovement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "inventory_id")
    private InventoryItem inventory;

    private BigDecimal quantityMoved;  // Quantity moved (in kg)
    private String movementType;      // Type of movement (e.g., Purchase, Sale, Return, Damaged)
    private LocalDateTime movementDate; // Date of movement

    @PrePersist
    protected void onCreate() {
        movementDate = LocalDateTime.now();
    }
}

