package com.lm.entity.accounting;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;

@Entity
@Table(name = "invoice")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Invoice {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String invoiceNumber; // e.g. INV-20250826-0001
    private Long salesOrderId;    // link to SalesOrder
    private Long customerId;

    private BigDecimal totalAmount;
    private BigDecimal balanceDue; // totalAmount - sum(payments)

    @Enumerated(EnumType.STRING)
    private Status status; // PENDING, PARTIAL, PAID, CANCELLED

    private OffsetDateTime issueDate;
    private OffsetDateTime dueDate;

    @OneToMany(mappedBy = "invoice", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<Payment> payments;

    @Version
    private Long version;

    public enum Status { PENDING, PARTIAL, PAID, CANCELLED }
}

