package com.lm.entity.sales;

public enum SaleStatus {
    COMPLETED;
}
