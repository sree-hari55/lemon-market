package com.lm.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Entity
@Table(name = "markets")
@Setter
@Getter
public class Market implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotBlank(message = "Market name is required")
	@Column(nullable = false)
	private String name;

	@NotBlank(message = "Owner name is required")
	@Column(nullable = false)
	private String ownerName;
}

