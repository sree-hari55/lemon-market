package com.lm.entity.sales;


import com.lm.entity.customer.Customer;
import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;


@Entity
@Table(name = "sales")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Sale {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String quality;
    private String location;
    private String paymentStatus;
    private BigDecimal quantityKg;
    private BigDecimal unitPrice;
    private String status;
    private String createdBy;
    private BigDecimal bags;
    private String vehicleNumber;
    private BigDecimal amount;
    @JoinColumn(name = "customer_id")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    private LocalDateTime creationDate;
    private LocalDateTime modifiedDate;

    @PrePersist
    protected void onCreate() {
        creationDate = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        modifiedDate = LocalDateTime.now();
    }

}
