package com.lm.entity.sales;

public enum LemonQuality {
    FRESH,
    SECOND_QUALITY
}
