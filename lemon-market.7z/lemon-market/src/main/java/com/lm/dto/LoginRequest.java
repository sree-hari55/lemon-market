package com.lm.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class LoginRequest {
    @NotBlank(message = "user name is mandatory")
    private String userName;
    @NotBlank(message = "password is mandatory")
    private String password;
    private String marketName;
    private boolean isAdmin = false;
}
