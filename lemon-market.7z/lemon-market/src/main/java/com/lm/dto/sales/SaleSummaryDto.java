package com.lm.dto.sales;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

@Getter
@Setter
public class SaleSummaryDto {
    private LocalDateTime date;
    private String lemonType;
    private String location;
    private BigDecimal totalQuantity;
    private BigDecimal totalCost;
    private BigDecimal avgCost;

    public SaleSummaryDto(Date date, String lemonType, BigDecimal quantitySoldKg,
                          BigDecimal pricePerKg, BigDecimal totalAmount, String location) {
        if (date != null) {
            this.date = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate().atStartOfDay();
        } else {
            this.date = null;
        }
        this.lemonType = lemonType;
        this.totalQuantity = quantitySoldKg != null ? quantitySoldKg : BigDecimal.ZERO;
        this.avgCost = pricePerKg != null ? pricePerKg : BigDecimal.ZERO;
        this.totalCost = totalAmount != null ? totalAmount : BigDecimal.ZERO;
        this.location = location;
    }


}