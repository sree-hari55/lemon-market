package com.lm.dto.farmer;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
public class FarmerPayDto {

    private Long id;
    private String paymentType;
    private BigDecimal amount;
    private LocalDateTime createdDate;
    private LocalDateTime modifiedDate;

    private FarmerDto farmer;

}
