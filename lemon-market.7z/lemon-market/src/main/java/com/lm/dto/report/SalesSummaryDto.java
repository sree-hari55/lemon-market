package com.lm.dto.report;

import lombok.AllArgsConstructor;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@AllArgsConstructor
public class SalesSummaryDto {
    private LocalDate day;
    private Long orders;
    private Long itemsSold;
    private BigDecimal totalRevenue;
}
