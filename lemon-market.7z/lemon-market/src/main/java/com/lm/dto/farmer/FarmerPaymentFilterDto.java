package com.lm.dto.farmer;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.Date;

@Setter
@Getter
public class FarmerPaymentFilterDto {
    private Long farmerID;
    private String farmerFirstName;
    private String farmerLastName;
    private String paymentType;
    private LocalDateTime fromDate;
    private LocalDateTime toDate;
}
