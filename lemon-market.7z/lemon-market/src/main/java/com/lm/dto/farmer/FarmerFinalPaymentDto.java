package com.lm.dto.farmer;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;
@Setter
@Getter
public class FarmerFinalPaymentDto {
        private Long id;
        private BigDecimal advancePayment;
        private BigDecimal paidPayment;
        private BigDecimal totalPayment;
        private BigDecimal pendingPayment;
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        private LocalDateTime createdDate;
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        private LocalDateTime modifiedDate;
        private FarmerDto farmerDto;

}
