package com.lm.dto.customer;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
public class CustomerPaymentSummaryDto {
    private BigDecimal paidPayment;
    private BigDecimal pendingAmount;
    private BigDecimal totalPayments;
    private BigDecimal totalAdvancePayments;
    private long totalCustomers;
}

