package com.lm.dto.inventory;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public record InventoryItemDTO(
        Long id,
        String quality,
        BigDecimal stockInKg,
        BigDecimal stockOutKg,
        BigDecimal availableStockKg,
        BigDecimal pricePerKg,
        LocalDateTime expiryDate,
        String status,
        String location,
        String transactionType,
        String participantName,
        String notes,
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        LocalDateTime lastUpdated) {}


