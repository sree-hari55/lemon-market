package com.lm.dto.customer;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Setter
@Getter
public class CustomerPaymentFilterDto {
    private Long customerID;
    private String customerFirstName;
    private String customerLastName;
    private String paymentType;
    private LocalDateTime fromDate;
    private LocalDateTime toDate;
}
