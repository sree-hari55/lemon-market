package com.lm.dto.inventory;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
@Getter
@Setter
@Builder
public class InventorySummaryDto {
    private LemonStockDto availableLemonStock;
    private LemonStockDto soldLemonStock;

    @Getter
    @Setter
    @Builder
    public static class LemonStockDto {
        private BigDecimal freshKg;
        private BigDecimal freshTons;
        private BigDecimal secondQualityKg;
        private BigDecimal secondQualityTons;
    }
}

