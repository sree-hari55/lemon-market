package com.lm.dto.inventory;

import com.lm.entity.inventory.TransactionType;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public record StockTransactionRequest(
        @NotNull Long productId,
        @NotNull TransactionType transactionType,
        @Min(1) Integer quantity,
        String warehouse,
        Long referenceId
) {}
