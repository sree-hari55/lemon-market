package com.lm.dto.accounting;


import lombok.Data;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

@Data
public class PaymentDto {
    private Long id;
    private Long invoiceId;
    private BigDecimal amount;
    private OffsetDateTime paymentDate;
    private String mode;
    private String reference;
    private String receivedBy;
}

