package com.lm.dto.farmer;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;


@Getter
@Setter
@NoArgsConstructor
public class FarmerPaymentSummaryDto {
    private BigDecimal paidPayment;
    private BigDecimal pendingAmount;
    private BigDecimal totalPayments;
    private BigDecimal totalAdvancePayments;
    private long totalFarmers;
}
