package com.lm.dto.sales;

import lombok.Data;

@Data
public class ShipmentDetailsDto {
    private Long id;
    private String carrier;
    private String trackingNumber;
    private String originCountry;
    private String destinationCountry;
    private String status; // e.g. "PENDING", "SHIPPED", "DELIVERED"
}
