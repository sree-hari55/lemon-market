package com.lm.dto.sales;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
public class SalesOrderFilterDto {
    private String quality;
    private String location;
    private String paymentStatus;
    private String status;
    private String customerName;

    private LocalDateTime fromDate;
    private LocalDateTime toDate;

    private BigDecimal minQuantityKg;
    private BigDecimal maxQuantityKg;
}
