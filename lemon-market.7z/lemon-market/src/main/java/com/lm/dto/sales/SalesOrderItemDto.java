package com.lm.dto.sales;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class SalesOrderItemDto {
    private Long inventoryItemId;
    private String itemName;
    private Integer quantity;
    private BigDecimal unitPrice;
}