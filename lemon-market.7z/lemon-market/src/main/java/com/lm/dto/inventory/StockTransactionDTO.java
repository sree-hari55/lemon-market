package com.lm.dto.inventory;

import com.lm.entity.inventory.TransactionType;

import java.time.LocalDateTime;

//public record StockTransactionDTO(Long id, ProductDTO product, TransactionType transactionType, Integer quantity, LocalDateTime transactionDate, Long referenceId) {}
