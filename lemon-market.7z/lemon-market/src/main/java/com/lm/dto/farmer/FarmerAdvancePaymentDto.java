package com.lm.dto.farmer;


import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;
@Getter
@Setter
public class FarmerAdvancePaymentDto {

    private Long farmerId;
    private String paymentType;
    private BigDecimal amount;
    private boolean isInterest;
    private int interestRateInRupees;
    private LocalDateTime createdDate;
    private LocalDateTime modifiedDate;
    private FarmerDto farmer;
}
