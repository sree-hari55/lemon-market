package com.lm.dto.report;

import lombok.AllArgsConstructor;
import lombok.Data;
import java.time.LocalDate;

@Data
@AllArgsConstructor
public class StockMovementDto {
    private Long inventoryItemId;
    private String itemName;
    private LocalDate date;
    private Integer quantityIn;
    private Integer quantityOut;
    private Integer closingBalance;
}
