package com.lm.dto.sales;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.lm.entity.customer.Customer;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
public class SalesOrderDto {
    private Long id;
    private String quality;
    private String location;
    private String paymentStatus;
    private BigDecimal quantityKg;
    private BigDecimal unitPrice;
    private String status;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime creationDate;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime modifiedDate;
    private String createdBy;
    private int bags;
    private String vehicleNumber;
    private BigDecimal amount;
    private String customerName;
    @JsonIgnore
    private Customer customer;
}