package com.lm.dto.inventory;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
public class InventoryFilterDto {
    private String quality;
    private String status;
    private String location;
    private String transactionType;
    private String participantName;

    private LocalDateTime fromDate;
    private LocalDateTime toDate;

    private BigDecimal minAvailableStockKg;
    private BigDecimal maxAvailableStockKg;
}
