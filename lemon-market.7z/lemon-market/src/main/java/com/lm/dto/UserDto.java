package com.lm.dto;

import lombok.Data;

@Data
public class UserDto {

	private String name;
	private String phoneNumber;
	private String email;
	private String address;
}
