package com.lm.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.domain.Page;

import java.util.List;
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class PageOfResp <T>{
    private long totalResult;

    private int pageIndex;

    private int itemsPerPage;

    private List<T> results;

    public PageOfResp(Page<T> page) {
        super();
        this.pageIndex = page.getNumber() + 1;
        this.itemsPerPage = page.getSize();
        this.totalResult = page.getTotalElements();
        this.results = page.getContent();
    }
}
