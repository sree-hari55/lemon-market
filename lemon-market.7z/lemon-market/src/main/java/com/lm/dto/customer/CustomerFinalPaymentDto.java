package com.lm.dto.customer;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Setter
@Getter
public class CustomerFinalPaymentDto {
    private Long id;
    private BigDecimal advancePayment;
    private BigDecimal paidPayment;
    private BigDecimal totalPayment;
    private BigDecimal pendingPayment;
    private LocalDateTime createdDate;
    private LocalDateTime modifiedDate;
    private CustomerDto customerDto;

}

