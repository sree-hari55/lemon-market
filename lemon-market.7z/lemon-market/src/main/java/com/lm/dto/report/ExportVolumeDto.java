package com.lm.dto.report;

import lombok.AllArgsConstructor;
import lombok.Data;
import java.math.BigDecimal;

@Data
@AllArgsConstructor
public class ExportVolumeDto {
    private String groupBy;       // e.g. country or customer
    private Long orders;
    private Long items;
    private BigDecimal revenue;
}
