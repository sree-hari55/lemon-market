package com.lm.dto.farmer;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FarmerFilterDto {
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String email;
}
