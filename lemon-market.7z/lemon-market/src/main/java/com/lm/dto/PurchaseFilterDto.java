package com.lm.dto;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
public class PurchaseFilterDto {
    private Long farmerId;
    private String farmerFirstName;
    private String location;
    private String vehicleNumber;
    private String lemonType;
    private LocalDateTime fromDate;
    private LocalDateTime toDate;
    private BigDecimal minWeight;
    private BigDecimal maxWeight;
}
