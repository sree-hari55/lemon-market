package com.lm.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.time.LocalDateTime;
@Getter
@Setter
@NoArgsConstructor
public class PurchaseSummaryDto {
    private LocalDateTime date;
    private String lemonType;
    private String location;
    private BigDecimal totalQuantity;
    private BigDecimal totalCost;
    private BigDecimal avgCost;
    public PurchaseSummaryDto(LocalDateTime date, String lemonType, String location,
                              BigDecimal totalQuantity, BigDecimal totalCost, BigDecimal avgCost) {
        this.date = date;
        this.lemonType = lemonType;
        this.location = location;
        this.totalQuantity = totalQuantity;
        this.totalCost = totalCost;
        this.avgCost = avgCost;
    }


}
