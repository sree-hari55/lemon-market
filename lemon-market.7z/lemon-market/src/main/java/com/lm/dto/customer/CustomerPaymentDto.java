package com.lm.dto.customer;

import com.lm.dto.farmer.FarmerDto;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;
@Getter
@Setter
public class CustomerPaymentDto {
    private Long id;
    private String paymentType;
    private BigDecimal amount;
    private LocalDateTime createdDate;
    private LocalDateTime modifiedDate;

    private CustomerDto customer;
}
