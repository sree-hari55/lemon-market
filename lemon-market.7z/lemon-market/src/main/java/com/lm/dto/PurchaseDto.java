package com.lm.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.lm.dto.farmer.FarmerDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PurchaseDto {
    private Long id;
   // @NotNull
    private BigDecimal weight; // in kg

  //  @NotNull
    private BigDecimal pricePerKg;

   // @NotNull
    private int transportDistance; // in km

  //  @NotBlank
    private String vehicleNumber;

   // @NotNull
    private int bags;

    private String createdBy;

    private String quality;

    private FarmerDto farmer;

    // Calculated fields (can be sent in response)
    private BigDecimal purchaseAmount;
    private BigDecimal commission;
    private BigDecimal transportCharge;
    private BigDecimal finalAmount;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime creationDate;
}
