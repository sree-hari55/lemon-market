package com.lm.dto.accounting;


import lombok.Data;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;

@Data
public class InvoiceDto {
    private Long id;
    private String invoiceNumber;
    private Long salesOrderId;
    private Long customerId;
    private BigDecimal totalAmount;
    private BigDecimal balanceDue;
    private String status;
    private OffsetDateTime issueDate;
    private OffsetDateTime dueDate;
    private List<PaymentDto> payments;
}

