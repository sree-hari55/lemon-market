package com.lm.dto.customer;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CustomerFilterDto {
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;
}
