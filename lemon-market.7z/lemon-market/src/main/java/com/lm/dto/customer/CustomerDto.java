package com.lm.dto.customer;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.lm.dto.PurchaseDto;
import lombok.Data;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.List;


import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Data
public class CustomerDto {
    private Long id;

    @NotBlank(message = "First Name is mandatory")
    private String firstName;


    @NotBlank(message = "Last Name is mandatory")
    private String LastName;

    @Size(min = 10, max = 15, message = "Phone number should be 10 to 15 digits")
    @NotBlank(message = "phone number mandatory")
    private String phoneNumber;

    @Email(message = "Invalid email format")
    private String email;

    private String address;

    private String createdBy;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime creationDate;
    List<PurchaseDto> purchaseDtos;
}
