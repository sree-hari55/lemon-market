package com.lm.dto.accounting;


import lombok.Data;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

@Data
public class CreateInvoiceRequest {
    private Long salesOrderId;
    private Long customerId;
    private BigDecimal totalAmount;
    private OffsetDateTime issueDate;
    private OffsetDateTime dueDate;
    private String invoiceNumber; // optional: allow client-provided
}

