package com.lm.dto.report;

import lombok.AllArgsConstructor;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@AllArgsConstructor
public class ProfitLossDto {
    private LocalDate date;
    private Long salesOrderId;
    private Long inventoryItemId;
    private String itemName;
    private Integer quantity;
    private BigDecimal totalSaleAmount;
    private BigDecimal totalCostAmount;
    private BigDecimal profit; // sale - cost
}

