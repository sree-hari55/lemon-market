package com.lm.dto;

import lombok.Getter;

@Getter
public enum Location {
    SHOP,WAREHOUSE,COLD_STORAGE;
    private String code;
}
