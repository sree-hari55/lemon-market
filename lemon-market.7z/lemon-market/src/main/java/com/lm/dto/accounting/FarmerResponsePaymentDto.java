package com.lm.dto.accounting;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.lm.dto.farmer.FarmerDto;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
public class FarmerResponsePaymentDto {
    private Long id;
    private String paymentType;
    private String narration;
    private BigDecimal withdrawalAmount;
    private BigDecimal depositAmount;
    private BigDecimal closingBalance;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createdDate;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime modifiedDate;

    private FarmerDto farmerDto;

}
