package com.lm.dto.sales;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class SalesOrderRequestDto {
    private Long customerId;
    private String quality;
    private String location;
    private String paymentStatus;
    private BigDecimal quantityKg;
    private BigDecimal unitPrice;
    private String status;

    private String vehicleNumber;
    private String customerName;
}
