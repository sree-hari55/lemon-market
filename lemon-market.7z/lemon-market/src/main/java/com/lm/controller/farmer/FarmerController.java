package com.lm.controller.farmer;

import com.lm.dto.PageOfResp;
import com.lm.dto.PurchaseDto;
import com.lm.dto.PurchaseFilterDto;
import com.lm.dto.farmer.FarmerDto;
import com.lm.dto.farmer.FarmerFilterDto;
import com.lm.service.farmer.FarmerService;
import com.lm.utils.PaginationUtils;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/farmer")
@RequiredArgsConstructor
public class FarmerController {

    private final FarmerService farmerService;

    @PostMapping
    public ResponseEntity<FarmerDto> createCustomer(@Valid @RequestBody FarmerDto dto) {
        return ResponseEntity.ok(farmerService.createCustomer(dto));
    }

    @GetMapping("/{id}")
    public ResponseEntity<FarmerDto> getCustomer(@PathVariable("id") Long id) {
        return ResponseEntity.ok(farmerService.getCustomerById(id));
    }

    @GetMapping
    public ResponseEntity<PageOfResp<FarmerDto>> getCustomers(@RequestParam(value = "pageIndex", required = false, defaultValue = "1") int pageIndex,
                                                              @RequestParam(value = "pageSize", required = false, defaultValue = "10") int pageSize) {
        Pageable pageable = PaginationUtils.initPageable(pageIndex, pageSize);
        PageOfResp<FarmerDto> pageOfResp = farmerService.getCustomers(pageable);
        return ResponseEntity.ok(pageOfResp);
    }

    @PutMapping("/{id}")
    public ResponseEntity<FarmerDto> updateCustomer(@PathVariable("id") Long id, @Valid @RequestBody FarmerDto dto) {
        return ResponseEntity.ok(farmerService.updateCustomer(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCustomer(@PathVariable("id") Long id) {
        System.out.println("delete API call");
        farmerService.deleteCustomer(id);
        return ResponseEntity.noContent().build();
    }
    @GetMapping("/search")
    public ResponseEntity<List<FarmerDto>> searchCustomers(@RequestParam("query") String query) {
        List<FarmerDto> pageOfResp = farmerService.searchCustomers(query);
        return ResponseEntity.ok(pageOfResp);
    }

    @PostMapping("/filter")
    public ResponseEntity<PageOfResp<FarmerDto>> filterPurchases(
            @RequestBody FarmerFilterDto filterDto,
            @RequestParam(value = "pageIndex", defaultValue = "1") int pageIndex,
            @RequestParam(value = "pageSize", defaultValue = "10") int pageSize) {

        Pageable pageable = PaginationUtils.initPageable(pageIndex, pageSize);
        PageOfResp<FarmerDto> response = farmerService.filterFarmers(filterDto, pageable);
        return ResponseEntity.ok(response);
    }

}