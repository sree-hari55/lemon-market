package com.lm.controller;

import java.util.List;

import com.lm.dto.MarketDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lm.service.MarketService;

import lombok.AllArgsConstructor;

@RestController
@RequestMapping("/api/market")
@RequiredArgsConstructor
public class MarketController {

	private final MarketService marketService;

	@GetMapping
	public ResponseEntity<List<MarketDTO>> getAllMarkets() {
		List<MarketDTO> markets = marketService.getAllMarkets();
		return ResponseEntity.ok(markets);
	}
}
