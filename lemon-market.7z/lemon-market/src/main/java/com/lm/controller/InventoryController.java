package com.lm.controller;


import com.lm.dto.PageOfResp;
import com.lm.dto.inventory.InventoryFilterDto;
import com.lm.dto.inventory.InventoryItemDTO;
import com.lm.dto.inventory.InventorySummaryDto;
import com.lm.service.inventory.InventoryService;
import com.lm.utils.PaginationUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api/v1/inventory")
@RequiredArgsConstructor
@Slf4j
@CrossOrigin(origins = "http://localhost:4200")
public class InventoryController {

    private final InventoryService inventoryService;

    /**
     * Get all products in the system
     */
    @GetMapping
    public ResponseEntity<PageOfResp<InventoryItemDTO>> listInventory( @RequestParam(defaultValue = "1") int pageIndex,
                                                                 @RequestParam(defaultValue = "10") int pageSize) {
        Pageable pageable = PaginationUtils.initPageable(pageIndex, pageSize);
        PageOfResp<InventoryItemDTO> inventoryList = inventoryService.listInventory(pageable);
        return ResponseEntity.ok(inventoryList);
    }

    @PostMapping("/filter")
    public ResponseEntity<PageOfResp<InventoryItemDTO>> filterInventory(
            @RequestBody InventoryFilterDto filterDto,
            @RequestParam(defaultValue = "1") int pageIndex,
            @RequestParam(defaultValue = "10") int pageSize) {

        Pageable pageable = PaginationUtils.initPageable(pageIndex, pageSize);
        return ResponseEntity.ok(inventoryService.filterInventoryItems(filterDto, pageable));
    }


    /**
     * Create a new product
     */
   /* @PostMapping("/products")
    public ResponseEntity<ProductDTO> createProduct(@Valid @RequestBody ProductDTO productDTO) {
        log.info("Creating product: {}", productDTO.name());
      //  ProductDTO createdProduct = inventoryService.createProduct(productDTO);
        return ResponseEntity.status(201).body(createdProduct);
    }
*/
    /**
     * Get all inventory items (stock per warehouse)
     */
   /* @GetMapping("/items")
    public ResponseEntity<List<InventoryItemDTO>> getAllInventoryItems() {
        log.info("Fetching inventory items");
        List<InventoryItemDTO> items = inventoryService.listInventory();
        return ResponseEntity.ok(items);
    }

    *//**
     * Record a stock transaction (purchase, sale, adjustment)
     *//*
    @PostMapping("/transactions")
    public ResponseEntity<StockTransactionDTO> createStockTransaction(
            @Valid @RequestBody StockTransactionRequest request
    ) {
        log.info("Creating stock transaction for productId={}, type={}, qty={}",
                request.productId(), request.transactionType(), request.quantity());

        StockTransactionDTO transaction = inventoryService.addStockTransaction(request);
        return ResponseEntity.status(201).body(transaction);
    }

    @GetMapping
    public List<Inventory> getAllInventory() {
        return inventoryService.getAllInventory();
    }
*/
    // Endpoint to check expired stock
   /* @PostMapping("/check-expiry")
    public void checkExpiredStock() {
        inventoryService.checkExpiredStock();
    }*/

    // Endpoint to check low stock
    @PostMapping("/check-low-stock")
    public void checkLowStock() {
        //inventoryService.checkLowStock();
    }

    @GetMapping("/summary")
    public ResponseEntity<InventorySummaryDto> getInventorySummary() {
        InventorySummaryDto summary = inventoryService.getInventorySummary();
        return ResponseEntity.ok(summary);
    }
}

