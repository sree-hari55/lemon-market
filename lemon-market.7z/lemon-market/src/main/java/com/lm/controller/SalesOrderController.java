package com.lm.controller;


import com.lm.dto.PageOfResp;
import com.lm.dto.PurchaseSummaryDto;
import com.lm.dto.sales.SaleSummaryDto;
import com.lm.dto.sales.SalesOrderDto;
import com.lm.dto.sales.SalesOrderFilterDto;
import com.lm.dto.sales.SalesOrderRequestDto;
import com.lm.service.sales.SalesOrderService;
import com.lm.utils.PaginationUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.http.*;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import java.security.Principal;
import java.util.List;

@RestController
@RequestMapping("/api/sales")
@RequiredArgsConstructor
public class SalesOrderController {
    private final SalesOrderService service;

    @PostMapping
    public ResponseEntity<SalesOrderDto> create(@Validated @RequestBody SalesOrderRequestDto dto, Principal p) {
        SalesOrderDto saved = service.create(dto, p == null ? "system" : p.getName());
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    @PutMapping("/{id}")
    public ResponseEntity<SalesOrderDto> update(@PathVariable("id") Long id, @Validated @RequestBody SalesOrderDto dto, Principal p) {
        return ResponseEntity.ok(service.update(id, dto, p == null ? "system" : p.getName()));
    }

    @PostMapping("/{id}/confirm")
    public ResponseEntity<SalesOrderDto> confirm(@PathVariable("id") Long id, Principal p) {
        return ResponseEntity.ok(service.confirmOrder(id, p == null ? "system" : p.getName()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<SalesOrderDto> get(@PathVariable("id") Long id) {
        return service.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @GetMapping
    public ResponseEntity<PageOfResp<SalesOrderDto>> list(
            @RequestParam(name = "page",defaultValue = "0") int page,
            @RequestParam(name = "size", defaultValue = "20") int size) {
        Pageable pageable = PaginationUtils.initPageable(page, size);
        PageOfResp<SalesOrderDto> result = service.listSales(pageable);

        return ResponseEntity.ok(result);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> cancel(@PathVariable("id") Long id) {
        service.cancelOrder(id,"system");
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/filter")
    public ResponseEntity<PageOfResp<SalesOrderDto>> filterSales(
            @RequestBody SalesOrderFilterDto filterDto,
            @RequestParam(defaultValue = "1") int pageIndex,
            @RequestParam(defaultValue = "10") int pageSize) {

        Pageable pageable = PaginationUtils.initPageable(pageIndex, pageSize);
        return ResponseEntity.ok(service.filterSalesOrders(filterDto, pageable));
    }

    @GetMapping("/sale-summary")
    public ResponseEntity<Page<SaleSummaryDto>> getSaleSummary(
            @RequestParam(value = "pageIndex", defaultValue = "1") int pageIndex,
            @RequestParam(value = "pageSize", defaultValue = "10") int pageSize) {
        Pageable pageable = PaginationUtils.initPageable(pageIndex, pageSize);
        Page<SaleSummaryDto> response = service.getSaleSummary(pageable);
        return ResponseEntity.ok(response);
    }

}

