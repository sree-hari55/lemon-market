package com.lm.controller.farmer;


import com.lm.dto.PageOfResp;
import com.lm.dto.farmer.FarmerFinalPaymentDto;
import com.lm.dto.farmer.FarmerPaymentSummaryDto;
import com.lm.service.farmer.FarmerFinalPaymentService;
import com.lm.utils.PaginationUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/farmer/final-payments")
@RequiredArgsConstructor
public class FarmerFinalPaymentController {

    private final FarmerFinalPaymentService service;

    @PostMapping
    public ResponseEntity<FarmerFinalPaymentDto> createFarmerFinalPayment(@RequestBody FarmerFinalPaymentDto dto) {
        return ResponseEntity.ok(service.createFarmerFinalPayment(dto));
    }

    @GetMapping("/{id}")
    public ResponseEntity<FarmerFinalPaymentDto> getFarmerFinalPaymentById(@PathVariable Long id) {
        return ResponseEntity.ok(service.getFarmerFinalPaymentById(id));
    }

    @GetMapping
    public ResponseEntity<PageOfResp<FarmerFinalPaymentDto>> getFarmerFinalPayments(@RequestParam(value = "pageIndex", required = false, defaultValue = "1") int pageIndex,
                                                                                        @RequestParam(value = "pageSize", required = false, defaultValue = "10") int pageSize) {
        Pageable pageable = PaginationUtils.initPageable(pageIndex, pageSize);
        PageOfResp<FarmerFinalPaymentDto> pageOfResp = service.getFarmerFinalPayments(pageable);
        return ResponseEntity.ok(pageOfResp);
    }

    @PutMapping("/{id}")
    public ResponseEntity<FarmerFinalPaymentDto> updateFarmerFinalPayment(@PathVariable Long id, @RequestBody FarmerFinalPaymentDto dto) {
        return ResponseEntity.ok(service.updateFarmerFinalPayment(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteFarmerFinalPaymentById(@PathVariable Long id) {
        service.deleteFarmerFinalPaymentById(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/summary")
    public ResponseEntity<FarmerPaymentSummaryDto> getFarmerFinalPaymentSummary() {
        FarmerPaymentSummaryDto summary = service.getFarmerFinalPaymentSummary();
        return ResponseEntity.ok(summary);
    }
}

