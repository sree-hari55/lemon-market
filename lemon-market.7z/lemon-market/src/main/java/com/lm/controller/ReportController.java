package com.lm.controller;

import com.lm.dto.PageOfResp;
import com.lm.dto.PurchaseSummaryDto;
import com.lm.dto.report.ExportVolumeDto;
import com.lm.dto.report.ProfitLossDto;
import com.lm.dto.report.SalesSummaryDto;
import com.lm.dto.report.StockMovementDto;
import com.lm.service.report.ReportService;
import com.lm.utils.PaginationUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/reports")
@RequiredArgsConstructor
public class ReportController {

    private final ReportService reportService;

    @GetMapping("/purchase-summary")
    public ResponseEntity<PageOfResp<PurchaseSummaryDto>> getPurchaseSummary(
            @RequestParam(value = "pageIndex", defaultValue = "1") int pageIndex,
            @RequestParam(value = "pageSize", defaultValue = "10") int pageSize) {
        Pageable  pageable = PaginationUtils.initPageable(pageIndex,pageSize);
        PageOfResp<PurchaseSummaryDto> pageOfResp = reportService.getSummaryReport(pageable);
           return ResponseEntity.ok(pageOfResp);
    }


    @GetMapping("/sales/daily")
    public ResponseEntity<Page<SalesSummaryDto>> dailySales(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {

        PageRequest pr = PageRequest.of(page, size);
        return ResponseEntity.ok(reportService.dailySalesSummary(from, to, pr));
    }

    @GetMapping("/stock/movement")
    public ResponseEntity<List<StockMovementDto>> stockMovement(
            @RequestParam(required = false) Long inventoryItemId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to) {
        return ResponseEntity.ok(reportService.stockMovement(inventoryItemId, from, to));
    }

    @GetMapping("/profit-loss")
    public ResponseEntity<Page<ProfitLossDto>> profitLoss(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        PageRequest pr = PageRequest.of(page, size);
        return ResponseEntity.ok(reportService.profitLoss(from, to, pr));
    }

    @GetMapping("/export-volume")
    public ResponseEntity<List<ExportVolumeDto>> exportVolume(
            @RequestParam(defaultValue = "customer") String groupBy,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to,
            @RequestParam(defaultValue = "10") int limit) {
        return ResponseEntity.ok(reportService.exportVolume(groupBy, from, to, limit));
    }
}
