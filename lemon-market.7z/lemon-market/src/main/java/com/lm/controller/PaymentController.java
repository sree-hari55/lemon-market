package com.lm.controller;


import com.lm.dto.accounting.CreatePaymentRequest;
import com.lm.dto.accounting.PaymentDto;
import com.lm.service.accounting.PaymentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/accounting/payments")
@RequiredArgsConstructor
public class PaymentController {

    private final PaymentService paymentService;

    @PostMapping
    public ResponseEntity<PaymentDto> record(@RequestBody CreatePaymentRequest req, @RequestHeader(value="X-User", required=false) String user) {
        PaymentDto dto = paymentService.recordPayment(req, user == null ? "system" : user);
        return ResponseEntity.status(HttpStatus.CREATED).body(dto);
    }

    @GetMapping("/invoice/{invoiceId}")
    public ResponseEntity<List<PaymentDto>> listForInvoice(@PathVariable Long invoiceId) {
        return ResponseEntity.ok(paymentService.listPaymentsForInvoice(invoiceId));
    }
}

