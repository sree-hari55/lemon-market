package com.lm.controller;

import com.lm.dto.LoginRequest;
import com.lm.dto.LoginResponse;
import com.lm.service.AdminService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
public class AdminController {

    private final AdminService service;
    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@RequestBody @Valid LoginRequest loginRequest){
        LoginResponse loginResponse = service.login(loginRequest);
        if(loginResponse != null){
            return ResponseEntity.ok(loginResponse);
        }
        return ResponseEntity.badRequest().build();
    }
}
