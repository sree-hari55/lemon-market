package com.lm.controller.customer;

import com.lm.dto.PageOfResp;
import com.lm.dto.customer.CustomerPaymentDto;
import com.lm.dto.customer.CustomerPaymentFilterDto;
import com.lm.dto.customer.CustomerResponsePaymentDto;
import com.lm.service.customer.CustomerPaymentService;
import com.lm.utils.PaginationUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/customer-payment")
@Slf4j
public class CustomerPaymentController {

    @Autowired
    private CustomerPaymentService service;

    @PostMapping
    public ResponseEntity<CustomerResponsePaymentDto> createCustomerPayment(@RequestBody CustomerPaymentDto dto) {
        return ResponseEntity.ok(service.create(dto));
    }

    @GetMapping
    public ResponseEntity<PageOfResp<CustomerResponsePaymentDto>> getCustomerPayments(@RequestParam(value = "pageIndex", required = false, defaultValue = "1") int pageIndex,
                                                                                    @RequestParam(value = "pageSize", required = false, defaultValue = "10") int pageSize) {
        Pageable page = PaginationUtils.initPageable(pageIndex, pageSize);
        PageOfResp<CustomerResponsePaymentDto> pageOfResp = service.getAll(page);
        return ResponseEntity.ok(pageOfResp);
    }

    @GetMapping("/{id}")
    public ResponseEntity<CustomerResponsePaymentDto> getCustomerPaymentById(@PathVariable("id") Long id) {
        CustomerResponsePaymentDto dto =  service.getById(id);
        if (dto != null) {
            return ResponseEntity.ok(dto);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<CustomerResponsePaymentDto> updateCustomerPayment(@PathVariable("id") Long id, @RequestBody CustomerPaymentDto dto) {
        CustomerResponsePaymentDto updated = service.update(id, dto);
        if (updated != null) {
            return ResponseEntity.ok(updated);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCustomerPayment(@PathVariable("id") Long id) {
        if (service.delete(id)) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    @GetMapping("/customers/{customerId}")
    public ResponseEntity<List<CustomerResponsePaymentDto>> fetchCustomerPaymentByFarmerId(@PathVariable("customerId") Long customerId){
        return ResponseEntity.ok(service.getByCustomerId(customerId));
    }
    @PostMapping("/filter")
    public ResponseEntity<PageOfResp<CustomerResponsePaymentDto>> filterCustomerPayments(@RequestBody CustomerPaymentFilterDto customerPaymentFilterDto,
                                                                                       @RequestParam(value = "pageIndex", required = false, defaultValue = "1") int pageIndex,
                                                                                       @RequestParam(value = "pageSize", required = false, defaultValue = "10") int pageSize){
        Pageable page = PaginationUtils.initPageable(pageIndex, pageSize);
        if (!"Normal".equalsIgnoreCase(customerPaymentFilterDto.getPaymentType())) {
            return ResponseEntity
                    .badRequest()
                    .body(new PageOfResp<>());
        }

        PageOfResp<CustomerResponsePaymentDto> result = service.filter(customerPaymentFilterDto,page);
        return ResponseEntity.ok(result);
    }

    @PostMapping("/download")
    public ResponseEntity<byte[]> downloadCustomerPayments(@RequestBody CustomerPaymentFilterDto filterDto,
                                                         @RequestParam(required = false, value = "fileType") String fileType) {

        if (!"Normal".equalsIgnoreCase(filterDto.getPaymentType())) {
            return ResponseEntity.badRequest().build();
        }

        byte[] fileContent;
        String contentType;
        String fileName = filterDto.getCustomerFirstName()+" "+ filterDto.getCustomerLastName();

        switch (fileType.toUpperCase()) {
            case "CSV":
                fileContent = service.exportCSV(filterDto);
                contentType = "text/csv";
                fileName = fileName +"_"+filterDto.getPaymentType()+ LocalDateTime.now()+"_payments.csv";
                break;
            case "PDF":
                fileContent = service.exportPDF(filterDto);
                contentType = "application/pdf";
                fileName = fileName +"_"+filterDto.getPaymentType()+LocalDateTime.now() +"_payments.pdf";
                break;
            default:
                return ResponseEntity.badRequest().build();
        }
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType(contentType));
        headers.setContentDisposition(ContentDisposition.builder("attachment").filename(fileName).build());

        return new ResponseEntity<>(fileContent, headers, HttpStatus.OK);
    }
}

