package com.lm.controller;

import com.lm.dto.accounting.CreateInvoiceRequest;
import com.lm.dto.accounting.InvoiceDto;
import com.lm.service.accounting.InvoiceService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/accounting/invoices")
@RequiredArgsConstructor
public class InvoiceController {

    private final InvoiceService invoiceService;

    @PostMapping
    public ResponseEntity<InvoiceDto> create(@RequestBody CreateInvoiceRequest req, @RequestHeader(value="X-User", required=false) String user) {
        InvoiceDto dto = invoiceService.createInvoice(req, user == null ? "system" : user);
        return ResponseEntity.status(HttpStatus.CREATED).body(dto);
    }

    @GetMapping("/{id}")
    public ResponseEntity<InvoiceDto> get(@PathVariable Long id) {
        InvoiceDto dto = invoiceService.getInvoice(id);
        return dto == null ? ResponseEntity.notFound().build() : ResponseEntity.ok(dto);
    }

    @GetMapping
    public ResponseEntity<Page<InvoiceDto>> list(@RequestParam(defaultValue = "0") int page,
                                                 @RequestParam(defaultValue = "20") int size) {
        PageRequest pr = PageRequest.of(page, size, Sort.by("issueDate").descending());
        return ResponseEntity.ok(invoiceService.listInvoices(pr));
    }

    @PostMapping("/{id}/cancel")
    public ResponseEntity<Void> cancel(@PathVariable Long id, @RequestHeader(value="X-User", required=false) String user) {
        invoiceService.cancelInvoice(id, user == null ? "system" : user);
        return ResponseEntity.noContent().build();
    }
}
