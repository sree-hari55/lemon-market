package com.lm.controller.customer;

import com.lm.dto.customer.CustomerDto;
import com.lm.dto.PageOfResp;
import com.lm.dto.customer.CustomerFilterDto;
import com.lm.service.customer.CustomerService;
import com.lm.utils.PaginationUtils;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/customers")
@RequiredArgsConstructor
public class CustomerController {

    private final CustomerService customerService;

    @PostMapping
    public ResponseEntity<CustomerDto> createCustomer(@Valid @RequestBody CustomerDto dto) {
        return ResponseEntity.ok(customerService.createCustomer(dto));
    }

    @GetMapping("/{id}")
    public ResponseEntity<CustomerDto> getCustomer(@PathVariable("id") Long id) {
        return ResponseEntity.ok(customerService.getCustomerById(id));
    }

    @GetMapping
    public ResponseEntity<PageOfResp<CustomerDto>> getCustomers(@RequestParam(value = "pageIndex", required = false, defaultValue = "1") int pageIndex,
                                                                @RequestParam(value = "pageSize", required = false, defaultValue = "10") int pageSize) {
        Pageable pageable = PaginationUtils.initPageable(pageIndex, pageSize);
        PageOfResp<CustomerDto> pageOfResp = customerService.getCustomers(pageable);
        return ResponseEntity.ok(pageOfResp);
    }

    @PutMapping("/{id}")
    public ResponseEntity<CustomerDto> updateCustomer(@PathVariable("id") Long id, @Valid @RequestBody CustomerDto dto) {
        return ResponseEntity.ok(customerService.updateCustomer(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCustomer(@PathVariable("id") Long id) {
        System.out.println("delete API call");
        customerService.deleteCustomer(id);
        return ResponseEntity.noContent().build();
    }
    @GetMapping("/search")
    public ResponseEntity<List<CustomerDto>> searchCustomers(@RequestParam("query") String query) {
        List<CustomerDto> pageOfResp = customerService.searchCustomers(query);
        return ResponseEntity.ok(pageOfResp);
    }

    @GetMapping("/filter")
    public ResponseEntity<PageOfResp<CustomerDto>> filterCustomers(
            @RequestBody CustomerFilterDto customerFilterDto,
            @RequestParam(value = "pageIndex", required = false, defaultValue = "1") int pageIndex,
            @RequestParam(value = "pageSize", required = false, defaultValue = "10") int pageSize) {

        Pageable pageable = PaginationUtils.initPageable(pageIndex, pageSize);
        PageOfResp<CustomerDto> pageOfResp = customerService.filterCustomers(customerFilterDto, pageable);
        return ResponseEntity.ok(pageOfResp);
    }


}
