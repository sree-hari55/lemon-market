package com.lm.controller.farmer;


import com.lm.dto.PageOfResp;
import com.lm.dto.accounting.FarmerResponsePaymentDto;
import com.lm.dto.farmer.FarmerAdvancePaymentDto;
import com.lm.dto.farmer.FarmerPaymentFilterDto;
import com.lm.service.farmer.FarmerAdvancePaymentService;
import com.lm.utils.JacksonUtils;
import com.lm.utils.PaginationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

@RestController
@RequestMapping("/api/farmer/advance-payments")
public class FarmerAdvancePaymentController {

    @Autowired
    private FarmerAdvancePaymentService service;

    @PostMapping
    public ResponseEntity<FarmerAdvancePaymentDto> createFarmerAdvancePayment(@RequestBody FarmerAdvancePaymentDto dto) {
        System.out.println(JacksonUtils.obj2json(dto));
        return ResponseEntity.ok(service.createFarmerAdvancePayment(dto));
    }

    @PostMapping("/return")
    public ResponseEntity<FarmerAdvancePaymentDto> returnFarmerAdvancePayment(@RequestBody FarmerAdvancePaymentDto dto) {
        return ResponseEntity.ok(service.returnAdvancePayment(dto));
    }

    @GetMapping
    public ResponseEntity<PageOfResp<FarmerAdvancePaymentDto>> getFarmerAdvancePayments(
            @RequestParam(value = "pageIndex", required = false, defaultValue = "1") int pageIndex,
            @RequestParam(value = "pageSize", required = false, defaultValue = "10") int pageSize
    ) {
        Pageable pageable = PaginationUtils.initPageable(pageIndex, pageSize);
        PageOfResp<FarmerAdvancePaymentDto> pageOfResp = service.getFarmerAdvancePayments(pageable);
        return ResponseEntity.ok(pageOfResp);
    }

    @GetMapping("/{id}")
    public ResponseEntity<FarmerAdvancePaymentDto> getFarmerAdvancePaymentById(@PathVariable Long id) {
        FarmerAdvancePaymentDto dto = service.getFarmerAdvancePaymentById(id);
        if (dto != null) {
            return ResponseEntity.ok(dto);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<FarmerAdvancePaymentDto> updateFarmerAdvancePayment(@PathVariable Long id, @RequestBody FarmerAdvancePaymentDto dto) {
        FarmerAdvancePaymentDto updated = service.updateFarmerAdvancePayment(id, dto);
        if (updated != null) {
            return ResponseEntity.ok(updated);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteFarmerAdvancePayment(@PathVariable Long id) {
        if (service.deleteFarmerAdvancePayment(id)) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
   /* @GetMapping("/customers/{customerId}")
    public ResponseEntity<List<FarmerPayDto>> fetchFarmerPayDtoByFarmerId(@PathVariable Long customerId){
        return ResponseEntity.ok(service.fetchFarmerPayDtoByFarmerId(customerId));
    }*/

    @PostMapping("/filter")
    public ResponseEntity<PageOfResp<FarmerResponsePaymentDto>> filterFarmerPayments(@RequestBody FarmerPaymentFilterDto customerPaymentFilterDto,
                                                                                     @RequestParam(value = "pageIndex", required = false, defaultValue = "1") int pageIndex,
                                                                                     @RequestParam(value = "pageSize", required = false, defaultValue = "10") int pageSize){
        Pageable page = PaginationUtils.initPageable(pageIndex, pageSize);
        if (!"Advance".equalsIgnoreCase(customerPaymentFilterDto.getPaymentType())) {
            return ResponseEntity
                    .badRequest()
                    .body(new PageOfResp<>());
        }

        PageOfResp<FarmerResponsePaymentDto> result = service.filterFarmerPayments(customerPaymentFilterDto,page);
        return ResponseEntity.ok(result);
    }
    @PostMapping("/download")
    public ResponseEntity<byte[]> downloadFarmerPayments(@RequestBody FarmerPaymentFilterDto filterDto,
            @RequestParam(required = false, value = "fileType") String fileType) {

        if (!"Advance".equalsIgnoreCase(filterDto.getPaymentType())) {
            return ResponseEntity.badRequest().build();
        }

        byte[] fileContent;
        String contentType;
        String fileName = filterDto.getFarmerFirstName()+" "+ filterDto.getFarmerLastName();

        switch (fileType.toUpperCase()) {
            case "CSV":
                fileContent = service.generateFarmerPaymentsCSV(filterDto);
                contentType = "text/csv";
                fileName = fileName+"_"+filterDto.getPaymentType()+LocalDateTime.now()+"_payments.csv";
                break;
            case "PDF":
                fileContent = service.generateFarmerPaymentsPDF(filterDto);
                contentType = "application/pdf";
                fileName = fileName+"_"+filterDto.getPaymentType()+LocalDateTime.now()+"_payments.pdf";
                break;
            default:
                return ResponseEntity.badRequest().build();
        }
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType(contentType));
        headers.setContentDisposition(ContentDisposition.builder("attachment").filename(fileName).build());

        return new ResponseEntity<>(fileContent, headers, HttpStatus.OK);
    }


}
