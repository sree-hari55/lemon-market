package com.lm.controller.farmer;


import com.lm.dto.PageOfResp;
import com.lm.dto.accounting.FarmerResponsePaymentDto;
import com.lm.dto.farmer.FarmerPayDto;
import com.lm.dto.farmer.FarmerPaymentFilterDto;
import com.lm.service.farmer.FarmerPaymentService;
import com.lm.utils.PaginationUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/farmer-payment")
@Slf4j
public class FarmerPaymentController {

    @Autowired
    private FarmerPaymentService service;

    @PostMapping
    public ResponseEntity<FarmerResponsePaymentDto> createFarmerPayment(@RequestBody FarmerPayDto dto) {
        return ResponseEntity.ok(service.createFarmerPayment(dto));
    }

    @GetMapping
    public ResponseEntity<PageOfResp<FarmerResponsePaymentDto>> getFarmerPayments(@RequestParam(value = "pageIndex", required = false, defaultValue = "1") int pageIndex,
                                                                          @RequestParam(value = "pageSize", required = false, defaultValue = "10") int pageSize) {
        Pageable page = PaginationUtils.initPageable(pageIndex, pageSize);
        PageOfResp<FarmerResponsePaymentDto> pageOfResp = service.getFarmerPayments(page);
        return ResponseEntity.ok(pageOfResp);
    }

    @GetMapping("/{id}")
    public ResponseEntity<FarmerResponsePaymentDto> getFarmerPaymentById(@PathVariable Long id) {
        FarmerResponsePaymentDto dto = service.getFarmerPaymentById(id);
        if (dto != null) {
            return ResponseEntity.ok(dto);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<FarmerResponsePaymentDto> updateFarmerPayment(@PathVariable Long id, @RequestBody FarmerPayDto dto) {
        FarmerResponsePaymentDto updated = service.updateFarmerPayment(id, dto);
        if (updated != null) {
            return ResponseEntity.ok(updated);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteFarmerPayment(@PathVariable Long id) {
        if (service.deleteFarmerPayment(id)) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    @GetMapping("/customers/{customerId}")
    public ResponseEntity<List<FarmerResponsePaymentDto>> fetchFarmerPaymentByFarmerId(@PathVariable Long customerId){
        return ResponseEntity.ok(service.fetchFarmerPaymentByFarmerId(customerId));
    }
    @PostMapping("/filter")
    public ResponseEntity<PageOfResp<FarmerResponsePaymentDto>> filterFarmerPayments(@RequestBody FarmerPaymentFilterDto customerPaymentFilterDto,
                                                                                   @RequestParam(value = "pageIndex", required = false, defaultValue = "1") int pageIndex,
                                                                                   @RequestParam(value = "pageSize", required = false, defaultValue = "10") int pageSize){
        Pageable page = PaginationUtils.initPageable(pageIndex, pageSize);
        if (!"Normal".equalsIgnoreCase(customerPaymentFilterDto.getPaymentType())) {
            return ResponseEntity
                    .badRequest()
                    .body(new PageOfResp<>());
        }

        PageOfResp<FarmerResponsePaymentDto> result = service.filterFarmerPayments(customerPaymentFilterDto,page);
        return ResponseEntity.ok(result);
    }

    @PostMapping("/download")
    public ResponseEntity<byte[]> downloadFarmerPayments(@RequestBody FarmerPaymentFilterDto filterDto,
                                                           @RequestParam(required = false, value = "fileType") String fileType) {

        if (!"Normal".equalsIgnoreCase(filterDto.getPaymentType())) {
            return ResponseEntity.badRequest().build();
        }

        byte[] fileContent;
        String contentType;
        String fileName = filterDto.getFarmerFirstName()+" "+ filterDto.getFarmerLastName();

        switch (fileType.toUpperCase()) {
            case "CSV":
                fileContent = service.generateFarmerPaymentsCSV(filterDto);
                contentType = "text/csv";
                fileName = fileName +"_"+filterDto.getPaymentType()+ LocalDateTime.now()+"_payments.csv";
                break;
            case "PDF":
                fileContent = service.generateFarmerPaymentsPDF(filterDto);
                contentType = "application/pdf";
                fileName = fileName +"_"+filterDto.getPaymentType()+LocalDateTime.now() +"_payments.pdf";
                break;
            default:
                return ResponseEntity.badRequest().build();
        }
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType(contentType));
        headers.setContentDisposition(ContentDisposition.builder("attachment").filename(fileName).build());

        return new ResponseEntity<>(fileContent, headers, HttpStatus.OK);
    }
}

