package com.lm.controller;

import com.lm.dto.PageOfResp;
import com.lm.dto.PurchaseDto;
import com.lm.dto.PurchaseFilterDto;
import com.lm.dto.PurchaseSummaryDto;
import com.lm.service.InvoiceService;
import com.lm.service.PurchaseService;
import com.lm.utils.PaginationUtils;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/purchase")
@RequiredArgsConstructor
public class PurchaseController {

    private final PurchaseService purchaseService;
    private final InvoiceService invoiceService;

    @PostMapping
    public ResponseEntity<PurchaseDto> createPurchase(@Valid @RequestBody PurchaseDto purchaseDto) {
        PurchaseDto savedPurchase = purchaseService.calculateBilling(purchaseDto);
        return new ResponseEntity<>(savedPurchase, HttpStatus.CREATED);
    }
    @GetMapping("/{id}/invoice")
    public ResponseEntity<byte[]> getInvoice(@PathVariable("id") Long id) {

        byte[] pdf = invoiceService.generateInvoicePdf(id);

        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_PDF)
                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=invoice_" + id + ".pdf")
                .body(pdf);
    }

    @GetMapping
    public ResponseEntity<PageOfResp<PurchaseDto>> getPurchases(@RequestParam(value = "pageIndex", required = false, defaultValue = "1") int pageIndex,
                                                        @RequestParam(value = "pageSize", required = false, defaultValue = "10") int pageSize) {
        Pageable pageable = PaginationUtils.initPageable(pageIndex, pageSize);
        PageOfResp<PurchaseDto> pageOfResp = purchaseService.getPurchases(pageable);
        return ResponseEntity.ok(pageOfResp);
    }

    @GetMapping("/{id}")
    public ResponseEntity<PurchaseDto> getPurchaseById(@PathVariable("id") Long id) {
        return ResponseEntity.ok(purchaseService.getPurchaseById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<PurchaseDto> updatePurchase(@PathVariable("id") Long id, @Valid @RequestBody PurchaseDto purchaseDto) {
        return ResponseEntity.ok(purchaseService.updatePurchase(id, purchaseDto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePurchase(@PathVariable("id") Long id) {
        purchaseService.deletePurchase(id);
        return ResponseEntity.noContent().build();
    }
    @RequestMapping(method = RequestMethod.OPTIONS)
    public ResponseEntity<?> handleOptions() {
        return ResponseEntity.ok().build();
    }

}
