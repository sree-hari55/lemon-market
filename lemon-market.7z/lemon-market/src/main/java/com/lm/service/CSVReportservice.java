package com.lm.service;

import com.lm.dto.accounting.FarmerResponsePaymentDto;
import com.lm.dto.farmer.FarmerPaymentFilterDto;
import com.lm.entity.farmer.Farmer;

import java.util.List;

public class CSVReportservice implements ReportService<List<FarmerResponsePaymentDto>, Farmer, FarmerPaymentFilterDto>{

    @Override
    public byte[] generate(List<FarmerResponsePaymentDto> farmerResponsePaymentDtos, Farmer farmer, FarmerPaymentFilterDto farmerPaymentFilterDto) {
        return new byte[0];
    }
}
