package com.lm.service;

import java.util.List;
import java.util.stream.Collectors;

import com.lm.dto.MarketDTO;
import com.lm.entity.Market;
import com.lm.repository.MarketRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class MarketService {

	private final MarketRepository repository;

	public List<MarketDTO> getAllMarkets() {
		return repository.findAll()
				.stream()
				.map(this::toDTO)
				.collect(Collectors.toList());
	}

	private MarketDTO toDTO(Market market) {
		MarketDTO marketDTO = new MarketDTO();
		BeanUtils.copyProperties(market, marketDTO);
		return marketDTO;
	}

}

