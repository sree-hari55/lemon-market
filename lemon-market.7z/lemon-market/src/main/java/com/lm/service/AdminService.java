package com.lm.service;

import com.lm.dto.LoginRequest;
import com.lm.dto.LoginResponse;
import com.lm.entity.Admins;
import com.lm.repository.AdminRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class AdminService {

    private final AdminRepository adminRepository;

    public LoginResponse login(LoginRequest request){
      Optional<Admins> admin = adminRepository.findByUserNameAndPasswordAndMarketName(request.getUserName(),request.getPassword(),request.getMarketName());
      if(admin.isPresent()){
          LoginResponse loginResponse = new LoginResponse();
          loginResponse.setUserName(admin.get().getUserName());
          loginResponse.setToken(UUID.randomUUID().toString());
          loginResponse.setImageUrl("http://loaclshot");
          return loginResponse;
      }
      return null;
    }
}
