package com.lm.service.farmer;


import com.lm.dto.PageOfResp;
import com.lm.dto.accounting.FarmerResponsePaymentDto;
import com.lm.dto.farmer.FarmerAdvancePaymentDto;
import com.lm.dto.farmer.FarmerPayDto;
import com.lm.dto.farmer.FarmerPaymentFilterDto;
import com.lm.entity.farmer.Farmer;
import com.lm.entity.farmer.FarmerAdvancePayment;
import com.lm.entity.farmer.FarmerFinalPayment;
import com.lm.exception.InvalidPaymentException;
import com.lm.exception.ResourceNotFoundException;
import com.lm.mapper.FarmerAdvancePaymentMapper;
import com.lm.repository.farmer.FarmerFinalPaymentRepository;
import com.lm.repository.farmer.FarmerAdvancePaymentRepository;
import com.lm.repository.farmer.FarmerRepository;
import com.lm.service.PDFReportService;
import com.lm.utils.PaginationUtils;
import jakarta.persistence.criteria.Predicate;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class FarmerAdvancePaymentService {
    private final FarmerAdvancePaymentRepository repository;
    private final FarmerAdvancePaymentMapper mapper;
    private final FarmerFinalPaymentRepository farmerFinalPaymentRepository;
    private final FarmerRepository farmerRepository;
    private final PDFReportService pdfReportService;

    @Transactional
    public FarmerAdvancePaymentDto createFarmerAdvancePayment(FarmerAdvancePaymentDto dto) {
        try {
            Long farmerId = dto.getFarmer() != null ? dto.getFarmer().getId() : null;

            if (farmerId == null) {
                throw new IllegalArgumentException("Farmer ID is required.");
            }

            Farmer farmer = farmerRepository.findById(farmerId)
                    .orElseThrow(() -> new IllegalArgumentException("Farmer not found with ID: " + farmerId));

            farmerFinalPaymentRepository.findByFarmerId(farmerId).ifPresent(customerFinalPayment -> {
                BigDecimal result = Optional.ofNullable(customerFinalPayment.getAdvancePayment())
                        .orElse(BigDecimal.ZERO)
                        .add(dto.getAmount());

                customerFinalPayment.setAdvancePayment(result);
                farmerFinalPaymentRepository.save(customerFinalPayment);
            });
            Optional<FarmerAdvancePayment> optionalFarmerAdvancePayment = repository.findTopByFarmerIdOrderByCreatedDateDesc(farmerId);
            FarmerAdvancePayment entity = optionalFarmerAdvancePayment
                    .map(existing -> mapper.toEntity(dto, Optional.of(existing)))
                    .orElseGet(() -> mapper.toEntity(dto, Optional.empty()));
            entity.setFarmer(farmer);
            FarmerAdvancePayment saved = repository.save(entity);
            return mapper.toDto(saved);
        }catch (Exception e){
            e.printStackTrace();
            throw e;
        }
    }
    @Transactional
    public FarmerAdvancePaymentDto returnAdvancePayment(FarmerAdvancePaymentDto dto) {
        Long farmerId = dto.getFarmer() != null ? dto.getFarmer().getId() : null;

        if (farmerId == null) {
            throw new IllegalArgumentException("Farmer ID is required.");
        }

        Farmer farmer = farmerRepository.findById(farmerId)
                .orElseThrow(() -> new IllegalArgumentException("Farmer not found with ID: " + farmerId));

        FarmerFinalPayment farmerFinalPayment = farmerFinalPaymentRepository
                .findByFarmerId(farmerId)
                .orElseThrow(() -> new IllegalArgumentException("Farmer final payment record not found"));

        if (dto.getAmount().compareTo(farmerFinalPayment.getAdvancePayment()) > 0) {
            throw new InvalidPaymentException("Advance return amount cannot be more than the advance amount.");
        }

        farmerFinalPayment.setAdvancePayment(farmerFinalPayment.getAdvancePayment().subtract(dto.getAmount()));
        farmerFinalPaymentRepository.save(farmerFinalPayment);
        Optional<FarmerAdvancePayment> optionalFarmerAdvancePayment = repository.findTopByFarmerIdOrderByCreatedDateDesc(farmerId);
        FarmerAdvancePayment entity = mapper.toEntityForReturnAdvancePayment(dto, optionalFarmerAdvancePayment);
        entity.setFarmer(farmer);
        FarmerAdvancePayment saved = repository.save(entity);

        return mapper.toDto(saved);
    }


    public PageOfResp<FarmerAdvancePaymentDto> getFarmerAdvancePayments(Pageable pageable) {
        Page<FarmerAdvancePaymentDto> pageResults =repository.findAll(pageable)
                .map(mapper::toDto);
        return PaginationUtils.convertToPageResponse(pageResults);

    }

    public FarmerAdvancePaymentDto getFarmerAdvancePaymentById(Long id) {
        Optional<FarmerAdvancePayment> optional = repository.findById(id);
        return optional.map(mapper::toDto).orElse(null);
    }

    public FarmerAdvancePaymentDto updateFarmerAdvancePayment(Long id, FarmerAdvancePaymentDto dto) {
        Optional<FarmerAdvancePayment> optional = repository.findById(id);
        if (optional.isPresent()) {
            FarmerAdvancePayment existing = optional.get();
            // existing.setAmount(dto.getAmount());
            existing.setPaymentType(dto.getPaymentType());
            existing.setInterest(dto.isInterest());
            existing.setInterestRateInRupees(dto.getInterestRateInRupees());
            // existing.setCustomer(dto.getCustomer());

            FarmerAdvancePayment updated = repository.save(existing);
            return mapper.toDto(updated);
        } else {
            return null;
        }
    }

    public boolean deleteFarmerAdvancePayment(Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return true;
        }
        return false;
    }
    public List<FarmerPayDto> fetchFarmerPayDtoByCustomerId(Long customerId){
      /*  if (customerId == null) {
            throw new IllegalArgumentException("Customer ID is required.");
        }

        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new IllegalArgumentException("Customer not found with ID: " + customerId));

        List<CustomerPay> customerPayList= repository.findByCustomerId(customerId);
        return customerPayList.stream()
                .map(mapper::toDto)
                .collect(Collectors.toList());*/
        return null;

    }

    public PageOfResp<FarmerResponsePaymentDto> filterFarmerPayments(FarmerPaymentFilterDto filterDto, Pageable page) {
        Long farmerId = filterDto.getFarmerID();
        if (farmerId == null) {
            throw new ResourceNotFoundException("Farmer ID is required.");
        }

        Farmer farmer = farmerRepository.findById(farmerId)
                .orElseThrow(() -> new IllegalArgumentException("Farmer not found with ID: " + farmerId));
        Specification<FarmerAdvancePayment> spec = withFilters(filterDto);
        Page<FarmerAdvancePayment> pageResults = repository.findAll(spec,page);
        Page<FarmerResponsePaymentDto> dtoPage = pageResults.map(mapper::toResponseDto);
        return PaginationUtils.convertToPageResponse(dtoPage);
    }
    public static Specification<FarmerAdvancePayment> withFilters(FarmerPaymentFilterDto filterDto) {
        return (root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();

            if (filterDto.getFarmerID() != null) {
                predicates.add(cb.equal(root.get("farmer").get("id"), filterDto.getFarmerID()));
            }
            if (filterDto.getFarmerFirstName() != null) {
                predicates.add(cb.equal(root.get("farmer").get("firstName"), filterDto.getFarmerFirstName()));
            }
            if (filterDto.getFarmerLastName() != null) {
                predicates.add(cb.equal(root.get("farmer").get("lastName"), filterDto.getFarmerLastName()));
            }

            if (filterDto.getFromDate() != null) {
                predicates.add(cb.greaterThanOrEqualTo(root.get("createdDate"), filterDto.getFromDate()));
            }

            if (filterDto.getToDate() != null) {
                predicates.add(cb.lessThanOrEqualTo(root.get("createdDate"), filterDto.getToDate()));
            }

            query.orderBy(cb.asc(root.get("createdDate")));

            return cb.and(predicates.toArray(new Predicate[0]));
        };
    }

    public byte[] generateFarmerPaymentsCSV(FarmerPaymentFilterDto filterDto) {
        return null;
    }

    public byte[] generateFarmerPaymentsPDF(FarmerPaymentFilterDto filterDto) {
        Long farmerId = filterDto.getFarmerID();
        if (farmerId == null) {
            throw new ResourceNotFoundException("Farmer ID is required.");
        }
        Farmer farmer = farmerRepository.findById(farmerId)
                .orElseThrow(() -> new IllegalArgumentException("Farmer not found with ID: " + farmerId));
        Specification<FarmerAdvancePayment> spec = withFilters(filterDto);
        List<FarmerAdvancePayment> pageResults = repository.findAll(spec);
        List<FarmerResponsePaymentDto> dtoList = pageResults.stream().map(mapper::toResponseDto).toList();

        return pdfReportService.generate(dtoList,farmer,filterDto);
    }
}
