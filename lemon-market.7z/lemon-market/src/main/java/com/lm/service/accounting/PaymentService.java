package com.lm.service.accounting;


import com.lm.dto.accounting.CreatePaymentRequest;
import com.lm.dto.accounting.PaymentDto;
import java.util.List;

public interface PaymentService {
    PaymentDto recordPayment(CreatePaymentRequest req, String username);
    List<PaymentDto> listPaymentsForInvoice(Long invoiceId);
}

