package com.lm.service.accounting;


import com.lm.dto.accounting.CreatePaymentRequest;
import com.lm.dto.accounting.PaymentDto;
import com.lm.entity.accounting.Invoice;
import com.lm.entity.accounting.Payment;
import com.lm.mapper.AccountingMapper;
import com.lm.repository.accounting.InvoiceRepository;
import com.lm.repository.accounting.PaymentRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PaymentServiceImpl implements PaymentService {

    private final PaymentRepository paymentRepo;
    private final InvoiceRepository invoiceRepo;
    private final AccountingMapper mapper;

    @Override
    @Transactional
    public PaymentDto recordPayment(CreatePaymentRequest req, String username) {
        Invoice inv = invoiceRepo.findById(req.getInvoiceId())
                .orElseThrow(() -> new IllegalArgumentException("Invoice not found: " + req.getInvoiceId()));

        // ensure payment date
        if (req.getPaymentDate() == null) req.setPaymentDate(OffsetDateTime.now());

        Payment p = mapper.toEntity(req, inv);

        // save payment
        Payment saved = paymentRepo.save(p);

        // update invoice balance and status
        BigDecimal newBalance = inv.getBalanceDue().subtract(saved.getAmount() == null ? BigDecimal.ZERO : saved.getAmount());
        inv.setBalanceDue(newBalance.max(BigDecimal.ZERO));
        if (inv.getBalanceDue().compareTo(BigDecimal.ZERO) <= 0) {
            inv.setStatus(Invoice.Status.PAID);
        } else if (inv.getBalanceDue().compareTo(inv.getTotalAmount()) < 0) {
            inv.setStatus(Invoice.Status.PARTIAL);
        } else {
            inv.setStatus(Invoice.Status.PENDING);
        }
        // add to payments list
        inv.getPayments().add(saved);
        invoiceRepo.save(inv);

        // TODO: publish PaymentRecordedEvent for bookkeeping / audit / receipts
        return mapper.toDto(saved);
    }

    @Override
    public List<PaymentDto> listPaymentsForInvoice(Long invoiceId) {
        return paymentRepo.findByInvoiceId(invoiceId).stream().map(mapper::toDto).collect(Collectors.toList());
    }
}
