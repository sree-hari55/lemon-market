package com.lm.service.customer;

import com.lm.dto.PageOfResp;
import com.lm.dto.accounting.FarmerResponsePaymentDto;
import com.lm.dto.customer.CustomerPaymentDto;
import com.lm.dto.customer.CustomerPaymentFilterDto;
import com.lm.dto.customer.CustomerResponsePaymentDto;
import com.lm.dto.farmer.FarmerPaymentFilterDto;
import com.lm.entity.customer.Customer;
import com.lm.entity.customer.CustomerPayment;
import com.lm.entity.farmer.Farmer;
import com.lm.entity.farmer.FarmerPayment;
import com.lm.exception.InvalidPaymentException;
import com.lm.exception.NotEnoughPaymentException;
import com.lm.exception.PaymentSettledException;
import com.lm.exception.ResourceNotFoundException;
import com.lm.mapper.FarmerPayMapper;
import com.lm.repository.customer.CustomerFinalPaymentRepository;
import com.lm.repository.customer.CustomerPaymentRepository;
import com.lm.repository.customer.CustomerRepository;
import com.lm.service.PDFReportService;
import com.lm.utils.JacksonUtils;
import com.lm.utils.PaginationUtils;
import jakarta.persistence.criteria.Predicate;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class CustomerPaymentServiceImpl implements CustomerPaymentService {
    private final CustomerPaymentRepository repository;
    private final CustomerFinalPaymentRepository customerFinalPaymentRepository;
    private final FarmerPayMapper mapper;
    private final CustomerRepository customerRepository;
    private final PDFReportService pdfReportService;


    @Override
    public CustomerResponsePaymentDto create(CustomerPaymentDto dto) {
        log.info("customer pay dto:{}", JacksonUtils.obj2json(dto));
        Long customerId = dto.getCustomer().getId() != null ? dto.getCustomer().getId() : null;

        if (customerId == null) {
            throw new IllegalArgumentException("Customer ID is required.");
        }

        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new IllegalArgumentException("Customer not found with ID: " + customerId));

        customerFinalPaymentRepository.findByCustomerId(customerId).ifPresent(finalPayment -> {
            BigDecimal paymentAmount = dto.getAmount() != null ? dto.getAmount() : BigDecimal.ZERO;
            BigDecimal paidPayment = finalPayment.getPaidPayment() != null ? finalPayment.getPaidPayment() : BigDecimal.ZERO;
            BigDecimal totalPayment = finalPayment.getTotalPayment() != null ? finalPayment.getTotalPayment() : BigDecimal.ZERO;
            BigDecimal pendingPayment = finalPayment.getPendingPayment() != null ? finalPayment.getPendingPayment() : BigDecimal.ZERO;

            if (paidPayment.compareTo(totalPayment) == 0) {
                throw new PaymentSettledException("Full payment has already been settled.");
            }

            if (paymentAmount.compareTo(pendingPayment) > 0) {
                throw new NotEnoughPaymentException("Insufficient amount. Please review the pending balance and try again.");
            }

            BigDecimal newPending = pendingPayment.subtract(paymentAmount);
            BigDecimal newPaid = paidPayment.add(paymentAmount);

            finalPayment.setPaidPayment(newPaid);
            finalPayment.setPendingPayment(newPending);
            customerFinalPaymentRepository.save(finalPayment);
        });
        Optional<CustomerPayment> existingCustomerPayment =repository.findTopByCustomerIdOrderByCreatedDateDesc(customerId);
        if(existingCustomerPayment.isPresent()){
            CustomerPayment entity = toEntity(dto,existingCustomerPayment.get());
            entity.setCustomer(customer);
            CustomerPayment saved = repository.save(entity);
            return toDto(saved);
        }else{
            throw new InvalidPaymentException("No need to pay any payments");
        }

    }

    @Override
    public PageOfResp<CustomerResponsePaymentDto> getAll(Pageable pageable) {
        Page<CustomerResponsePaymentDto> pageResults = repository.findAll(pageable) .map(this::toDto);
        return PaginationUtils.convertToPageResponse(pageResults);
    }

    @Override
    public CustomerResponsePaymentDto getById(Long id) {
        Optional<CustomerPayment> optional = repository.findById(id);
        return optional.map(this::toDto).orElse(null);
    }

    @Override
    public CustomerResponsePaymentDto update(Long id, CustomerPaymentDto dto) {
        Optional<CustomerPayment> optional = repository.findById(id);
        if (optional.isPresent()) {
            CustomerPayment existing = optional.get();
            //   existing.setAmount(dto.getAmount());
            existing.setPaymentType(dto.getPaymentType());
            CustomerPayment updated = repository.save(existing);
            return this.toDto(updated);
        } else {
            return null;
        }
    }

    @Override
    public boolean delete(Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return true;
        }
        return false;
    }

    @Override
    public List<CustomerResponsePaymentDto> getByCustomerId(Long farmerId) {
        if (farmerId == null) {
            throw new IllegalArgumentException("Farmer ID is required.");
        }

        Customer farmer = customerRepository.findById(farmerId)
                .orElseThrow(() -> new IllegalArgumentException("Farmer not found with ID: " + farmerId));

        List<CustomerPayment> customerPayList= repository.findByCustomerId(farmerId);
        return customerPayList.stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    @Override
    public PageOfResp<CustomerResponsePaymentDto> filter(CustomerPaymentFilterDto filterDto, Pageable page) {
        Long customerId = filterDto.getCustomerID();
        if (customerId == null) {
            throw new ResourceNotFoundException("Farmer ID is required.");
        }

        Customer farmer = customerRepository.findById(customerId)
                .orElseThrow(() -> new IllegalArgumentException("Farmer not found with ID: " + customerId));
        Specification<CustomerPayment> spec = withFilters(filterDto);
        Page<CustomerPayment> pageResults = repository.findAll(spec,page);
        Page<CustomerResponsePaymentDto> dtoPage = pageResults.map(this::toDto);
        return PaginationUtils.convertToPageResponse(dtoPage);
    }

    @Override
    public byte[] exportCSV(CustomerPaymentFilterDto dto) {
        return new byte[0];
    }

    @Override
    public byte[] exportPDF(CustomerPaymentFilterDto filterDto) {
        Long farmerId = filterDto.getCustomerID();
        if (farmerId == null) {
            throw new ResourceNotFoundException("Farmer ID is required.");
        }

        Customer farmer = customerRepository.findById(farmerId)
                .orElseThrow(() -> new IllegalArgumentException("Farmer not found with ID: " + farmerId));
        Specification<CustomerPayment> spec = withFilters(filterDto);
        List<CustomerPayment> pageResults = repository.findAll(spec);
        List<CustomerResponsePaymentDto> dtoList = pageResults.stream().map(this::toDto).toList();

        return pdfReportService.generateCustomerReport(dtoList,farmer,filterDto);
    }

    public CustomerResponsePaymentDto toDto(CustomerPayment entity) {

        CustomerResponsePaymentDto dto = new CustomerResponsePaymentDto();
        BeanUtils.copyProperties(entity, dto);
        //  CustomerDto customerDto = new CustomerDto();
        // BeanUtils.copyProperties(entity, customerDto);
        //   dto.setCustomer(customerDto);
        return dto;
    }

    public CustomerPayment toEntity(CustomerPaymentDto dto, CustomerPayment customerPayment) {
        CustomerPayment entity = new CustomerPayment();
        // entity.setId(dto.getId());
        entity.setWithdrawalAmount(dto.getAmount());
        entity.setPaymentType(dto.getPaymentType());
        entity.setCreatedDate(dto.getCreatedDate());
        entity.setModifiedDate(dto.getModifiedDate());
        BigDecimal previousClosingBalance = customerPayment.getClosingBalance();
        if (previousClosingBalance == null) {
            previousClosingBalance = BigDecimal.ZERO;
        }
        entity.setClosingBalance(previousClosingBalance.subtract(dto.getAmount()));
        return entity;
    }
    public static Specification<CustomerPayment> withFilters(CustomerPaymentFilterDto filterDto) {
        return (root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();

            if (filterDto.getCustomerID() != null) {
                predicates.add(cb.equal(root.get("farmer").get("id"), filterDto.getCustomerID()));
            }
            if (filterDto.getCustomerFirstName() != null) {
                predicates.add(cb.equal(root.get("farmer").get("firstName"), filterDto.getCustomerFirstName()));
            }
            if (filterDto.getCustomerLastName() != null) {
                predicates.add(cb.equal(root.get("farmer").get("lastName"), filterDto.getCustomerLastName()));
            }

            if (filterDto.getFromDate() != null) {
                predicates.add(cb.greaterThanOrEqualTo(root.get("createdDate"), filterDto.getFromDate()));
            }

            if (filterDto.getToDate() != null) {
                predicates.add(cb.lessThanOrEqualTo(root.get("createdDate"), filterDto.getToDate()));
            }

            query.orderBy(cb.asc(root.get("createdDate")));

            return cb.and(predicates.toArray(new Predicate[0]));
        };
    }
}