package com.lm.service.report;


import com.lm.dto.PageOfResp;
import com.lm.dto.PurchaseSummaryDto;
import com.lm.dto.report.ExportVolumeDto;
import com.lm.dto.report.ProfitLossDto;
import com.lm.dto.report.SalesSummaryDto;
import com.lm.dto.report.StockMovementDto;
import com.lm.repository.PurchaseRepository;
import com.lm.utils.PaginationUtils;
import jakarta.persistence.*;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.*;
import java.util.*;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class ReportServiceImpl implements ReportService {

    private final EntityManager em;

    private final PurchaseRepository purchaseRepository;

    @Override
    public Page<SalesSummaryDto> dailySalesSummary(LocalDate from, LocalDate to, Pageable pageable) {
        return null;
    }

    @Override
    public List<StockMovementDto> stockMovement(Long inventoryItemId, LocalDate from, LocalDate to) {
        return null;
    }

    @Override
    public Page<ProfitLossDto> profitLoss(LocalDate from, LocalDate to, Pageable pageable) {
        return null;
    }

    @Override
    public List<ExportVolumeDto> exportVolume(String groupBy, LocalDate from, LocalDate to, int limit) {
        return null;
    }

    @Override
    public Page<PurchaseSummaryDto> getPurchaseSummary(int pageIndex, int pageSize) {
        return null;
    }

    /**
     * Daily sales summary (orders, items sold, revenue) grouped by day.
     */

    @Override
    public PageOfResp<PurchaseSummaryDto> getSummaryReport(Pageable pageable) {
        Page<PurchaseSummaryDto> purchaseSummary = purchaseRepository.getPurchaseSummary(pageable);
        return PaginationUtils.convertToPageResponse(purchaseSummary);
    }

}

