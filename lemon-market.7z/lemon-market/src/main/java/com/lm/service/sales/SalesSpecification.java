package com.lm.service.sales;

import com.lm.dto.sales.SalesOrderFilterDto;
import com.lm.entity.sales.Sale;
import jakarta.persistence.criteria.Predicate;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

public class SalesSpecification {

    public static Specification<Sale> withFilters(SalesOrderFilterDto filter) {
        return (root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();

            if (StringUtils.hasText(filter.getQuality())) {
                predicates.add(cb.like(cb.lower(root.get("quality")), "%" + filter.getQuality().toLowerCase() + "%"));
            }

            if (StringUtils.hasText(filter.getLocation())) {
                predicates.add(cb.like(cb.lower(root.get("location")), "%" + filter.getLocation().toLowerCase() + "%"));
            }

            if (StringUtils.hasText(filter.getPaymentStatus())) {
                predicates.add(cb.equal(cb.lower(root.get("paymentStatus")), filter.getPaymentStatus().toLowerCase()));
            }

            if (StringUtils.hasText(filter.getStatus())) {
                predicates.add(cb.equal(cb.lower(root.get("status")), filter.getStatus().toLowerCase()));
            }

            if (StringUtils.hasText(filter.getCustomerName())) {
                predicates.add(cb.like(cb.lower(root.get("customer").get("firstName")), "%" + filter.getCustomerName().toLowerCase() + "%"));
            }

            if (filter.getFromDate() != null) {
                predicates.add(cb.greaterThanOrEqualTo(root.get("creationDate"), filter.getFromDate()));
            }

            if (filter.getToDate() != null) {
                predicates.add(cb.lessThanOrEqualTo(root.get("creationDate"), filter.getToDate()));
            }

            if (filter.getMinQuantityKg() != null) {
                predicates.add(cb.greaterThanOrEqualTo(root.get("quantityKg"), filter.getMinQuantityKg()));
            }

            if (filter.getMaxQuantityKg() != null) {
                predicates.add(cb.lessThanOrEqualTo(root.get("quantityKg"), filter.getMaxQuantityKg()));
            }

            return cb.and(predicates.toArray(new Predicate[0]));
        };
    }
}
