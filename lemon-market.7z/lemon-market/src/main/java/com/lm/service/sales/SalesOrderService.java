package com.lm.service.sales;

import com.lm.dto.PageOfResp;
import com.lm.dto.PurchaseSummaryDto;
import com.lm.dto.sales.SaleSummaryDto;
import com.lm.dto.sales.SalesOrderDto;
import com.lm.dto.sales.SalesOrderFilterDto;
import com.lm.dto.sales.SalesOrderRequestDto;
import com.lm.exception.InsufficientStockException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface SalesOrderService {
    SalesOrderDto create(SalesOrderRequestDto dto, String username);

    public PageOfResp<SalesOrderDto> listSales(Pageable pageable);

    SalesOrderDto update(Long id, SalesOrderDto dto, String username);
    SalesOrderDto confirmOrder(Long id, String username) throws InsufficientStockException;
    Optional<SalesOrderDto> findById(Long id);
    Page<SalesOrderDto> search(Pageable p);
    void cancelOrder(Long id, String username);
    PageOfResp<SalesOrderDto> filterSalesOrders(SalesOrderFilterDto filterDto, Pageable pageable);

    Page<SaleSummaryDto> getSaleSummary(Pageable pageable);
}
