package com.lm.service.inventory;

import com.lm.dto.PageOfResp;
import com.lm.dto.inventory.InventoryFilterDto;
import com.lm.dto.inventory.InventoryItemDTO;
import com.lm.dto.inventory.InventorySummaryDto;
import com.lm.entity.Purchase;
import com.lm.entity.inventory.InventoryItem;
import com.lm.dto.Location;
import com.lm.entity.inventory.StockMovement;
import com.lm.entity.inventory.TransactionType;
import com.lm.entity.sales.LemonQuality;
import com.lm.entity.sales.Sale;
import com.lm.repository.inventory.InventoryItemRepository;
import com.lm.repository.inventory.StockMovementRepository;
import com.lm.utils.PaginationUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Slf4j
public class InventoryService {

    @Autowired
    private InventoryItemRepository inventoryItemRepository;

    @Autowired
    private StockMovementRepository stockMovementRepository;


    public void updateInventoryAfterPurchase(Purchase purchase,String participantName) {
        LocalDateTime expiry = purchase.getCreationDate().plusDays(2);
        Optional<InventoryItem> existingOpt = inventoryItemRepository.findByPurchaseIdAndExpiryDate(purchase.getId(), expiry);
        Optional<InventoryItem> existingStock = inventoryItemRepository.findFirstByQualityOrderByCreationDateDesc(purchase.getLemonType());
        BigDecimal availableStockKg = existingStock
                .map(stock -> stock.getAvailableStockKg().add(purchase.getWeight()))
                .orElse(purchase.getWeight());

        InventoryItem inventory;
        if (existingOpt.isPresent()) {
            inventory = existingOpt.get();
            inventory.setStockInKg(inventory.getStockInKg().add(purchase.getWeight()));
            inventory.setAvailableStockKg(inventory.getAvailableStockKg().add(purchase.getWeight()));
        } else {
            inventory = new InventoryItem();
            inventory.setPurchase(purchase);
            inventory.setStockInKg(purchase.getWeight());
            inventory.setStockOutKg(BigDecimal.ZERO);
            inventory.setAvailableStockKg(availableStockKg);
            inventory.setExpiryDate(expiry);
            inventory.setReorderLevel(BigDecimal.valueOf(100));
            inventory.setStatus(String.valueOf(TransactionType.PURCHASE));
            inventory.setQuality(purchase.getLemonType());
            inventory.setLocation(String.valueOf(Location.WAREHOUSE));
            inventory.setTransactionType(String.valueOf(TransactionType.PURCHASE));
            inventory.setPricePerKg(purchase.getPricePerKg());
            inventory.setParticipantName(participantName);

        }

        inventoryItemRepository.save(inventory);

        StockMovement movement = new StockMovement();
        movement.setInventory(inventory);
        movement.setQuantityMoved(purchase.getWeight());
        movement.setMovementType("Purchase");
        stockMovementRepository.save(movement);
    }

    public void updateInventoryAfterSale(Sale sale, String participantName) {

        Optional<InventoryItem> existingStock = inventoryItemRepository.findFirstByQualityOrderByCreationDateDesc(sale.getQuality());
        BigDecimal availableStockKg = existingStock
                .map(stock -> stock.getAvailableStockKg().subtract(sale.getQuantityKg()))
                .orElse(sale.getQuantityKg());
        InventoryItem inventory;
        inventory = new InventoryItem();
        inventory.setSale(sale);
        inventory.setStockInKg(BigDecimal.ZERO);
        inventory.setStockOutKg(sale.getQuantityKg());
        inventory.setAvailableStockKg(availableStockKg);
        inventory.setReorderLevel(BigDecimal.valueOf(100));
        inventory.setStatus("Sold");
        inventory.setQuality(sale.getQuality());
        inventory.setLocation(String.valueOf(Location.WAREHOUSE));
        inventory.setTransactionType(String.valueOf(TransactionType.SALE));
        inventory.setPricePerKg(sale.getUnitPrice());
        inventory.setParticipantName(participantName);
        
        inventoryItemRepository.save(inventory);

        StockMovement movement = new StockMovement();
        movement.setInventory(inventory);
        movement.setQuantityMoved(sale.getQuantityKg());
        movement.setMovementType("Sale");
        stockMovementRepository.save(movement);
    }

    public List<InventoryItem> getLowStockItems(BigDecimal threshold) {
        return inventoryItemRepository.findByAvailableStockKgLessThan(threshold);
    }

    public List<InventoryItem> getAll() {
        return inventoryItemRepository.findAll();
    }

    public List<InventoryItem> getByTypeAndLocation(String lemonType, String location) {
        return inventoryItemRepository.findByQualityAndLocation(lemonType, location);
    }

    public void checkExpiredStock() {
        List<InventoryItem> inventories = inventoryItemRepository.findAll();
        for (InventoryItem inventory : inventories) {
            if (inventory.getExpiryDate().isBefore(java.time.LocalDateTime.now())) {
                inventory.setStatus("Expired");
                inventoryItemRepository.save(inventory);
            }
        }
    }
    
    public PageOfResp<InventoryItemDTO> listInventory(Pageable pageable) {
        Page<InventoryItem> pageResults = inventoryItemRepository.findAllOrderByLatestDateDesc(pageable);
        Page<InventoryItemDTO> dtoPage = pageResults.map(this::mapToDto);
        return PaginationUtils.convertToPageResponse(dtoPage);
    }

    public InventorySummaryDto getInventorySummary() {
        List<InventoryItem> inventoryItems = inventoryItemRepository.findAll();
        if(inventoryItems.isEmpty()){
            return InventorySummaryDto.builder().build();
        }

        var availableStock = calculateAvailableStock(inventoryItems);
        var soldStock = calculateSoldStock(inventoryItems);

        return InventorySummaryDto.builder()
                .availableLemonStock(availableStock)
                .soldLemonStock(soldStock)
                .build();
    }

    private InventorySummaryDto.LemonStockDto calculateAvailableStock(List<InventoryItem> items) {
        Optional<InventoryItem> optionalFreshInventoryItem = inventoryItemRepository.findFirstByQualityOrderByCreationDateDesc(String.valueOf(LemonQuality.FRESH));
        BigDecimal totalFreshLemonInKgs = optionalFreshInventoryItem.map(InventoryItem::getAvailableStockKg).orElse(BigDecimal.ZERO);
        BigDecimal totalFreshLemonInTons = toTons(totalFreshLemonInKgs);
        Optional<InventoryItem> optionalInventoryItem = inventoryItemRepository.findFirstByQualityOrderByCreationDateDesc(String.valueOf(LemonQuality.SECOND_QUALITY));
        BigDecimal total2ndQualityLemonInKgs = optionalInventoryItem.map(InventoryItem::getAvailableStockKg).orElse(BigDecimal.ZERO);
        BigDecimal total2ndQualityLemonInTons = toTons(total2ndQualityLemonInKgs);
      /*  BigDecimal totalFreshLemonInKgs = items.stream()
                .filter(i -> i.getStatus().equals("Available") && i.getQuality().equalsIgnoreCase("Fresh"))
                .map(InventoryItem::getAvailableStockKg).reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal totalFreshLemonInTons = toTons(totalFreshLemonInKgs);

        BigDecimal total2ndQualityLemonInKgs = items.stream()
                .filter(i -> i.getStatus().equals("Available") && i.getQuality().equalsIgnoreCase("2nd Quality"))
                .map(InventoryItem::getAvailableStockKg).reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal total2ndQualityLemonInTons = toTons(total2ndQualityLemonInKgs);*/

        return InventorySummaryDto.LemonStockDto.builder()
                .freshKg(totalFreshLemonInKgs)
                .freshTons(totalFreshLemonInTons)
                .secondQualityKg(total2ndQualityLemonInKgs)
                .secondQualityTons(total2ndQualityLemonInTons)
                .build();
    }

    private InventorySummaryDto.LemonStockDto calculateSoldStock(List<InventoryItem> items) {
        BigDecimal totalFreshLemonInKgs = items.stream()
                .filter(i -> i.getStatus().equals("Sold") && i.getQuality().equalsIgnoreCase("Fresh"))
                .map(InventoryItem::getStockOutKg).reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal totalFreshLemonInTons = toTons(totalFreshLemonInKgs);

        BigDecimal total2ndQualityLemonInKgs = items.stream()
                .filter(i -> i.getStatus().equals("Sold") && i.getQuality().equalsIgnoreCase("2nd Quality"))
                .map(InventoryItem::getStockOutKg).reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal total2ndQualityLemonInTons = toTons(total2ndQualityLemonInKgs);

        return InventorySummaryDto.LemonStockDto.builder()
                .freshKg(totalFreshLemonInKgs)
                .freshTons(totalFreshLemonInTons)
                .secondQualityKg(total2ndQualityLemonInKgs)
                .secondQualityTons(total2ndQualityLemonInTons)
                .build();
    }
    private BigDecimal toTons(BigDecimal kg) {
        return kg.divide(BigDecimal.valueOf(1000), 3, RoundingMode.HALF_UP);
    }

    public boolean checkStock(String quality, BigDecimal quantityKg) {
        return inventoryItemRepository.findFirstByQualityOrderByCreationDateDesc(quality)
                .map(item -> {
                    BigDecimal available = item.getAvailableStockKg() != null
                            ? item.getAvailableStockKg()
                            : BigDecimal.ZERO;

                    return available.compareTo(quantityKg) >= 0;
                })
                .orElse(false);
    }

    public void deleteInventoryByPurchaseId(Long purchaseId){
        inventoryItemRepository.deleteByPurchaseId(purchaseId);
    }
    public void deleteStockMovementByInventoryId(Long inventoryId){
        stockMovementRepository.deleteByInventoryId(inventoryId);
    }
    public Optional<InventoryItem> findByPurchaseId(Long PurchaseId){
       return inventoryItemRepository.findByPurchaseId(PurchaseId);
    }

    public void deleteInventoryBySaleId(Long saleId) {
        inventoryItemRepository.deleteBySaleId(saleId);
    }
    public Optional<InventoryItem> findBySaleId(Long saleId){
        return inventoryItemRepository.findBySaleId(saleId);
    }

    public PageOfResp<InventoryItemDTO> filterInventoryItems(InventoryFilterDto filterDto, Pageable pageable) {
        Specification<InventoryItem> spec = InventorySpecification.withFilters(filterDto);
        Page<InventoryItem> page = inventoryItemRepository.findAll(spec, pageable);

        Page<InventoryItemDTO> dtoPage = page.map(this::mapToDto);
        return PaginationUtils.convertToPageResponse(dtoPage);
    }

    private InventoryItemDTO mapToDto(InventoryItem item) {
        return new InventoryItemDTO(
                item.getId(),
                item.getQuality(),
                item.getStockInKg(),
                item.getStockOutKg(),
                item.getAvailableStockKg(),
                item.getPricePerKg(),
                item.getExpiryDate(),
                item.getStatus(),
                item.getLocation(),
                item.getTransactionType(),
                item.getParticipantName(),
                item.getNotes(),
                item.getModifiedDate() != null ? item.getModifiedDate() : item.getCreationDate()
        );
    }

/*
    @Transactional
    public StockTransactionDTO addStockTransaction(StockTransactionRequest request) {
        var product = productRepository.findById(request.productId())
                .orElseThrow(() -> new IllegalArgumentException("Product not found"));

        var warehouse = Optional.ofNullable(request.warehouse()).orElse("Default");

        var inventoryItem = inventoryItemRepository.findByProductAndWarehouse(product, warehouse)
                .orElseGet(() -> {
                    var newItem = new InventoryItem();
                    newItem.setProduct(product);
                    newItem.setWarehouse(warehouse);
                    newItem.setQuantity(0);
                    newItem.setLastUpdated(LocalDateTime.now());
                    return newItem;
                });

        int currentQty = inventoryItem.getQuantity();
        int updatedQty = switch (request.transactionType()) {
            case PURCHASE, ADJUSTMENT -> currentQty + request.quantity();
            case SALE -> currentQty - request.quantity();
        };

        if (updatedQty < 0) {
            throw new IllegalArgumentException("Insufficient stock for sale");
        }

        inventoryItem.setQuantity(updatedQty);
        inventoryItem.setLastUpdated(LocalDateTime.now());
        inventoryItemRepository.save(inventoryItem);

        var transaction = new StockTransaction();
        transaction.setProduct(product);
        transaction.setTransactionType(request.transactionType());
        transaction.setQuantity(request.quantity());
        transaction.setTransactionDate(LocalDateTime.now());
        transaction.setReferenceId(request.referenceId());

        stockTransactionRepository.save(transaction);

        return new StockTransactionDTO(
                transaction.getId(),
                new ProductDTO(product.getId(), product.getName(), product.getDescription()),
                transaction.getTransactionType(),
                transaction.getQuantity(),
                transaction.getTransactionDate(),
                transaction.getReferenceId());
    }*/
}

