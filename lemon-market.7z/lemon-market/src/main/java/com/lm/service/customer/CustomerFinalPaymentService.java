package com.lm.service.customer;

import com.lm.dto.PageOfResp;
import com.lm.dto.customer.CustomerFinalPaymentDto;
import com.lm.dto.customer.CustomerPaymentSummaryDto;
import com.lm.dto.farmer.FarmerFinalPaymentDto;
import com.lm.dto.farmer.FarmerPaymentSummaryDto;
import org.springframework.data.domain.Pageable;

public interface CustomerFinalPaymentService {
    CustomerFinalPaymentDto create(CustomerFinalPaymentDto dto);

    CustomerFinalPaymentDto getById(Long id);

    PageOfResp<CustomerFinalPaymentDto> getAll(Pageable pageable);

    CustomerFinalPaymentDto update(Long id, CustomerFinalPaymentDto dto);

    void deleteById(Long id);

    CustomerPaymentSummaryDto getSummary();
}
