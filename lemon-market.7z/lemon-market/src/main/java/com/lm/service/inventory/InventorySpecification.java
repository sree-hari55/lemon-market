package com.lm.service.inventory;

import com.lm.dto.inventory.InventoryFilterDto;
import com.lm.entity.inventory.InventoryItem;
import jakarta.persistence.criteria.Predicate;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

public class InventorySpecification {

    public static Specification<InventoryItem> withFilters(InventoryFilterDto filter) {
        return (root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();

            if (StringUtils.hasText(filter.getQuality())) {
                predicates.add(cb.like(cb.lower(root.get("quality")), "%" + filter.getQuality().toLowerCase() + "%"));
            }

            if (StringUtils.hasText(filter.getStatus())) {
                predicates.add(cb.equal(cb.lower(root.get("status")), filter.getStatus().toLowerCase()));
            }

            if (StringUtils.hasText(filter.getLocation())) {
                predicates.add(cb.like(cb.lower(root.get("location")), "%" + filter.getLocation().toLowerCase() + "%"));
            }

            if (StringUtils.hasText(filter.getTransactionType())) {
                predicates.add(cb.equal(cb.lower(root.get("transactionType")), filter.getTransactionType().toLowerCase()));
            }

            if (StringUtils.hasText(filter.getParticipantName())) {
                predicates.add(cb.like(cb.lower(root.get("participantName")), "%" + filter.getParticipantName().toLowerCase() + "%"));
            }

            if (filter.getFromDate() != null) {
                predicates.add(cb.greaterThanOrEqualTo(root.get("creationDate"), filter.getFromDate()));
            }

            if (filter.getToDate() != null) {
                predicates.add(cb.lessThanOrEqualTo(root.get("creationDate"), filter.getToDate()));
            }

            if (filter.getMinAvailableStockKg() != null) {
                predicates.add(cb.greaterThanOrEqualTo(root.get("availableStockKg"), filter.getMinAvailableStockKg()));
            }

            if (filter.getMaxAvailableStockKg() != null) {
                predicates.add(cb.lessThanOrEqualTo(root.get("availableStockKg"), filter.getMaxAvailableStockKg()));
            }

            return cb.and(predicates.toArray(new Predicate[0]));
        };
    }
}
