package com.lm.service.farmer;


import com.lm.dto.PageOfResp;
import com.lm.dto.accounting.FarmerResponsePaymentDto;
import com.lm.dto.farmer.FarmerPayDto;
import com.lm.dto.farmer.FarmerPaymentFilterDto;
import com.lm.entity.farmer.Farmer;
import com.lm.entity.farmer.FarmerPayment;
import com.lm.exception.InvalidPaymentException;
import com.lm.exception.NotEnoughPaymentException;
import com.lm.exception.PaymentSettledException;
import com.lm.exception.ResourceNotFoundException;
import com.lm.mapper.FarmerPayMapper;
import com.lm.repository.farmer.FarmerFinalPaymentRepository;
import com.lm.repository.farmer.FarmerPaymentRepository;
import com.lm.repository.farmer.FarmerRepository;
import com.lm.service.PDFReportService;
import com.lm.utils.PaginationUtils;
import jakarta.persistence.criteria.Predicate;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class FarmerPaymentService {
    private final FarmerPaymentRepository repository;
    private final FarmerFinalPaymentRepository farmerFinalPaymentRepository;
    private final FarmerPayMapper mapper;
    private final FarmerRepository farmerRepository;
    private final PDFReportService pdfReportService;

    @Transactional
    public FarmerResponsePaymentDto createFarmerPayment(FarmerPayDto dto) {
        Long farmerId = dto.getFarmer() != null ? dto.getFarmer().getId() : null;

        if (farmerId == null) {
            throw new IllegalArgumentException("Farmer ID is required.");
        }

        Farmer farmer = farmerRepository.findById(farmerId)
                .orElseThrow(() -> new IllegalArgumentException("Farmer not found with ID: " + farmerId));

        farmerFinalPaymentRepository.findByFarmerId(farmerId).ifPresent(finalPayment -> {
            BigDecimal paymentAmount = dto.getAmount() != null ? dto.getAmount() : BigDecimal.ZERO;
            BigDecimal paidPayment = finalPayment.getPaidPayment() != null ? finalPayment.getPaidPayment() : BigDecimal.ZERO;
            BigDecimal totalPayment = finalPayment.getTotalPayment() != null ? finalPayment.getTotalPayment() : BigDecimal.ZERO;
            BigDecimal pendingPayment = finalPayment.getPendingPayment() != null ? finalPayment.getPendingPayment() : BigDecimal.ZERO;

            if (paidPayment.compareTo(totalPayment) == 0) {
                throw new PaymentSettledException("Full payment has already been settled.");
            }

            if (paymentAmount.compareTo(pendingPayment) > 0) {
                throw new NotEnoughPaymentException("Insufficient amount. Please review the pending balance and try again.");
            }

            BigDecimal newPending = pendingPayment.subtract(paymentAmount);
            BigDecimal newPaid = paidPayment.add(paymentAmount);

            finalPayment.setPaidPayment(newPaid);
            finalPayment.setPendingPayment(newPending);
            farmerFinalPaymentRepository.save(finalPayment);
        });
        Optional<FarmerPayment> existingCustomerPayment =repository.findTopByFarmerIdOrderByCreatedDateDesc(farmerId);
        if(existingCustomerPayment.isPresent()){
            FarmerPayment entity = mapper.toEntity(dto,existingCustomerPayment.get());
            entity.setFarmer(farmer);
            FarmerPayment saved = repository.save(entity);
            return mapper.toDto(saved);
        }else{
            throw new InvalidPaymentException("No need to pay any payments");
        }

    }




    public PageOfResp<FarmerResponsePaymentDto> getFarmerPayments(Pageable pageable) {
        Page<FarmerResponsePaymentDto> pageResults = repository.findAll(pageable) .map(mapper::toDto);
        return PaginationUtils.convertToPageResponse(pageResults);
    }

    public FarmerResponsePaymentDto getFarmerPaymentById(Long id) {
        Optional<FarmerPayment> optional = repository.findById(id);
        return optional.map(mapper::toDto).orElse(null);
    }

    public FarmerResponsePaymentDto updateFarmerPayment(Long id, FarmerPayDto dto) {
        Optional<FarmerPayment> optional = repository.findById(id);
        if (optional.isPresent()) {
            FarmerPayment existing = optional.get();
            //   existing.setAmount(dto.getAmount());
            existing.setPaymentType(dto.getPaymentType());
            FarmerPayment updated = repository.save(existing);
            return mapper.toDto(updated);
        } else {
            return null;
        }
    }

    public boolean deleteFarmerPayment(Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return true;
        }
        return false;
    }

    public List<FarmerResponsePaymentDto> fetchFarmerPaymentByFarmerId(Long farmerId){
        if (farmerId == null) {
            throw new IllegalArgumentException("Farmer ID is required.");
        }

        Farmer farmer = farmerRepository.findById(farmerId)
                .orElseThrow(() -> new IllegalArgumentException("Farmer not found with ID: " + farmerId));

        List<FarmerPayment> customerPayList= repository.findByFarmerId(farmerId);
        return customerPayList.stream()
                .map(mapper::toDto)
                .collect(Collectors.toList());

    }

    public PageOfResp<FarmerResponsePaymentDto> filterFarmerPayments(FarmerPaymentFilterDto filterDto, Pageable page) {
        Long farmerId = filterDto.getFarmerID();
        if (farmerId == null) {
            throw new ResourceNotFoundException("Farmer ID is required.");
        }

        Farmer farmer = farmerRepository.findById(farmerId)
                .orElseThrow(() -> new IllegalArgumentException("Farmer not found with ID: " + farmerId));
        Specification<FarmerPayment> spec = withFilters(filterDto);
        Page<FarmerPayment> pageResults = repository.findAll(spec,page);
        Page<FarmerResponsePaymentDto> dtoPage = pageResults.map(mapper::toDto);
        return PaginationUtils.convertToPageResponse(dtoPage);
    }
    public static Specification<FarmerPayment> withFilters(FarmerPaymentFilterDto filterDto) {
        return (root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();

            if (filterDto.getFarmerID() != null) {
                predicates.add(cb.equal(root.get("farmer").get("id"), filterDto.getFarmerID()));
            }
            if (filterDto.getFarmerFirstName() != null) {
                predicates.add(cb.equal(root.get("farmer").get("firstName"), filterDto.getFarmerFirstName()));
            }
            if (filterDto.getFarmerLastName() != null) {
                predicates.add(cb.equal(root.get("farmer").get("lastName"), filterDto.getFarmerLastName()));
            }

            if (filterDto.getFromDate() != null) {
                predicates.add(cb.greaterThanOrEqualTo(root.get("createdDate"), filterDto.getFromDate()));
            }

            if (filterDto.getToDate() != null) {
                predicates.add(cb.lessThanOrEqualTo(root.get("createdDate"), filterDto.getToDate()));
            }

            query.orderBy(cb.asc(root.get("createdDate")));

            return cb.and(predicates.toArray(new Predicate[0]));
        };
    }

    public byte[] generateFarmerPaymentsPDF(FarmerPaymentFilterDto filterDto) {
        Long farmerId = filterDto.getFarmerID();
        if (farmerId == null) {
            throw new ResourceNotFoundException("Farmer ID is required.");
        }

        Farmer farmer = farmerRepository.findById(farmerId)
                .orElseThrow(() -> new IllegalArgumentException("Farmer not found with ID: " + farmerId));
        Specification<FarmerPayment> spec = withFilters(filterDto);
        List<FarmerPayment> pageResults = repository.findAll(spec);
        List<FarmerResponsePaymentDto> dtoList = pageResults.stream().map(mapper::toDto).toList();

        return pdfReportService.generate(dtoList,farmer,filterDto);
    }

    public byte[] generateFarmerPaymentsCSV(FarmerPaymentFilterDto filterDto) {
        return null;
    }
}
