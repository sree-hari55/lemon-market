package com.lm.service;

public interface ReportService<T,U,V> {
    byte[] generate(T t, U u, V v);
}
