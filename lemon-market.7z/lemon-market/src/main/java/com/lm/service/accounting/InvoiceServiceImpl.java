package com.lm.service.accounting;

import com.lm.dto.accounting.CreateInvoiceRequest;
import com.lm.dto.accounting.InvoiceDto;
import com.lm.entity.accounting.Invoice;
import com.lm.mapper.AccountingMapper;
import com.lm.repository.accounting.InvoiceRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class InvoiceServiceImpl implements InvoiceService {

    private final InvoiceRepository invoiceRepo;
    private final AccountingMapper mapper;

    @Override
    @Transactional
    public InvoiceDto createInvoice(CreateInvoiceRequest req, String username) {
        Invoice inv = mapper.toEntity(req);
        if (inv.getInvoiceNumber() == null || inv.getInvoiceNumber().isBlank()) {
            inv.setInvoiceNumber(generateInvoiceNumber());
        }
        if (inv.getIssueDate() == null) inv.setIssueDate(OffsetDateTime.now());
        inv.setBalanceDue(inv.getTotalAmount());
        Invoice saved = invoiceRepo.save(inv);
        // TODO: save audit log or publish event to notify Sales/Customer
        return mapper.toDto(saved);
    }

    @Override
    public InvoiceDto getInvoice(Long id) {
        return invoiceRepo.findById(id).map(mapper::toDto).orElse(null);
    }

    @Override
    public Page<InvoiceDto> listInvoices(Pageable pageable) {
        return invoiceRepo.findAll(pageable).map(mapper::toDto);
    }

    @Override
    public Optional<InvoiceDto> findBySalesOrderId(Long salesOrderId) {
        return invoiceRepo.findAll().stream()
                .filter(i -> salesOrderId != null && salesOrderId.equals(i.getSalesOrderId()))
                .findFirst().map(mapper::toDto);
    }

    @Override
    @Transactional
    public void cancelInvoice(Long id, String username) {
        Invoice inv = invoiceRepo.findById(id).orElseThrow(() -> new IllegalArgumentException("Invoice not found"));
        inv.setStatus(Invoice.Status.CANCELLED);
        invoiceRepo.save(inv);
        // TODO: publish event / audit log
    }

    private String generateInvoiceNumber() {
        return "INV-" + OffsetDateTime.now().toLocalDate() + "-" + UUID.randomUUID().toString().substring(0,6);
    }
}
