package com.lm.service;

import com.lm.dto.accounting.FarmerResponsePaymentDto;
import com.lm.dto.customer.CustomerPaymentFilterDto;
import com.lm.dto.customer.CustomerResponsePaymentDto;
import com.lm.dto.farmer.FarmerPaymentFilterDto;
import com.lm.entity.customer.Customer;
import com.lm.entity.farmer.Farmer;
import com.lowagie.text.*;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import org.springframework.stereotype.Service;

import java.awt.*;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class PDFReportService implements  ReportService<List<FarmerResponsePaymentDto>, Farmer, FarmerPaymentFilterDto>{
    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");


    @Override
    public byte[] generate(List<FarmerResponsePaymentDto> transactions, Farmer farmer, FarmerPaymentFilterDto filterDto) {
        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Document document = new Document(PageSize.A4, 30, 30, 50, 30);
            PdfWriter.getInstance(document, out);
            document.open();

            // Add Bank Header
            //   Paragraph bankHeader = new Paragraph("HDFC BANK", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16));
            //   bankHeader.setAlignment(Element.ALIGN_LEFT);
            //   document.add(bankHeader);

            //   document.add(new Paragraph("We understand your world", FontFactory.getFont(FontFactory.HELVETICA, 10)));
            //   document.add(new Paragraph(" ")); // spacer

            // Account Holder Info
            PdfPTable infoTable = new PdfPTable(2);
            infoTable.setWidthPercentage(100);
            infoTable.setSpacingBefore(10);
            infoTable.addCell(getCell("Farmer Name: " + farmer.getFirstName(), PdfPCell.ALIGN_LEFT));
            infoTable.addCell(getCell("Mobile No: " + farmer.getPhoneNumber(), PdfPCell.ALIGN_RIGHT));
            infoTable.addCell(getCell("LastName: " + farmer.getLastName(), PdfPCell.ALIGN_LEFT));
            infoTable.addCell(getCell("Email: " + farmer.getEmail(), PdfPCell.ALIGN_RIGHT));
            document.add(infoTable);

            document.add(new Paragraph(" "));
            if(filterDto.getFromDate() != null && filterDto.getToDate() != null) {
                document.add(new Paragraph("Statement Period: " + filterDto.getFromDate() + " to " + filterDto.getToDate()));
            }
            document.add(new Paragraph("Statement Period: " ));
            document.add(new Paragraph(" ")); // spacer

            // Transactions Table
            PdfPTable table = new PdfPTable(new float[]{5f, 2.5f, 3.5f, 3f, 3f, 3f});
            table.setWidthPercentage(100);
            table.setSpacingBefore(10);

            // Add Table Headers
            addTableHeader(table, "Date", "Narration", "Cheq/Cash","Withdrawal Amt", "Deposit Amt", "Closing Balance");
            for (FarmerResponsePaymentDto tx : transactions) {
                table.addCell(formatDate(tx.getCreatedDate()));
                table.addCell(tx.getNarration() != null ? tx.getNarration() : "");
                table.addCell(tx.getPaymentType() != null ? tx.getPaymentType() : "");
                table.addCell(tx.getWithdrawalAmount() != null ? tx.getWithdrawalAmount().toString() : "");
                table.addCell(tx.getDepositAmount() != null ? tx.getDepositAmount().toString() : "");
                table.addCell(tx.getClosingBalance() != null ? tx.getClosingBalance().toString() : "");
            }

            document.add(table);
            document.close();

            return out.toByteArray();

        } catch (DocumentException | IOException e) {
            throw new RuntimeException("Error generating PDF", e);
        }
    }


    public byte[] generateCustomerReport(List<CustomerResponsePaymentDto> transactions, Customer customer, CustomerPaymentFilterDto filterDto) {
        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Document document = new Document(PageSize.A4, 30, 30, 50, 30);
            PdfWriter.getInstance(document, out);
            document.open();

            // Add Bank Header
            //   Paragraph bankHeader = new Paragraph("HDFC BANK", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16));
            //   bankHeader.setAlignment(Element.ALIGN_LEFT);
            //   document.add(bankHeader);

            //   document.add(new Paragraph("We understand your world", FontFactory.getFont(FontFactory.HELVETICA, 10)));
            //   document.add(new Paragraph(" ")); // spacer

            // Account Holder Info
            PdfPTable infoTable = new PdfPTable(2);
            infoTable.setWidthPercentage(100);
            infoTable.setSpacingBefore(10);
            infoTable.addCell(getCell("Farmer Name: " + customer.getFirstName(), PdfPCell.ALIGN_LEFT));
            infoTable.addCell(getCell("Mobile No: " + customer.getPhoneNumber(), PdfPCell.ALIGN_RIGHT));
            infoTable.addCell(getCell("LastName: " + customer.getLastName(), PdfPCell.ALIGN_LEFT));
            infoTable.addCell(getCell("Email: " + customer.getEmail(), PdfPCell.ALIGN_RIGHT));
            document.add(infoTable);

            document.add(new Paragraph(" "));
            if(filterDto.getFromDate() != null && filterDto.getToDate() != null) {
                document.add(new Paragraph("Statement Period: " + filterDto.getFromDate() + " to " + filterDto.getToDate()));
            }
            document.add(new Paragraph("Statement Period: " ));
            document.add(new Paragraph(" ")); // spacer

            // Transactions Table
            PdfPTable table = new PdfPTable(new float[]{5f, 2.5f, 3.5f, 3f, 3f, 3f});
            table.setWidthPercentage(100);
            table.setSpacingBefore(10);

            // Add Table Headers
            addTableHeader(table, "Date", "Narration", "Cheq/Cash","Withdrawal Amt", "Deposit Amt", "Closing Balance");
            for (CustomerResponsePaymentDto tx : transactions) {
                table.addCell(formatDate(tx.getCreatedDate()));
                table.addCell(tx.getNarration() != null ? tx.getNarration() : "");
                table.addCell(tx.getPaymentType() != null ? tx.getPaymentType() : "");
                table.addCell(tx.getWithdrawalAmount() != null ? tx.getWithdrawalAmount().toString() : "");
                table.addCell(tx.getDepositAmount() != null ? tx.getDepositAmount().toString() : "");
                table.addCell(tx.getClosingBalance() != null ? tx.getClosingBalance().toString() : "");
            }

            document.add(table);
            document.close();

            return out.toByteArray();

        } catch (DocumentException | IOException e) {
            throw new RuntimeException("Error generating PDF", e);
        }
    }
    private PdfPCell getCell(String text, int alignment) {
        PdfPCell cell = new PdfPCell(new Phrase(text));
        cell.setPadding(5);
        cell.setBorder(PdfPCell.NO_BORDER);
        cell.setHorizontalAlignment(alignment);
        return cell;
    }

    private void addTableHeader(PdfPTable table, String... headers) {
        for (String header : headers) {
            PdfPCell headerCell = new PdfPCell(new Phrase(header, FontFactory.getFont(FontFactory.HELVETICA_BOLD)));
            headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
            headerCell.setBackgroundColor(Color.LIGHT_GRAY);
            table.addCell(headerCell);
        }
    }
    private String formatDate(LocalDateTime dateTime) {
        return dateTime != null ? dateTime.format(DATE_TIME_FORMATTER) : "";
    }

}
