package com.lm.service.farmer;

import com.lm.dto.PageOfResp;
import com.lm.dto.farmer.FarmerFinalPaymentDto;
import com.lm.dto.farmer.FarmerPaymentSummaryDto;
import com.lm.entity.farmer.FarmerFinalPayment;
import com.lm.mapper.FarmerFinalPaymentMapper;
import com.lm.repository.farmer.FarmerFinalPaymentRepository;
import com.lm.repository.farmer.FarmerRepository;
import com.lm.utils.PaginationUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class FarmerFinalPaymentServiceImpl implements FarmerFinalPaymentService{
    private final FarmerFinalPaymentRepository repository;
    private final FarmerRepository farmerRepository;
    @Override
    public FarmerFinalPaymentDto createFarmerFinalPayment(FarmerFinalPaymentDto dto) {
        FarmerFinalPayment entity = FarmerFinalPaymentMapper.toEntity(dto);
        FarmerFinalPayment saved = repository.save(entity);
        return FarmerFinalPaymentMapper.toDto(saved);
    }

    @Override
    public FarmerFinalPaymentDto getFarmerFinalPaymentById(Long id) {
        FarmerFinalPayment entity = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("CustomerFinalPayment not found with ID: " + id));
        return FarmerFinalPaymentMapper.toDto(entity);
    }

    @Override
    public PageOfResp<FarmerFinalPaymentDto> getFarmerFinalPayments(Pageable pageable) {
        Page<FarmerFinalPaymentDto> pageResult =repository.findAll(pageable).map(FarmerFinalPaymentMapper::toDto);
        return PaginationUtils.convertToPageResponse(pageResult);
    }

    @Override
    public FarmerFinalPaymentDto updateFarmerFinalPayment(Long id, FarmerFinalPaymentDto dto) {
        FarmerFinalPayment existing = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("FarmerFinalPayment not found with ID: " + id));

        existing.setAdvancePayment(dto.getAdvancePayment());
        existing.setPaidPayment(dto.getPaidPayment());
        existing.setTotalPayment(dto.getTotalPayment());
        existing.setPendingPayment(dto.getPendingPayment());

        FarmerFinalPayment updated = repository.save(existing);
        return FarmerFinalPaymentMapper.toDto(updated);
    }

    @Override
    public void deleteFarmerFinalPaymentById(Long id) {
        repository.deleteById(id);
    }

    @Override
    public FarmerPaymentSummaryDto getFarmerFinalPaymentSummary() {
        log.debug("Calculating customer payment summary.");

        List<FarmerFinalPayment> payments = repository.findAll();
        FarmerPaymentSummaryDto dto = new FarmerPaymentSummaryDto();

        if (!payments.isEmpty()) {
            BigDecimal totalPaid = payments.stream()
                    .map(p -> Optional.ofNullable(p.getPaidPayment()).orElse(BigDecimal.ZERO))
                    .reduce(BigDecimal.ZERO, BigDecimal::add);

            BigDecimal totalPending = payments.stream()
                    .map(p -> Optional.ofNullable(p.getPendingPayment()).orElse(BigDecimal.ZERO))
                    .reduce(BigDecimal.ZERO, BigDecimal::add);

            BigDecimal totalAmount = payments.stream()
                    .map(p -> Optional.ofNullable(p.getTotalPayment()).orElse(BigDecimal.ZERO))
                    .reduce(BigDecimal.ZERO, BigDecimal::add);

            BigDecimal totalAdvancePayments = payments.stream()
                    .map(p -> Optional.ofNullable(p.getAdvancePayment()).orElse(BigDecimal.ZERO))
                    .reduce(BigDecimal.ZERO, BigDecimal::add);

            dto.setPaidPayment(totalPaid);
            dto.setPendingAmount(totalPending);
            dto.setTotalPayments(totalAmount);
            dto.setTotalAdvancePayments(totalAdvancePayments);
        } else {
            log.warn("No customer final payments found in the database.");
            dto.setPaidPayment(BigDecimal.ZERO);
            dto.setPendingAmount(BigDecimal.ZERO);
            dto.setTotalPayments(BigDecimal.ZERO);
            dto.setTotalAdvancePayments(BigDecimal.ZERO);
        }

        long customerCount = farmerRepository.count();
        dto.setTotalFarmers(customerCount);

        return dto;
    }
}
