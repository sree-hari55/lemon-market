package com.lm.service.sales;

import com.lm.dto.PageOfResp;
import com.lm.dto.sales.SaleSummaryDto;
import com.lm.dto.sales.SalesOrderDto;
import com.lm.dto.sales.SalesOrderFilterDto;
import com.lm.dto.sales.SalesOrderRequestDto;
import com.lm.entity.customer.Customer;
import com.lm.entity.customer.CustomerFinalPayment;
import com.lm.entity.customer.CustomerPayment;
import com.lm.entity.sales.AuditLog;
import com.lm.entity.sales.Sale;
import com.lm.entity.sales.SaleStatus;
import com.lm.exception.InsufficientStockException;
import com.lm.repository.customer.CustomerFinalPaymentRepository;
import com.lm.repository.customer.CustomerPaymentRepository;
import com.lm.repository.customer.CustomerRepository;
import com.lm.repository.sales.AuditLogRepository;
import com.lm.repository.sales.SaleRepository;
import com.lm.service.inventory.InventoryService;
import com.lm.utils.PaginationUtils;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.*;

@Service
@RequiredArgsConstructor
public class SalesOrderServiceImpl implements SalesOrderService {
    private final InventoryService inventoryService;
    private final AuditLogRepository auditLogRepo;
    private final SaleRepository saleRepository;
    private final CustomerRepository customerRepository;
    private final CustomerPaymentRepository customerPaymentRepository;
    private final CustomerFinalPaymentRepository customerFinalPaymentRepository;

    @Override
    @Transactional
    public SalesOrderDto create(SalesOrderRequestDto dto, String username) {
        boolean stockAvailable = inventoryService.checkStock(dto.getQuality(), dto.getQuantityKg());
        if (!stockAvailable) {
           String message =String.format("Insufficient stock for quality: %s, quantity: %s. Please check inventory.",
                    dto.getQuality(), dto.getQuantityKg());
            throw new InsufficientStockException(message);
        }
        Customer customer = customerRepository.findById(dto.getCustomerId())
                .orElseThrow(() -> new RuntimeException("Customer not found"));
        Sale sale = Sale.builder()
                .customer(customer)
                .location(dto.getLocation())
                .quality(dto.getQuality())
                .quantityKg(dto.getQuantityKg())
                .unitPrice(dto.getUnitPrice())
                .status(dto.getStatus() != null ? dto.getStatus() : SaleStatus.COMPLETED.name())
                .paymentStatus(dto.getPaymentStatus())
              //  .createdBy(dto.getCreatedBy())
                .bags(dto.getQuantityKg().divide(BigDecimal.valueOf(50.0)))
                .vehicleNumber(dto.getVehicleNumber())
                .amount(dto.getQuantityKg().multiply(dto.getUnitPrice()))
                .build();

        Sale savedSale = saleRepository.save(sale);
        // Update Customer Payment Info
        updateCustomerPayment(customer, sale);
        inventoryService.updateInventoryAfterSale(sale, customer.getFirstName()+" "+customer.getLastName());
         SalesOrderDto salesOrderDto = new SalesOrderDto();
        BeanUtils.copyProperties(savedSale, salesOrderDto);
          return salesOrderDto;
    }
    @Override
    public PageOfResp<SalesOrderDto> listSales(Pageable pageable) {
        Page<SalesOrderDto> pageResults = saleRepository.findAll(pageable).map(this::convertToDto);
        return PaginationUtils.convertToPageResponse(pageResults);
    }

    private SalesOrderDto convertToDto(Sale sale) {
        SalesOrderDto salesOrderDto = new SalesOrderDto();
        BeanUtils.copyProperties(sale, salesOrderDto);
        salesOrderDto.setCustomerName(sale.getCustomer().getFirstName()+" "+ sale.getCustomer().getLastName());
        return salesOrderDto;
    }

    @Override
    @Transactional
    public SalesOrderDto update(Long id, SalesOrderDto dto, String username) {
       return null;
    }

    @Override
    @Transactional
    public SalesOrderDto confirmOrder(Long id, String username) throws InsufficientStockException {
        return null;
    }

    @Override
    public Optional<SalesOrderDto> findById(Long id) {
        return null;
    }

    @Override
    public Page<SalesOrderDto> search(Pageable p) {
        return null;
    }

    @Override
    @Transactional
    public void cancelOrder(Long id, String username) {
        inventoryService.findBySaleId(id).ifPresent(inventory -> {
            inventoryService.deleteStockMovementByInventoryId(inventory.getId());
        });
        inventoryService.deleteInventoryBySaleId(id);
        saleRepository.deleteById(id);
    }

    private void saveAudit(String action, Long entityId, String username, String details) {
        AuditLog al = AuditLog.builder()
                .moduleName("SALES")
                .action(action)
                .entityId(entityId)
                .username(username)
                .details(details)
                .timestamp(OffsetDateTime.now())
                .build();
        auditLogRepo.save(al);
    }

    /*private void computeTotals(SalesOrder so) {
        BigDecimal total = BigDecimal.ZERO;
        for(SalesOrderItem i : so.getItems()) {
            i.setLineTotal(i.getUnitPrice().multiply(BigDecimal.valueOf(i.getQuantity())));
            total = total.add(i.getLineTotal());
        }
        so.setTotalAmount(total);
    }
*/
    private String generateOrderNumber() {
        return "SO-" + OffsetDateTime.now().toLocalDate() + "-" + UUID.randomUUID().toString().substring(0, 6);
    }
    private void updateCustomerPayment(Customer customer, Sale sale) {
        Optional<CustomerFinalPayment> optionalPayment = customerFinalPaymentRepository.findByCustomerId(customer.getId());
        CustomerFinalPayment payment = optionalPayment.orElseGet(CustomerFinalPayment::new);

        payment.setCustomer(customer);

        BigDecimal updatedTotalPayment = optionalPayment
                .map(p -> p.getTotalPayment().add(sale.getAmount()))
                .orElse(sale.getAmount());

        BigDecimal updatedPendingPayment = optionalPayment
                .map(p -> p.getPendingPayment().add(sale.getAmount()))
                .orElse(sale.getAmount());

        payment.setTotalPayment(updatedTotalPayment);
        payment.setPendingPayment(updatedPendingPayment);

        customerFinalPaymentRepository.saveAndFlush(payment);
        Optional<CustomerPayment> optionalCustomerPayment =
                customerPaymentRepository.findTopByCustomerIdOrderByCreatedDateDesc(customer.getId());

        CustomerPayment existingFarmerPayment = optionalCustomerPayment.orElseGet(CustomerPayment::new);

        CustomerPayment farmerPayment = new CustomerPayment();
        farmerPayment.setCustomer(customer);
        farmerPayment.setDepositAmount(sale.getAmount());
        BigDecimal previousClosingBalance = existingFarmerPayment.getClosingBalance();
        if (previousClosingBalance == null) {
            previousClosingBalance = BigDecimal.ZERO;
        }

        farmerPayment.setClosingBalance(previousClosingBalance.add(sale.getAmount()));
        farmerPayment.setCreatedDate(LocalDateTime.now());
        farmerPayment.setPaymentType("Cash");
        farmerPayment.setNarration("Deposit");

        customerPaymentRepository.save(farmerPayment);

    }
    @Override
    public PageOfResp<SalesOrderDto> filterSalesOrders(SalesOrderFilterDto filterDto, Pageable pageable) {
        Specification<Sale> spec = SalesSpecification.withFilters(filterDto);
        Page<Sale> result = saleRepository.findAll(spec, pageable);
        Page<SalesOrderDto> dtoPage = result.map(this::convertToDto);
        return PaginationUtils.convertToPageResponse(dtoPage);
    }

    @Override
    public Page<SaleSummaryDto> getSaleSummary(Pageable pageable) {
        return null;
                //saleRepository.findSaleSummary(pageable);
    }

}
