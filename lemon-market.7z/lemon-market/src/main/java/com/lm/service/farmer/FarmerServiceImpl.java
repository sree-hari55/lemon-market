package com.lm.service.farmer;

import com.lm.dto.PageOfResp;
import com.lm.dto.PurchaseDto;
import com.lm.dto.farmer.FarmerDto;
import com.lm.dto.farmer.FarmerFilterDto;
import com.lm.entity.Purchase;
import com.lm.entity.farmer.Farmer;
import com.lm.repository.farmer.FarmerRepository;
import com.lm.utils.PaginationUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class FarmerServiceImpl implements FarmerService{

    private final FarmerRepository farmerRepository;
    @Override
    public List<FarmerDto> searchCustomers(String query) {
     return farmerRepository.searchByFullName(query).stream().map(this::toDto).toList();
    }

    @Override
    public void deleteCustomer(Long id) {
        Farmer customer = farmerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Customer not found"));
        farmerRepository.delete(customer);
    }

    @Override
    public FarmerDto updateCustomer(Long id, FarmerDto dto) {
        Farmer farmer = farmerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Customer not found"));

        BeanUtils.copyProperties(dto, farmer);

        farmer = farmerRepository.save(farmer);

        FarmerDto farmerDto = new FarmerDto();
        BeanUtils.copyProperties(farmer, farmerDto);
        return dto;
    }

    @Override
    public PageOfResp<FarmerDto> getCustomers(Pageable pageable) {
        Page<FarmerDto> pageResult=farmerRepository.findAll(pageable)
                .map(this::convertToFarmerDto);
        return PaginationUtils.convertToPageResponse(pageResult);
    }

    @Override
    public FarmerDto getCustomerById(Long id) {
        Farmer farmer = farmerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Customer not found"));
        return convertToFarmerDto(farmer);
    }

    @Override
    public FarmerDto createCustomer(FarmerDto dto) {
        Farmer farmer = new Farmer();
        BeanUtils.copyProperties(dto, farmer);
        farmer = farmerRepository.save(farmer);

        FarmerDto resultDTO = new FarmerDto();
        BeanUtils.copyProperties(farmer, resultDTO);
        return resultDTO;
    }

    @Override
    public PageOfResp<FarmerDto> filterFarmers(FarmerFilterDto filterDto, Pageable pageable) {
        Page<Farmer> farmers = farmerRepository.findAll(FarmerSpecification.withFilters(filterDto), pageable);
        Page<FarmerDto> farmerDtos = farmers.map(this::convertToFarmerDto);
        return PaginationUtils.convertToPageResponse(farmerDtos);
    }

    private FarmerDto convertToFarmerDto(Farmer farmer) {
        FarmerDto dto = new FarmerDto();
        BeanUtils.copyProperties(farmer, dto);

        if (farmer.getPurchases() != null && !farmer.getPurchases().isEmpty()) {
            List<PurchaseDto> purchaseDtoList = farmer.getPurchases().stream().map(this::convertToPurchaseDto)
                    .collect(Collectors.toList());
            dto.setPurchaseDtos(purchaseDtoList);
        }
        return dto;
    }
    private PurchaseDto convertToPurchaseDto(Purchase purchase) {
        PurchaseDto dto = new PurchaseDto();
        BeanUtils.copyProperties(purchase, dto);
        return dto;
    }
    private FarmerDto toDto(Farmer farmer) {
        FarmerDto dto = new FarmerDto();
        BeanUtils.copyProperties(farmer, dto);
        return dto;
    }
}
