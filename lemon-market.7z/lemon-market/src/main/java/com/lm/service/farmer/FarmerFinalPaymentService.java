package com.lm.service.farmer;

import com.lm.dto.PageOfResp;
import com.lm.dto.farmer.FarmerFinalPaymentDto;
import com.lm.dto.farmer.FarmerPaymentSummaryDto;
import org.springframework.data.domain.Pageable;

public interface FarmerFinalPaymentService {
    FarmerFinalPaymentDto createFarmerFinalPayment(FarmerFinalPaymentDto dto);
    FarmerFinalPaymentDto getFarmerFinalPaymentById(Long id);
    PageOfResp<FarmerFinalPaymentDto> getFarmerFinalPayments(Pageable pageable);
    FarmerFinalPaymentDto updateFarmerFinalPayment(Long id, FarmerFinalPaymentDto dto);
    void deleteFarmerFinalPaymentById(Long id);

    FarmerPaymentSummaryDto getFarmerFinalPaymentSummary();
}
