package com.lm.service.customer;

import com.lm.dto.accounting.FarmerResponsePaymentDto;
import com.lm.dto.customer.CustomerDto;
import com.lm.dto.PageOfResp;
import com.lm.dto.PurchaseDto;
import com.lm.dto.customer.CustomerFilterDto;
import com.lm.dto.farmer.FarmerPaymentFilterDto;
import com.lm.entity.customer.Customer;
import com.lm.entity.Purchase;
import com.lm.entity.farmer.FarmerPayment;
import com.lm.repository.customer.CustomerRepository;
import com.lm.utils.PaginationUtils;
import jakarta.persistence.criteria.Predicate;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CustomerService {

    private final CustomerRepository customerRepository;

    public CustomerDto createCustomer(CustomerDto dto) {
        Customer customer = new Customer();
        BeanUtils.copyProperties(dto, customer);
        customer = customerRepository.save(customer);

        CustomerDto resultDTO = new CustomerDto();
        BeanUtils.copyProperties(customer, resultDTO);
        return resultDTO;
    }

    public CustomerDto getCustomerById(Long id) {
        Customer customer = customerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Customer not found"));
        return convertToCustomerDto(customer);
    }

    public PageOfResp<CustomerDto> getCustomers(Pageable pageable) {
        Page<CustomerDto> pageResult=customerRepository.findAll(pageable)
                .map(this::convertToCustomerDto);
      return PaginationUtils.convertToPageResponse(pageResult);
    }
    private CustomerDto convertToCustomerDto(Customer customer) {
        CustomerDto dto = new CustomerDto();
        BeanUtils.copyProperties(customer, dto);

        /*if (customer.g != null && !customer.getSales().isEmpty()) {
            List<PurchaseDto> saleDtoList = customer.getSales().stream().map(this::convertToSaleDto)
                    .collect(Collectors.toList());
            dto.setPurchaseDtos(saleDtoList);
        }*/

        return dto;
    }
    private CustomerDto toDto(Customer customer) {
        CustomerDto dto = new CustomerDto();
        BeanUtils.copyProperties(customer, dto);
        return dto;
    }

    private PurchaseDto convertToSaleDto(Purchase purchase) {
        PurchaseDto dto = new PurchaseDto();
        BeanUtils.copyProperties(purchase, dto);
        return dto;
    }



    public CustomerDto updateCustomer(Long id, CustomerDto updatedDto) {
        Customer customer = customerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Customer not found"));

        BeanUtils.copyProperties(updatedDto, customer);

        customer = customerRepository.save(customer);

        CustomerDto dto = new CustomerDto();
        BeanUtils.copyProperties(customer, dto);
        return dto;
    }

    public void deleteCustomer(Long id) {
        Customer customer = customerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Customer not found"));
        customerRepository.delete(customer);
    }
    public List<CustomerDto> searchCustomers(String query){
        return customerRepository.searchByFullName(query).stream().map(this::toDto).toList();
    }

    public PageOfResp<CustomerDto> filterCustomers(CustomerFilterDto customerFilterDto, Pageable pageable) {
        Specification<Customer> spec = withFilters(customerFilterDto);
        Page<Customer> pageResults = customerRepository.findAll(spec, pageable);
        Page<CustomerDto> dtoPage = pageResults.map(this::mapToDto);
        return PaginationUtils.convertToPageResponse(dtoPage);
    }

    private CustomerDto mapToDto(Customer customer) {
        CustomerDto dto = new CustomerDto();
        dto.setId(customer.getId());
        dto.setFirstName(customer.getFirstName());
        dto.setLastName(customer.getLastName());
        dto.setEmail(customer.getEmail());
        dto.setPhoneNumber(customer.getPhoneNumber());
        dto.setAddress(customer.getAddress());
        return dto;
    }

    public static Specification<Customer> withFilters(CustomerFilterDto filter) {
        return (root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();

            if (StringUtils.hasText(filter.getFirstName())) {
                predicates.add(cb.like(cb.lower(root.get("firstName")), "%" + filter.getFirstName().toLowerCase() + "%"));
            }

            if (StringUtils.hasText(filter.getLastName())) {
                predicates.add(cb.like(cb.lower(root.get("lastName")), "%" + filter.getLastName().toLowerCase() + "%"));
            }

            if (StringUtils.hasText(filter.getEmail())) {
                predicates.add(cb.like(cb.lower(root.get("email")), "%" + filter.getEmail().toLowerCase() + "%"));
            }

            if (StringUtils.hasText(filter.getPhoneNumber())) {
                predicates.add(cb.like(cb.lower(root.get("phoneNumber")), "%" + filter.getPhoneNumber().toLowerCase() + "%"));
            }

            return cb.and(predicates.toArray(new Predicate[0]));
        };
    }


}
