package com.lm.service.farmer;

import com.lm.dto.PageOfResp;
import com.lm.dto.farmer.FarmerDto;
import com.lm.dto.farmer.FarmerFilterDto;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface FarmerService {

    List<FarmerDto> searchCustomers(String query);

    void deleteCustomer(Long id);

    FarmerDto updateCustomer(Long id, FarmerDto dto);

    PageOfResp<FarmerDto> getCustomers(Pageable pageable);

    FarmerDto getCustomerById(Long id);

    FarmerDto createCustomer(FarmerDto dto);

    PageOfResp<FarmerDto> filterFarmers(FarmerFilterDto filterDto, Pageable pageable);
}
