package com.lm.service.report;

import com.lm.dto.PageOfResp;
import com.lm.dto.PurchaseSummaryDto;
import com.lm.dto.report.ExportVolumeDto;
import com.lm.dto.report.ProfitLossDto;
import com.lm.dto.report.SalesSummaryDto;
import com.lm.dto.report.StockMovementDto;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.time.LocalDate;
import java.util.List;

public interface ReportService {
    /**
     * Daily sales summary for a date range (grouped by day).
     */
    Page<SalesSummaryDto> dailySalesSummary(LocalDate from, LocalDate to, Pageable pageable);

    /**
     * Stock movement for an inventory item (or all items if inventoryItemId == null) in a range.
     */
    List<StockMovementDto> stockMovement(Long inventoryItemId, LocalDate from, LocalDate to);

    /**
     * Profit/Loss details aggregated by day or item for a date range.
     */
    Page<ProfitLossDto> profitLoss(LocalDate from, LocalDate to, Pageable pageable);

    /**
     * Export volume grouped by customer or by destination country.
     * groupBy = "customer" or "country"
     */
    List<ExportVolumeDto> exportVolume(String groupBy, LocalDate from, LocalDate to, int limit);


    Page<PurchaseSummaryDto> getPurchaseSummary(int pageIndex, int pageSize);

    PageOfResp<PurchaseSummaryDto> getSummaryReport(Pageable pageable);
}
