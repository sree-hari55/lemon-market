package com.lm.service.accounting;


import com.lm.dto.accounting.CreateInvoiceRequest;
import com.lm.dto.accounting.InvoiceDto;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import java.util.Optional;

public interface InvoiceService {
    InvoiceDto createInvoice(CreateInvoiceRequest req, String username);
    InvoiceDto getInvoice(Long id);
    Page<InvoiceDto> listInvoices(Pageable pageable);
    Optional<InvoiceDto> findBySalesOrderId(Long salesOrderId);
    void cancelInvoice(Long id, String username);
}

