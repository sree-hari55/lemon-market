package com.lm.service.customer;

import com.lm.dto.PageOfResp;
import com.lm.dto.customer.CustomerDto;
import com.lm.dto.customer.CustomerFinalPaymentDto;
import com.lm.dto.customer.CustomerPaymentSummaryDto;
import com.lm.entity.customer.CustomerFinalPayment;
import com.lm.repository.customer.CustomerFinalPaymentRepository;
import com.lm.repository.customer.CustomerRepository;
import com.lm.utils.PaginationUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class CustomerFinalPaymentServiceImpl implements CustomerFinalPaymentService{
    private final CustomerFinalPaymentRepository repository;
    private final CustomerRepository customerRepository;
    @Override
    public CustomerFinalPaymentDto create(CustomerFinalPaymentDto dto) {
        CustomerFinalPayment entity = toEntity(dto);
        CustomerFinalPayment saved = repository.save(entity);
        return toDto(saved);
    }

    @Override
    public CustomerFinalPaymentDto getById(Long id) {
        CustomerFinalPayment entity = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("CustomerFinalPayment not found with ID: " + id));
        return toDto(entity);
    }

    @Override
    public PageOfResp<CustomerFinalPaymentDto> getAll(Pageable pageable) {
        Page<CustomerFinalPaymentDto> pageResult =
                repository.findAll(pageable).map(this::toDto);
        return PaginationUtils.convertToPageResponse(pageResult);
    }

    @Override
    public CustomerFinalPaymentDto update(Long id, CustomerFinalPaymentDto dto) {
        CustomerFinalPayment existing = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("CustomerFinalPayment not found with ID: " + id));

        existing.setAdvancePayment(dto.getAdvancePayment());
        existing.setPaidPayment(dto.getPaidPayment());
        existing.setTotalPayment(dto.getTotalPayment());
        existing.setPendingPayment(dto.getPendingPayment());

        CustomerFinalPayment updated = repository.save(existing);
        return toDto(updated);
    }

    @Override
    public void deleteById(Long id) {
        repository.deleteById(id);
    }

    @Override
    public CustomerPaymentSummaryDto getSummary() {
        log.debug("Calculating customer payment summary.");

        List<CustomerFinalPayment> payments = repository.findAll();
        CustomerPaymentSummaryDto dto = new CustomerPaymentSummaryDto();

        if (!payments.isEmpty()) {
            BigDecimal totalPaid = payments.stream()
                    .map(p -> Optional.ofNullable(p.getPaidPayment()).orElse(BigDecimal.ZERO))
                    .reduce(BigDecimal.ZERO, BigDecimal::add);

            BigDecimal totalPending = payments.stream()
                    .map(p -> Optional.ofNullable(p.getPendingPayment()).orElse(BigDecimal.ZERO))
                    .reduce(BigDecimal.ZERO, BigDecimal::add);

            BigDecimal totalAmount = payments.stream()
                    .map(p -> Optional.ofNullable(p.getTotalPayment()).orElse(BigDecimal.ZERO))
                    .reduce(BigDecimal.ZERO, BigDecimal::add);

            BigDecimal totalAdvancePayments = payments.stream()
                    .map(p -> Optional.ofNullable(p.getAdvancePayment()).orElse(BigDecimal.ZERO))
                    .reduce(BigDecimal.ZERO, BigDecimal::add);

            dto.setPaidPayment(totalPaid);
            dto.setPendingAmount(totalPending);
            dto.setTotalPayments(totalAmount);
            dto.setTotalAdvancePayments(totalAdvancePayments);
        } else {
            log.warn("No customer final payments found in the database.");
            dto.setPaidPayment(BigDecimal.ZERO);
            dto.setPendingAmount(BigDecimal.ZERO);
            dto.setTotalPayments(BigDecimal.ZERO);
            dto.setTotalAdvancePayments(BigDecimal.ZERO);
        }

        long customerCount = customerRepository.count();
        dto.setTotalCustomers(customerCount);

        return dto;
    }

    public CustomerFinalPaymentDto toDto(CustomerFinalPayment entity) {
        CustomerFinalPaymentDto dto = new CustomerFinalPaymentDto();
        dto.setId(entity.getId());
        dto.setAdvancePayment(entity.getAdvancePayment());
        dto.setPaidPayment(entity.getPaidPayment());
        dto.setTotalPayment(entity.getTotalPayment());
        dto.setPendingPayment(entity.getPendingPayment());
        dto.setCreatedDate(entity.getCreatedDate());
        dto.setModifiedDate(entity.getModifiedDate());
        CustomerDto customerDto = new CustomerDto();
        BeanUtils.copyProperties(entity.getCustomer(),customerDto);
        dto.setCustomerDto(customerDto);

        return dto;
    }

    public CustomerFinalPayment toEntity(CustomerFinalPaymentDto dto) {
        CustomerFinalPayment entity = new CustomerFinalPayment();
        entity.setId(dto.getId());
        entity.setAdvancePayment(dto.getAdvancePayment());
        entity.setPaidPayment(dto.getPaidPayment());
        entity.setTotalPayment(dto.getTotalPayment());
        entity.setPendingPayment(dto.getPendingPayment());
        // createdDate and modifiedDate are set automatically in entity
        return entity;
    }
}
