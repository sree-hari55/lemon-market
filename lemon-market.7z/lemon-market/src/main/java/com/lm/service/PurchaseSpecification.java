package com.lm.service;


import com.lm.dto.PurchaseFilterDto;
import com.lm.entity.Purchase;
import jakarta.persistence.criteria.Predicate;
import org.springframework.data.jpa.domain.Specification;

import java.util.ArrayList;
import java.util.List;

public class PurchaseSpecification {

    public static Specification<Purchase> withFilters(PurchaseFilterDto filter) {
        return (root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();

            if (filter.getFarmerId() != null) {
                predicates.add(cb.equal(root.get("farmer").get("id"), filter.getFarmerId()));
            }

            if (filter.getFarmerFirstName() != null && !filter.getFarmerFirstName().isEmpty()) {
                predicates.add(cb.like(cb.lower(root.get("farmer").get("firstName")), "%" + filter.getFarmerFirstName().toLowerCase() + "%"));
            }

            if (filter.getVehicleNumber() != null && !filter.getVehicleNumber().isEmpty()) {
                predicates.add(cb.like(cb.lower(root.get("vehicleNumber")), "%" + filter.getVehicleNumber().toLowerCase() + "%"));
            }

            if (filter.getLocation() != null && !filter.getLocation().isEmpty()) {
                predicates.add(cb.like(cb.lower(root.get("location")), "%" + filter.getLocation().toLowerCase() + "%"));
            }

            if (filter.getLemonType() != null && !filter.getLemonType().isEmpty()) {
                predicates.add(cb.equal(cb.lower(root.get("lemonType")), filter.getLemonType().toLowerCase()));
            }

            if (filter.getFromDate() != null) {
                predicates.add(cb.greaterThanOrEqualTo(root.get("creationDate"), filter.getFromDate()));
            }

            if (filter.getToDate() != null) {
                predicates.add(cb.lessThanOrEqualTo(root.get("creationDate"), filter.getToDate()));
            }

            if (filter.getMinWeight() != null) {
                predicates.add(cb.greaterThanOrEqualTo(root.get("weight"), filter.getMinWeight()));
            }

            if (filter.getMaxWeight() != null) {
                predicates.add(cb.lessThanOrEqualTo(root.get("weight"), filter.getMaxWeight()));
            }

            return cb.and(predicates.toArray(new Predicate[0]));
        };
    }
}

