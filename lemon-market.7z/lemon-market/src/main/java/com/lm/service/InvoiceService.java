package com.lm.service;

import com.lm.entity.Purchase;
import com.lm.repository.PurchaseRepository;
import com.lowagie.text.*;
import com.lowagie.text.Font;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.awt.*;
import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;
import java.util.stream.Stream;


@Service
@RequiredArgsConstructor
public class InvoiceService {

    private final PurchaseRepository purchaseRepository;

    private static final int LINE_LENGTH = 74;

    public byte[] generateInvoicePdf(long id) {
        Purchase purchase = purchaseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Sale not found with the sale id:"+id));

        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Document document = new Document(PageSize.A4, 36, 36, 36, 36);
            PdfWriter.getInstance(document, out);
            document.open();

            Font monoFont = new Font(Font.COURIER, 11, Font.NORMAL);
            Font boldMono = new Font(Font.COURIER, 11, Font.BOLD);

            document.add(center("TAX INVOICE", boldMono));
            document.add(line(generateLine(LINE_LENGTH), boldMono));

            document.add(center("Lemon Market", monoFont));
          //  document.add(center("Address Line, Contact Info", monoFont));
            document.add(Chunk.NEWLINE);

            document.add(new Paragraph(
                    String.format("Invoice No: %s        Date: %s",
                            UUID.randomUUID(),
                            LocalDate.now()), monoFont));

            document.add(new Paragraph("Customer Name: " + purchase.getFarmer().getFirstName() +" "+ purchase.getFarmer().getLastName(), monoFont));
            document.add(new Paragraph("Village Name: " + purchase.getFarmer().getAddress(), monoFont));
            document.add(new Paragraph("Mobile No: " + purchase.getFarmer().getPhoneNumber(), monoFont));
            document.add(Chunk.NEWLINE);

            PdfPTable table = new PdfPTable(5); // 5 columns
            table.setWidthPercentage(100);
            table.setSpacingBefore(10f);
            table.setSpacingAfter(10f);
            table.setWidths(new float[]{1, 4, 2, 2, 2}); // relative widths

            Font headerFont = new Font(Font.COURIER, 11, Font.BOLD);
            Font bodyFont = new Font(Font.COURIER, 11, Font.NORMAL);

            Stream.of("SNO", "Item Description", "Qty (kg)", "Rate (₹)", "Amount")
                    .forEach(columnTitle -> {
                        PdfPCell header = new PdfPCell();
                        header.setBackgroundColor(Color.LIGHT_GRAY);
                        header.setBorderWidth(1);
                        header.setPhrase(new Phrase(columnTitle, headerFont));
                        header.setHorizontalAlignment(Element.ALIGN_CENTER);
                        table.addCell(header);
                    });
            int srNo = 1;
            BigDecimal subtotal = BigDecimal.ZERO;

            BigDecimal amount = purchase.getWeight().multiply(purchase.getPricePerKg());
            subtotal = subtotal.add(amount);

            table.addCell(new Phrase(String.valueOf(srNo++), bodyFont));
                table.addCell(new Phrase("Lemon", bodyFont));
                table.addCell(new Phrase(String.format("%.0f", purchase.getWeight()), bodyFont));
                table.addCell(new Phrase(String.format("%.2f", purchase.getPricePerKg()), bodyFont));
                table.addCell(new Phrase(String.format("%.2f", amount), bodyFont));

            document.add(table);

            BigDecimal commission = purchase.getCommission();
            BigDecimal transport = purchase.getTransportCharge();
            BigDecimal afterDeductions = subtotal
                    .subtract(commission != null ? commission : BigDecimal.ZERO)
                    .subtract(transport != null ? transport : BigDecimal.ZERO);

            int bags = purchase.getBags();
            BigDecimal bagsCharge = BigDecimal.valueOf(bags).multiply(BigDecimal.valueOf(30));

            BigDecimal finalAmount = afterDeductions.add(bagsCharge);

            document.add(right(String.format("Subtotal: ₹%.2f", subtotal), monoFont));
            document.add(right(String.format("Commission: ₹%.2f", commission), monoFont));
            document.add(right(String.format("Transport: ₹%.2f", transport), monoFont));
            document.add(right("--------------------", monoFont));

            document.add(right(String.format("Total After Deductions: ₹%.2f", afterDeductions), boldMono));
            document.add(right("Additional Charges:", monoFont));
            document.add(right(String.format("  Bags (%d x ₹30): ₹%.2f", bags, bagsCharge), monoFont));
            document.add(right("-------------------------------", monoFont));
            document.add(right(String.format("FINAL AMOUNT PAYABLE: ₹%.2f", finalAmount), boldMono));


            document.close();
            return out.toByteArray();

        } catch (Exception e) {
            throw new RuntimeException("Failed to generate invoice PDF", e);
        }
    }

    private String padRight(String str, int width) {
        return String.format("%-" + width + "s", str);
    }

    Paragraph line(String text, Font font) {
        return new Paragraph(text, font);
    }
    private String generateLine(int length) {
        return "-".repeat(length);
    }

    private Paragraph center(String text, Font font) {
        Paragraph p = new Paragraph(text, font);
        p.setAlignment(Element.ALIGN_CENTER);
        return p;
    }

    private Paragraph right(String text, Font font) {
        Paragraph p = new Paragraph(text, font);
        p.setAlignment(Element.ALIGN_RIGHT);
        return p;
    }
}
