package com.lm.service.customer;

import com.lm.dto.PageOfResp;
import com.lm.dto.accounting.FarmerResponsePaymentDto;
import com.lm.dto.customer.CustomerPaymentDto;
import com.lm.dto.customer.CustomerPaymentFilterDto;
import com.lm.dto.customer.CustomerResponsePaymentDto;
import com.lm.dto.farmer.FarmerPaymentFilterDto;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface CustomerPaymentService {
    CustomerResponsePaymentDto create(CustomerPaymentDto dto);
    PageOfResp<CustomerResponsePaymentDto> getAll(Pageable page);
    CustomerResponsePaymentDto getById(Long id);
    CustomerResponsePaymentDto update(Long id, CustomerPaymentDto dto);
    boolean delete(Long id);
    List<CustomerResponsePaymentDto> getByCustomerId(Long farmerId);
    PageOfResp<CustomerResponsePaymentDto> filter(CustomerPaymentFilterDto dto, Pageable page);
    byte[] exportCSV(CustomerPaymentFilterDto dto);
    byte[] exportPDF(CustomerPaymentFilterDto dto);

}
