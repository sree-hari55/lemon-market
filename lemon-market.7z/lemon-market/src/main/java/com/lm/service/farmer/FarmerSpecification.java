package com.lm.service.farmer;

import com.lm.dto.farmer.FarmerFilterDto;
import com.lm.entity.farmer.Farmer;
import jakarta.persistence.criteria.Predicate;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

public class FarmerSpecification {
    public static Specification<Farmer> withFilters(FarmerFilterDto filter) {
        return (root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();

            if (StringUtils.hasText(filter.getFirstName())) {
                predicates.add(cb.like(cb.lower(root.get("firstName")), "%" + filter.getFirstName().toLowerCase() + "%"));
            }

            if (StringUtils.hasText(filter.getLastName())) {
                predicates.add(cb.like(cb.lower(root.get("lastName")), "%" + filter.getLastName().toLowerCase() + "%"));
            }

            if (StringUtils.hasText(filter.getPhoneNumber())) {
                predicates.add(cb.like(cb.lower(root.get("phoneNumber")), "%" + filter.getPhoneNumber().toLowerCase() + "%"));
            }

            if (StringUtils.hasText(filter.getEmail())) {
                predicates.add(cb.like(cb.lower(root.get("email")), "%" + filter.getEmail().toLowerCase() + "%"));
            }

            return cb.and(predicates.toArray(new Predicate[0]));
        };
    }
}
