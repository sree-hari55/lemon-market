package com.lm.service;

import com.lm.dto.PageOfResp;
import com.lm.dto.PurchaseDto;
import com.lm.dto.PurchaseFilterDto;
import com.lm.dto.PurchaseSummaryDto;
import com.lm.dto.customer.CustomerDto;
import com.lm.dto.farmer.FarmerDto;
import com.lm.entity.Purchase;
import com.lm.entity.farmer.Farmer;
import com.lm.entity.farmer.FarmerFinalPayment;
import com.lm.entity.farmer.FarmerPayment;
import com.lm.entity.inventory.InventoryItem;
import com.lm.repository.farmer.FarmerFinalPaymentRepository;
import com.lm.repository.PurchaseRepository;
import com.lm.repository.farmer.FarmerPaymentRepository;
import com.lm.repository.farmer.FarmerRepository;
import com.lm.service.inventory.InventoryService;
import com.lm.utils.PaginationUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static java.util.stream.Collectors.toList;

@Service
@RequiredArgsConstructor
@Slf4j
public class PurchaseService {

    private final PurchaseRepository purchaseRepository;
    private final FarmerRepository farmerRepository;
    private final FarmerFinalPaymentRepository farmerFinalPaymentRepository;
    private final FarmerPaymentRepository farmerPaymentRepository;
    private final InventoryService inventoryService;

    private static final double DEFAULT_COMMISSION_RATE = 0.10;
    private static final double TRANSPORT_CHARGE_PER_KM_PER_BAG = 5.0;
    @Transactional
    public PurchaseDto calculateBilling(PurchaseDto dto) {
        Farmer farmer = farmerRepository.findById(dto.getFarmer().getId())
                .orElseThrow(() -> new RuntimeException("Farmer not found"));

        int bagCount = calculateBagCount(dto);

        BigDecimal saleAmount = dto.getWeight().multiply(dto.getPricePerKg());

        BigDecimal commission = (dto.getCommission() != null && dto.getCommission().compareTo(BigDecimal.ZERO) > 0)
                ? dto.getCommission()
                : saleAmount.multiply(BigDecimal.valueOf(DEFAULT_COMMISSION_RATE));

        BigDecimal transportCharge = (dto.getTransportCharge() != null && dto.getTransportCharge().compareTo(BigDecimal.ZERO) > 0)
                ? dto.getTransportCharge()
                : calculateTransportCharge(bagCount, BigDecimal.valueOf(dto.getTransportDistance()));

        BigDecimal finalAmount = (dto.getFinalAmount() != null && dto.getFinalAmount().compareTo(BigDecimal.ZERO) > 0)
                ? dto.getFinalAmount()
                : calculateFinalAmount(saleAmount, commission, transportCharge, bagCount);

        // Save Sale
        Purchase purchase = buildPurchase(dto, farmer, bagCount, commission, transportCharge, finalAmount);
        purchaseRepository.save(purchase);

        // Update Customer Payment Info
        updateFarmerPayment(farmer, finalAmount);

        // create inventory
        inventoryService.updateInventoryAfterPurchase(purchase,farmer.getFirstName()+" "+farmer.getLastName());

        // Return DTO
        PurchaseDto purchaseDto = new PurchaseDto();
        BeanUtils.copyProperties(purchase, purchaseDto);
        return purchaseDto;
    }

    private int calculateBagCount(PurchaseDto dto) {
        if (dto.getBags() > 0) {
            return dto.getBags();
        } else {
            return dto.getWeight().divide(BigDecimal.valueOf(50), 0, RoundingMode.DOWN).intValue();
        }
    }

    private BigDecimal calculateTransportCharge(int bags, BigDecimal distance) {
        return BigDecimal.valueOf(bags)
                .multiply(distance)
                .multiply(BigDecimal.valueOf(TRANSPORT_CHARGE_PER_KM_PER_BAG));
    }

    private BigDecimal calculateFinalAmount(BigDecimal saleAmount, BigDecimal commission, BigDecimal transportCharge, int bags) {
        return saleAmount
                .subtract(commission)
                .subtract(transportCharge)
                .add(BigDecimal.valueOf(bags).multiply(BigDecimal.valueOf(30)));
    }

    private Purchase buildPurchase(PurchaseDto dto, Farmer farmer, int bagCount, BigDecimal commission, BigDecimal transportCharge, BigDecimal finalAmount) {
        Purchase purchase = new Purchase();
        purchase.setWeight(dto.getWeight());
        purchase.setPricePerKg(dto.getPricePerKg());
        purchase.setBags(bagCount);
        purchase.setVehicleNumber(dto.getVehicleNumber());
        purchase.setTransportDistanceKm(dto.getTransportDistance());

        purchase.setFinalAmount(finalAmount);
        purchase.setCommission(commission);

        purchase.setTransportCharge(transportCharge);
        purchase.setLemonType(dto.getQuality());
        purchase.setLocation("WAREHOUSE");

        purchase.setFarmer(farmer);
        return purchase;
    }



    private void updateFarmerPayment(Farmer farmer, BigDecimal finalAmount) {
        Optional<FarmerFinalPayment> optionalPayment = farmerFinalPaymentRepository.findByFarmerId(farmer.getId());
        FarmerFinalPayment payment = optionalPayment.orElseGet(FarmerFinalPayment::new);

        payment.setFarmer(farmer);

        BigDecimal updatedTotalPayment = optionalPayment
                .map(p -> p.getTotalPayment().add(finalAmount))
                .orElse(finalAmount);

        BigDecimal updatedPendingPayment = optionalPayment
                .map(p -> p.getPendingPayment().add(finalAmount))
                .orElse(finalAmount);

        payment.setTotalPayment(updatedTotalPayment);
        payment.setPendingPayment(updatedPendingPayment);

        farmerFinalPaymentRepository.saveAndFlush(payment);
        Optional<FarmerPayment> optionalCustomerPayment =
                farmerPaymentRepository.findTopByFarmerIdOrderByCreatedDateDesc(farmer.getId());

        FarmerPayment existingFarmerPayment = optionalCustomerPayment.orElseGet(FarmerPayment::new);

        FarmerPayment farmerPayment = new FarmerPayment();
        farmerPayment.setFarmer(farmer);
        farmerPayment.setDepositAmount(finalAmount);
        BigDecimal previousClosingBalance = existingFarmerPayment.getClosingBalance();
        if (previousClosingBalance == null) {
            previousClosingBalance = BigDecimal.ZERO;
        }

        farmerPayment.setClosingBalance(previousClosingBalance.add(finalAmount));
        farmerPayment.setCreatedDate(LocalDateTime.now());
        farmerPayment.setPaymentType("Cash");
        farmerPayment.setNarration("Deposit");

        farmerPaymentRepository.save(farmerPayment);

    }


    public PageOfResp<PurchaseDto> getPurchases(Pageable pageable) {
        Page<PurchaseDto> pageResults = purchaseRepository.findAll(pageable).map(this::convertToDto);
        return PaginationUtils.convertToPageResponse(pageResults);
    }

    public PurchaseDto getPurchaseById(Long id) {
        Purchase purchase = purchaseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Sale not found with id: " + id));
        return convertToDto(purchase);
    }

    public PurchaseDto updatePurchase(Long id, PurchaseDto dto) {
        Purchase purchase = purchaseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Sale not found with id: " + id));

        int bags = dto.getBags() > 0 ? dto.getBags() :
                dto.getWeight().divide(BigDecimal.valueOf(50), 0, RoundingMode.DOWN).intValue();

        BigDecimal saleAmount = dto.getWeight().multiply(dto.getPricePerKg());

        BigDecimal commission = (dto.getCommission() != null && dto.getCommission().compareTo(BigDecimal.ZERO) > 0)
                ? dto.getCommission()
                : saleAmount.multiply(BigDecimal.valueOf(DEFAULT_COMMISSION_RATE));

        BigDecimal transportCharge = BigDecimal.valueOf(bags)
                .multiply(BigDecimal.valueOf(dto.getTransportDistance()))
                .multiply(BigDecimal.valueOf(TRANSPORT_CHARGE_PER_KM_PER_BAG));

        BigDecimal finalAmount = saleAmount.subtract(commission).subtract(transportCharge);

        purchase.setWeight(dto.getWeight());
        purchase.setPricePerKg(dto.getPricePerKg());
        purchase.setBags(bags);
        purchase.setVehicleNumber(dto.getVehicleNumber());
        purchase.setTransportDistanceKm(dto.getTransportDistance());

        // Assuming these fields accept BigDecimal; if not, use .doubleValue()
        purchase.setTransportCharge(transportCharge);
        purchase.setFinalAmount(finalAmount);
        purchase.setCommission(commission);

        purchase.setModifiedDate(LocalDateTime.now());

        purchase = purchaseRepository.save(purchase);
        return convertToDto(purchase);
    }


    public void deletePurchase(Long id) {
        inventoryService.findByPurchaseId(id).ifPresent(inventory -> {
            inventoryService.deleteStockMovementByInventoryId(inventory.getId());
        });
        inventoryService.deleteInventoryByPurchaseId(id);
        purchaseRepository.deleteById(id);
    }

    private PurchaseDto convertToDto(Purchase purchase) {
        PurchaseDto dto = new PurchaseDto();
        BeanUtils.copyProperties(purchase, dto);
        if (purchase.getFarmer() != null) {
            FarmerDto farmerDto = new FarmerDto();
            BeanUtils.copyProperties(purchase.getFarmer(), farmerDto);
            dto.setFarmer(farmerDto);
        }
        return dto;
    }
}
