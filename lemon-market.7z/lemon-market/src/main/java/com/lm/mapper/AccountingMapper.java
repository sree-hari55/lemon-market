package com.lm.mapper;


import com.lm.dto.accounting.CreateInvoiceRequest;
import com.lm.dto.accounting.CreatePaymentRequest;
import com.lm.dto.accounting.InvoiceDto;
import com.lm.dto.accounting.PaymentDto;
import com.lm.entity.accounting.Invoice;
import com.lm.entity.accounting.Payment;
import org.springframework.stereotype.Component;
import java.util.stream.Collectors;

@Component
public class AccountingMapper {

    public InvoiceDto toDto(Invoice e) {
        if (e == null) return null;
        InvoiceDto d = new InvoiceDto();
        d.setId(e.getId());
        d.setInvoiceNumber(e.getInvoiceNumber());
        d.setSalesOrderId(e.getSalesOrderId());
        d.setCustomerId(e.getCustomerId());
        d.setTotalAmount(e.getTotalAmount());
        d.setBalanceDue(e.getBalanceDue());
        d.setStatus(e.getStatus() != null ? e.getStatus().name() : null);
        d.setIssueDate(e.getIssueDate());
        d.setDueDate(e.getDueDate());
        if (e.getPayments() != null) {
            d.setPayments(e.getPayments().stream().map(this::toDto).collect(Collectors.toList()));
        }
        return d;
    }

    public PaymentDto toDto(Payment p) {
        if (p == null) return null;
        PaymentDto d = new PaymentDto();
        d.setId(p.getId());
        d.setInvoiceId(p.getInvoice() != null ? p.getInvoice().getId() : null);
        d.setAmount(p.getAmount());
        d.setPaymentDate(p.getPaymentDate());
        d.setMode(p.getMode());
        d.setReference(p.getReference());
        d.setReceivedBy(p.getReceivedBy());
        return d;
    }

    public Invoice toEntity(CreateInvoiceRequest req) {
        if (req == null) return null;
        Invoice e = new Invoice();
        e.setInvoiceNumber(req.getInvoiceNumber());
        e.setSalesOrderId(req.getSalesOrderId());
        e.setCustomerId(req.getCustomerId());
        e.setTotalAmount(req.getTotalAmount());
        e.setBalanceDue(req.getTotalAmount());
        e.setIssueDate(req.getIssueDate());
        e.setDueDate(req.getDueDate());
        e.setStatus(Invoice.Status.PENDING);
        return e;
    }

    public Payment toEntity(CreatePaymentRequest req, Invoice invoice) {
        if (req == null) return null;
        Payment p = new Payment();
        p.setInvoice(invoice);
        p.setAmount(req.getAmount());
        p.setPaymentDate(req.getPaymentDate());
        p.setMode(req.getMode());
        p.setReference(req.getReference());
        p.setReceivedBy(req.getReceivedBy());
        return p;
    }
}

