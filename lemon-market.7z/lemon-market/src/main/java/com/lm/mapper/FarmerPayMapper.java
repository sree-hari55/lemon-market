package com.lm.mapper;

import com.lm.dto.accounting.FarmerResponsePaymentDto;
import com.lm.dto.farmer.FarmerPayDto;
import com.lm.entity.farmer.FarmerPayment;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
public class FarmerPayMapper {

    public FarmerResponsePaymentDto toDto(FarmerPayment entity) {

        FarmerResponsePaymentDto dto = new FarmerResponsePaymentDto();
        BeanUtils.copyProperties(entity, dto);
      //  CustomerDto customerDto = new CustomerDto();
       // BeanUtils.copyProperties(entity, customerDto);
     //   dto.setCustomer(customerDto);
        return dto;
    }

    public FarmerPayment toEntity(FarmerPayDto dto, FarmerPayment customerPayment) {
        FarmerPayment entity = new FarmerPayment();
       // entity.setId(dto.getId());
        entity.setWithdrawalAmount(dto.getAmount());
        entity.setPaymentType(dto.getPaymentType());
        entity.setCreatedDate(dto.getCreatedDate());
        entity.setModifiedDate(dto.getModifiedDate());
        BigDecimal previousClosingBalance = customerPayment.getClosingBalance();
        if (previousClosingBalance == null) {
            previousClosingBalance = BigDecimal.ZERO;
        }
        entity.setClosingBalance(previousClosingBalance.subtract(dto.getAmount()));
        return entity;
    }
}

