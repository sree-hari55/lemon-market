package com.lm.mapper;

import com.lm.dto.accounting.FarmerResponsePaymentDto;
import com.lm.dto.farmer.FarmerAdvancePaymentDto;
import com.lm.entity.farmer.FarmerAdvancePayment;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Optional;

@Component
public class FarmerAdvancePaymentMapper {

    public FarmerAdvancePaymentDto toDto(FarmerAdvancePayment entity) {
        FarmerAdvancePaymentDto dto = new FarmerAdvancePaymentDto();
        dto.setFarmerId(entity.getId());
        dto.setPaymentType(entity.getPaymentType());
     //   dto.setAmount(entity.getAmount());
        dto.setInterest(entity.isInterest());
        dto.setInterestRateInRupees(entity.getInterestRateInRupees());
        dto.setCreatedDate(entity.getCreatedDate());
        dto.setModifiedDate(entity.getModifiedDate());
        return dto;
    }
    public FarmerResponsePaymentDto toResponseDto(FarmerAdvancePayment entity) {
        FarmerResponsePaymentDto dto = new FarmerResponsePaymentDto();
        BeanUtils.copyProperties(entity, dto);
        return dto;
    }

    public FarmerAdvancePayment toEntity(FarmerAdvancePaymentDto dto, Optional<FarmerAdvancePayment> optionalCustomerAdvancePayment) {
        BigDecimal closingBalance = BigDecimal.ZERO;
        FarmerAdvancePayment entity = new FarmerAdvancePayment();
        entity.setPaymentType(dto.getPaymentType());

        if(optionalCustomerAdvancePayment.isPresent()){
            FarmerAdvancePayment customerAdvancePayment = optionalCustomerAdvancePayment.get();
            BigDecimal previousClosingBalance = customerAdvancePayment.getClosingBalance();
            if (previousClosingBalance == null) {
                previousClosingBalance = BigDecimal.ZERO;
            }

           closingBalance = previousClosingBalance.add(dto.getAmount());
        }else{
            closingBalance = dto.getAmount();

        }
        entity.setDepositAmount(dto.getAmount());
        entity.setClosingBalance(closingBalance);
        entity.setInterest(dto.isInterest());
        entity.setInterestRateInRupees(dto.getInterestRateInRupees());
        entity.setCreatedDate(dto.getCreatedDate());
        entity.setModifiedDate(dto.getModifiedDate());

        return entity;
    }

    public FarmerAdvancePayment toEntityForReturnAdvancePayment(FarmerAdvancePaymentDto dto, Optional<FarmerAdvancePayment> optionalCustomerAdvancePayment) {
        BigDecimal closingBalance = BigDecimal.ZERO;
        FarmerAdvancePayment entity = new FarmerAdvancePayment();
        entity.setPaymentType(dto.getPaymentType());

        if(optionalCustomerAdvancePayment.isPresent()){
            FarmerAdvancePayment customerAdvancePayment = optionalCustomerAdvancePayment.get();
            BigDecimal previousClosingBalance = customerAdvancePayment.getClosingBalance();
            if (previousClosingBalance == null) {
                previousClosingBalance = BigDecimal.ZERO;
            }
            closingBalance = previousClosingBalance.subtract(dto.getAmount());
        }else{
            closingBalance = dto.getAmount();
        }
        entity.setWithdrawalAmount(dto.getAmount());
        entity.setClosingBalance(closingBalance);
        entity.setInterest(dto.isInterest());
        entity.setInterestRateInRupees(dto.getInterestRateInRupees());
        entity.setCreatedDate(dto.getCreatedDate());
        entity.setModifiedDate(dto.getModifiedDate());

        return entity;
    }
}

