package com.lm.mapper;

import com.lm.dto.farmer.FarmerDto;
import com.lm.dto.farmer.FarmerFinalPaymentDto;
import com.lm.entity.farmer.FarmerFinalPayment;
import org.springframework.beans.BeanUtils;

public class FarmerFinalPaymentMapper {

    public static FarmerFinalPaymentDto toDto(FarmerFinalPayment entity) {
        FarmerFinalPaymentDto dto = new FarmerFinalPaymentDto();
        dto.setId(entity.getId());
        dto.setAdvancePayment(entity.getAdvancePayment());
        dto.setPaidPayment(entity.getPaidPayment());
        dto.setTotalPayment(entity.getTotalPayment());
        dto.setPendingPayment(entity.getPendingPayment());
        dto.setCreatedDate(entity.getCreatedDate());
        dto.setModifiedDate(entity.getModifiedDate());
        FarmerDto farmerDto = new FarmerDto();
        BeanUtils.copyProperties(entity.getFarmer(),farmerDto);
        dto.setFarmerDto(farmerDto);

        return dto;
    }

    public static FarmerFinalPayment toEntity(FarmerFinalPaymentDto dto) {
        FarmerFinalPayment entity = new FarmerFinalPayment();
        entity.setId(dto.getId());
        entity.setAdvancePayment(dto.getAdvancePayment());
        entity.setPaidPayment(dto.getPaidPayment());
        entity.setTotalPayment(dto.getTotalPayment());
        entity.setPendingPayment(dto.getPendingPayment());
        // createdDate and modifiedDate are set automatically in entity
        return entity;
    }
}
