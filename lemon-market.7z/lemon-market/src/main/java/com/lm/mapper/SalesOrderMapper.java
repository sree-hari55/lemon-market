/*
package com.lm.mapper;

import com.lm.dto.sales.SalesOrderDto;
import com.lm.dto.sales.SalesOrderItemDto;
import com.lm.dto.sales.ShipmentDetailsDto;
import com.lm.entity.sales.SalesOrder;
import com.lm.entity.sales.SalesOrderItem;
import com.lm.entity.sales.ShipmentDetails;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class SalesOrderMapper {

    public SalesOrderDto toDto(SalesOrder e) {
        if (e == null) return null;
        SalesOrderDto dto = new SalesOrderDto();
        dto.setId(e.getId());
        dto.setOrderNumber(e.getOrderNumber());
        dto.setCustomerId(e.getCustomerId());
        dto.setStatus(e.getStatus() != null ? e.getStatus().name() : null);
        dto.setTotalAmount(e.getTotalAmount());

        if (e.getItems() != null) {
            dto.setItems(
                    e.getItems().stream()
                            .map(this::toDto)
                            .collect(Collectors.toList())
            );
        }
        if (e.getShipmentDetails() != null) {
            ShipmentDetailsDto s = new ShipmentDetailsDto();
            s.setCarrier(e.getShipmentDetails().getCarrier());
            s.setTrackingNumber(e.getShipmentDetails().getTrackingNumber());
            s.setOriginCountry(e.getShipmentDetails().getOriginCountry());
            s.setDestinationCountry(e.getShipmentDetails().getDestinationCountry());
            dto.setShipmentDetails(s);
        }
        return dto;
    }

    public SalesOrder toEntity(SalesOrderDto d) {
        if (d == null) return null;
        SalesOrder entity = new SalesOrder();
        entity.setId(d.getId());
        entity.setOrderNumber(d.getOrderNumber());
        entity.setCustomerId(d.getCustomerId());
        if (d.getStatus() != null) {
            entity.setStatus(SalesOrder.Status.valueOf(d.getStatus()));
        }
        entity.setTotalAmount(d.getTotalAmount());

        if (d.getItems() != null) {
            entity.setItems(
                    d.getItems().stream()
                            .map(this::toEntity)
                            .collect(Collectors.toList())
            );
            entity.getItems().forEach(i -> i.setSalesOrder(entity));
        }
        if (d.getShipmentDetails() != null) {
            ShipmentDetails s = new ShipmentDetails();
            s.setCarrier(d.getShipmentDetails().getCarrier());
            s.setTrackingNumber(d.getShipmentDetails().getTrackingNumber());
            s.setOriginCountry(d.getShipmentDetails().getOriginCountry());
            s.setDestinationCountry(d.getShipmentDetails().getDestinationCountry());
            entity.setShipmentDetails(s);
        }
        return entity;
    }

    public SalesOrderItemDto toDto(SalesOrderItem i) {
        if (i == null) return null;
        SalesOrderItemDto dto = new SalesOrderItemDto();
     //   dto.setInventoryItemId(i.getInventoryItemId());
        dto.setItemName(i.getItemName());
        dto.setQuantity(i.getQuantity());
        dto.setUnitPrice(i.getUnitPrice());
        return dto;
    }

    public SalesOrderItem toEntity(SalesOrderItemDto d) {
        if (d == null) return null;
        SalesOrderItem entity = new SalesOrderItem();
    //    entity.setInventoryItemId(d.getInventoryItemId());
        entity.setItemName(d.getItemName());
        entity.setQuantity(d.getQuantity());
        entity.setUnitPrice(d.getUnitPrice());
        return entity;
    }
}
*/
