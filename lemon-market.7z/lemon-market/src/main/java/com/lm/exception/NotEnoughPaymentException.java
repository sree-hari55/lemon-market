package com.lm.exception;

public class NotEnoughPaymentException extends RuntimeException{
    NotEnoughPaymentException(){
        super();
    }
    public NotEnoughPaymentException(String message){
        super(message);
    }
}
