package com.lm.exception;

public class InsufficientStockException extends RuntimeException {
    public InsufficientStockException(Long inventoryId, int available, int requested) {
        super("Insufficient stock for item " + inventoryId + ". Available=" + available + " Requested=" + requested);
    }

    public InsufficientStockException(String stockNotAvailable) {
        super(stockNotAvailable);
    }
}
