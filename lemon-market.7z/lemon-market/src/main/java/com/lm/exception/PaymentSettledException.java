package com.lm.exception;

public class PaymentSettledException extends RuntimeException{
    PaymentSettledException(){
        super();
    }
    public PaymentSettledException(String message){
        super(message);
    }
}
