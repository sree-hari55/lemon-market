package com.lm.exception;

public class InvalidPaymentException extends RuntimeException{
    InvalidPaymentException(){
        super();
    }
    public InvalidPaymentException(String message){
        super(message);
    }
}
