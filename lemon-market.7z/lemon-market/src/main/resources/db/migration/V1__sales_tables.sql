CREATE TABLE sales_order (
  id BIGSERIAL PRIMARY KEY,
  order_number VARCHAR(100),
  customer_id BIGINT NOT NULL,
  status VARCHAR(20),
  total_amount NUMERIC(18,2),
  created_at TIMESTAMP WITH TIME ZONE,
  updated_at TIMESTAMP WITH TIME ZONE,
  confirmed_at TIMESTAMP WITH TIME ZONE,
  version BIGINT
);

CREATE TABLE sales_order_item (
  id BIGSERIAL PRIMARY KEY,
  sales_order_id BIGINT REFERENCES sales_order(id) ON DELETE CASCADE,
  inventory_item_id BIGINT,
  item_name VARCHAR(255),
  quantity INTEGER,
  unit_price NUMERIC(18,2),
  line_total NUMERIC(18,2)
);

CREATE TABLE audit_log (
  id BIGSERIAL PRIMARY KEY,
  module_name VARCHAR(50),
  action VARCHAR(50),
  entity_id BIGINT,
  username VARCHAR(150),
  details TEXT,
  timestamp TIMESTAMP WITH TIME ZONE
);
