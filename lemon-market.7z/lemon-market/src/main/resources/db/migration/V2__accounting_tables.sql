CREATE TABLE invoice (
  id BIGSERIAL PRIMARY KEY,
  invoice_number VARCHAR(100),
  sales_order_id BIGINT,
  customer_id BIGINT,
  total_amount NUMERIC(18,2),
  balance_due NUMERIC(18,2),
  status VARCHAR(20),
  issue_date TIMESTAMP WITH TIME ZONE,
  due_date TIMESTAMP WITH TIME ZONE,
  version BIGINT
);

CREATE TABLE payment (
  id BIGSERIAL PRIMARY KEY,
  invoice_id BIGINT REFERENCES invoice(id) ON DELETE CASCADE,
  amount NUMERIC(18,2),
  payment_date TIMESTAMP WITH TIME ZONE,
  mode VARCHAR(50),
  reference VARCHAR(255),
  received_by VARCHAR(150)
);
